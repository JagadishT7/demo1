DROP TABLE IF EXISTS `nagiosna_Sources`;
CREATE TABLE IF NOT EXISTS `nagiosna_Sources` (
    `sid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `port` SMALLINT UNSIGNED  NOT NULL UNIQUE,
    `addresses` TEXT,
    `name` VARCHAR(255) NOT NULL UNIQUE,
    `flowtype` ENUM('netflow', 'sflow'),
    `directory` VARCHAR(255) NOT NULL UNIQUE,
    `lifetime` VARCHAR(20) NOT NULL DEFAULT '2d'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_SourceGroups`;
CREATE TABLE IF NOT EXISTS `nagiosna_SourceGroups` (
    `gid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO
    `nagiosna_SourceGroups`
    (`name`)
VALUES
    ('All Sources');

DROP TABLE IF EXISTS `nagiosna_Views`;
CREATE TABLE IF NOT EXISTS `nagiosna_Views` (
    `vid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL UNIQUE,
    `lifetime` VARCHAR(20) NOT NULL DEFAULT '4w',
    `limiter` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_SGLinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_SGLinker` (
    `gid` INT NOT NULL,
    `sid` INT NOT NULL,
    PRIMARY KEY(`gid`, `sid`),
    FOREIGN KEY (sid) REFERENCES nagiosna_Sources(sid),
    FOREIGN KEY (gid) REFERENCES nagiosna_SourceGroups(gid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `nagiosna_SourcesViewsLinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_SourcesViewsLinker` (
    `sid` INT NOT NULL,
    `vid` INT NOT NULL,
    PRIMARY KEY(`sid`, `vid`),
    FOREIGN KEY (sid) REFERENCES nagiosna_Sources(sid),
    FOREIGN KEY (vid) REFERENCES nagiosna_Views(vid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_Queries`;
CREATE TABLE IF NOT EXISTS `nagiosna_Queries` (
    `qid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL UNIQUE,
	`description` TEXT, 
    `rawquery` TEXT,
    `aggregate_csv` VARCHAR(200), 
    `begindate` VARCHAR(30) NOT NULL,
    `enddate` VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO
    `nagiosna_Queries`
    (`name`, `description`, `rawquery`, `aggregate_csv`, `begindate`, `enddate`)
VALUES
    ('Common Botnets', 'Aggregation of the most common ips for botnets.', '(ip 213.155.14.161 and port 80) or (ip 59.124.27.180 and port 3305) or (ip 148.81.111.111 and port 65520) or (ip 194.85.61.78 and port 80) or (ip 178.132.202.196 and port 65520)', 'srcip,dstip', '-24 hours', '-1 second'),
    ('P2P Traffic', 'Aggregation of some common P2P traffic ports.', 'port 21 or port 6346 or port 6347 or port 411 or port 1025 or port 3689', 'dstip,srcip', '-24 hours', '-1 second');

DROP TABLE IF EXISTS `nagiosna_Reports`;
CREATE TABLE IF NOT EXISTS `nagiosna_Reports` (
    `rid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL UNIQUE,
    `top` SMALLINT UNSIGNED NOT NULL,
    `toptype` VARCHAR(20) NOT NULL,
    `toporder` VARCHAR(20) NOT NULL,
    `begindate` VARCHAR(30) NOT NULL,
    `enddate` VARCHAR(30) NOT NULL,
    `editable` TINYINT(1) UNSIGNED DEFAULT 1,
    `rawquery` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO 
    `nagiosna_Reports` 
    (`name`, `top`, `toptype`, `toporder`, `begindate`, `enddate`, `editable`)
VALUES
    ('Top 5 Talkers By Source IP (Last 24 Hours)', 5, 'srcip', 'bytes', '-24 hours', '-1 second', 0),
    ('Top 5 Talkers By Destination IP (Last 24 Hours)', 5, 'dstip', 'bytes', '-24 hours', '-1 second', 0),
    ('Top 5 Talkers By Source Port (Last 24 Hours)', 5, 'srcport', 'bytes', '-24 hours', '-1 second', 0),
    ('Top 5 Talkers By Destination Port (Last 24 Hours)', 5, 'dstport', 'bytes', '-24 hours', '-1 second', 0);

DROP TABLE IF EXISTS `nagiosna_Checks`;
CREATE TABLE IF NOT EXISTS `nagiosna_Checks` (
    `cid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `rawquery` TEXT,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `warning` VARCHAR(20),
    `sid` INT,
    `gid` INT,
    `vid` INT,
    `active` TINYINT(1) UNSIGNED DEFAULT 1,
    `critical` VARCHAR(20),
    `aberrant` TINYINT(1) UNSIGNED DEFAULT 0,
    `lastval` DOUBLE,
    `lastrun` TIMESTAMP,
    `lastcode` SMALLINT DEFAULT 3,
    `laststdout` VARCHAR(200),
    FOREIGN KEY (sid) REFERENCES nagiosna_Sources(sid),
    FOREIGN KEY (vid) REFERENCES nagiosna_Views(vid),
    FOREIGN KEY (gid) REFERENCES nagiosna_SourceGroups(gid),
    `metric` ENUM('bytes', 'flows', 'packets', 'bps', 'pps', 'bpp', 'abnormal_behavior')
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_TrapReceivers`;
CREATE TABLE IF NOT EXISTS `nagiosna_TrapReceivers` (
    `tid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `version` INT NOT NULL,
    `community` VARCHAR(100),
    `authlevel` VARCHAR(20),
    `privprotocol` ENUM('AES', 'DES'),
    `privpassword` VARCHAR(200),
    `authprotocol` ENUM('MD5', 'SHA'),
    `authpassword` VARCHAR(200),
    `username` VARCHAR(100),
    `port` SMALLINT UNSIGNED  NOT NULL,
    `ip` VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_NagiosServers`;
CREATE TABLE IF NOT EXISTS `nagiosna_NagiosServers` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `nrdp` VARCHAR(200),
    `token` VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_HostServiceAssociations`;
CREATE TABLE IF NOT EXISTS `nagiosna_HostServiceAssociations` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `hostname` VARCHAR(100) NOT NULL,
    `servicename` VARCHAR(100),
    `serverid` INT NOT NULL,
    FOREIGN KEY (serverid) REFERENCES nagiosna_NagiosServers(id) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_ChecksHSALinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_ChecksHSALinker` (
    `cid` INT NOT NULL,
    `aid` INT NOT NULL,
    PRIMARY KEY(`cid`, `aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_ChecksUsersLinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_ChecksUsersLinker` (
    `cid` INT NOT NULL,
    `uid` INT NOT NULL,
    PRIMARY KEY(`cid`, `uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_ChecksTrapsLinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_ChecksTrapsLinker` (
    `cid` INT NOT NULL,
    `tid` INT NOT NULL,
    PRIMARY KEY(`cid`, `tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Tables for Ion_auth for CodeIgniter
# Table structure for table 'groups'
#
DROP TABLE IF EXISTS `nagiosna_groups`;
CREATE TABLE IF NOT EXISTS `nagiosna_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `nagiosna_groups` (`id`, `name`, `description`) VALUES
    (1,'admin','Administrator'),
    (2,'members','General User');

#
# Table structure for table 'users'
#
DROP TABLE IF EXISTS `nagiosna_users`;
CREATE TABLE IF NOT EXISTS `nagiosna_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `apiaccess` tinyint(1) unsigned DEFAULT 0,
  `apikey` varchar(128) DEFAULT NULL,
  `lang` varchar(20) DEFAULT 'english',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `nagiosna_users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
     ('1',0x7f000001,'nagiosadmin','0','','admin@admin.com','',NULL,'1268889823','0','1', '','','','');

#
# Table for configuration options
#
DROP TABLE IF EXISTS `nagiosna_cf_options`;
CREATE TABLE IF NOT EXISTS `nagiosna_cf_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` mediumint(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` TEXT NOT NULL,
  PRIMARY KEY(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	 
#
# Table structure for table 'users_groups'
#
DROP TABLE IF EXISTS `nagiosna_users_groups`;
CREATE TABLE IF NOT EXISTS `nagiosna_users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `uc_users_groups` UNIQUE (`user_id`, `group_id`),
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `nagiosna_users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `nagiosna_groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `nagiosna_users_groups` (`id`, `user_id`, `group_id`) VALUES (1,1,1);

#
# Table structure for table 'login_attempts'
#
DROP TABLE IF EXISTS `nagiosna_login_attempts`;
CREATE TABLE IF NOT EXISTS `nagiosna_login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Table structure for table 'cmdsubsys'
#
DROP TABLE IF EXISTS `nagiosna_cmdsubsys`;
CREATE TABLE IF NOT EXISTS `nagiosna_cmdsubsys` (
  `id` varchar(30) NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `command` int(11) unsigned NOT NULL,
  `args` TEXT,
  `processing` tinyint(1) unsigned DEFAULT 0,
  `completed` tinyint(1) unsigned DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Table for user metadata storage
#
DROP TABLE IF EXISTS `nagiosna_usermeta`;
CREATE TABLE IF NOT EXISTS `nagiosna_usermeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Tables for alerting commands
#

DROP TABLE IF EXISTS `nagiosna_ChecksCmdLinker`;
CREATE TABLE IF NOT EXISTS `nagiosna_ChecksCmdLinker` (
    `cid` INT NOT NULL,
    `cmdid` INT NOT NULL,
    PRIMARY KEY(`cid`, `cmdid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `nagiosna_Commands`;
CREATE TABLE IF NOT EXISTS `nagiosna_Commands` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200),
    `location` TEXT,
    `script` VARCHAR(200),
    `arguments` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Generate the migrations table right away
#
DROP TABLE IF EXISTS `nagiosna_migrations`;
CREATE TABLE IF NOT EXISTS `nagiosna_migrations` (
    `version` INT(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `nagiosna_migrations` (`version`) VALUES (5);