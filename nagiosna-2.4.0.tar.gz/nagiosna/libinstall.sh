#
# libinstall.sh - common functions for installing Nagios software
#

# To use, simply put this file into the same directory as your install file.
# Then add this to the top of your install script:
#     cd $(dirname $(readlink -e "$0"))
#     . ./libinstall.sh
# (The cd command ensures your script is run from the install directory so the
# library can be found, and readlink ensures this works even with symlinks.)
# This library will then automatically run some standard checks for you like
# making sure it's run as root, making sure RHEL systems are registered, etc.
# It will also detect various information about the OS and make that available
# in global variables (see the set_os_info function for the list of variables).
#
# Write your installation steps either as functions or separate scripts. Then
# create a fullinstall function that puts it all together by passing those
# steps to the run_steps wrapper function, which will take care of some error
# handling and progress output. Finally, pass your fullinstall function to the
# log_it wrapper function, which will log the output of the installer to the
# specified file.


# Exit immediately if an untested command fails
set -e

# Global environment variable that determines whether to prompt the user for various information or not
export INTERACTIVE="True"

# Wrapper function for running installation steps
run_steps() {
	local traps
	traps=$(trap)

	for step; do
		# Set trap to print error msg if step fails
		trap "step_error $step" 0

		echo "Running '$step'..."

		if [ -f "installed.$step" ] || [ -f "installed.all" ]; then
			echo "$step step already completed - skipping"

			# Reset traps
			eval "$traps"

			continue
		fi

		"$step"

		echo "$step step completed OK"
		touch "installed.$step"
	done

	# Reset traps
	eval "$traps"

	touch installed.all
	for step; do
		rm -f "installed.$step"
	done
}

# Gets run automatically when an installation step fails
step_error() {
	cat >&2 <<-EOF

		===================
		INSTALLATION ERROR!
		===================
		Installation step failed - exiting.
		Check for error messages in the install log (install.log).

		If you require assistance in resolving the issue, please include install.log
		in your communications with Nagios Enterprises technical support.

		The step that failed was: '$1'
	EOF
}

# Wrapper function for capturing and logging stdout & stderr of another command
# First argument is the log file, followed by the command to run
log_it() {
	log="$1"
	shift
	"$@" 2>&1 | tee -a "$log"
}

# Print installation header text. Takes one argument - the name of the product.
print_header() {
	local product
	product="$1"

	cat <<-EOF

		$product Installation
		$(echo $product Installation | sed 's/./=/g')
		DATE: $(date)
	
		DISTRO INFO:
		$distro
		$version
		$architecture

	EOF
}

# Print installation footer text. Takes two arguments - the name of the product
# and optionally the web server path to the web interface.
print_footer() {
	local product path
	product="$1"
	path="$2"

	echo
	echo "$product Installation Success!"
	echo

	get_ip

	if [ -n "$path" ]; then
		echo "You can finish the final setup steps for $product by visiting:"
		echo "    http://$ip/$path/"
		echo
	fi
}

# Get the IP address of the specified device (or eth0 if none specified)
get_ip() {
	if [ "$dist" == 'el7' ] || [ "$distro" == "Ubuntu" ] || [ "$distro" == "Debian" ]; then
		ip=$(ip addr | grep global | grep -m 1 'inet' | awk '/inet[^6]/{print substr($2,0)}' | sed 's|/.*||')
	else
		ip=$(ifconfig | egrep -1 eth[0-9] | grep -m 1 'inet' | awk '/inet[^6]/{print substr($2,6)}')
	fi
	if [ "$ip" == "" ];then
		ip="<HOSTNAME>"
	fi
}

# Convenience function for printing errors and exiting
error() {
	echo "ERROR:" "$@" >&2
	return 1
}

# Return successfully only if the specified RPM packages are installed
is_installed() {
	for pkg; do
		rpm -q "$pkg" &>/dev/null
	done
}

# Adds the specified repo to the system package manager. Can be one of:
#     epel, cr (centos' continuous release repo)
add_yum_repo() {
	local repo url pkg
	repo="$1"

	# See if we need to install the repo...
	if is_installed "$repo-release"; then
		echo "$repo-release RPM installed OK"
		return 0
	fi

	echo "Enabling $repo repo..."

	case "$repo" in
		epel )
			pkg="epel-release-latest-$ver.noarch.rpm"
            url="https://assets.nagios.com/epel/$pkg"
			;;
		cr )
			if [ "$dist" = "el6" ] && is_installed centos-release; then
				yum -y install centos-release-cr
			fi
	esac

	if [ -n "$url" ] && [ -n "$pkg" ]; then
		curl -L -O "$url"
		rpm -Uvh "$pkg"
		rm "$pkg"
	fi

	yum check-update || true

	# Check to make sure RPM was installed
	if is_installed "$repo-release"; then
		echo "$repo-release RPM installed OK"
	else
		error "$repo-release RPM was not installed - exiting."
	fi
}

# Adds specified user if it doesn't exist already
add_user() {
	local user
	user="$1"

	if ! grep -q "^$user:" /etc/passwd; then
		case "$dist" in
			el* )
				useradd -n "$user"
				;;
			* )
				useradd "$user"
		esac
	fi

    # Add user home folder if it doesn't already exist
    if [ ! -d "/home/$user" ]; then
        mkdir "/home/$user"
        chown $user:$user "/home/$user"
    fi
}

# Adds specified group if it doesn't exist already
add_group() {
	local group
	group="$1"

	if ! grep -q "^$group:" /etc/group; then
		groupadd "$group"
	fi
}

# Adds user to the specified groups
add_to_groups() {
	local user
	user="$1"

	shift
	for group; do
		usermod -a -G "$group" "$user"
	done
}

# Prompt the user for a custom MySQL password and sets the mysqlpass variable
prompt_mysqlpass() {
	local pass

	# Check Mysql root password if MySQL is already installed and running...
	if ! service "$mysqld" status &>/dev/null; then
		echo "MySQL not running or not yet installed - that's okay."
		return 0
	fi

	# Test for null or specified MySQL root password
	if mysqlshow -u root ${mysqlpass:+"-p$mysqlpass"} &>/dev/null; then
		:
	# Test for default XI MySQL root password
	elif mysqlshow -u root -pnagiosxi &>/dev/null; then
		mysqlpass="nagiosxi"
	elif [ "$INTERACTIVE" = "True" ]; then
		for i in 1 2 3; do
			echo "Enter the MySQL root password to continue..."
			stty -echo
			read -r -p "MySQL Root Password: " pass
			echo
			stty echo

			# Test the password
			if mysqlshow -u root ${pass:+"-p$pass"} &>/dev/null; then
				echo "Password validated."
				mysqlpass="$pass"
				break
			elif [ "$i" -eq 3 ]; then
				error "password failed."
			else
				echo "Password failed."
			fi
		done
	else
		error "could not connect to MySQL server. Invalid credentials?"
	fi
}

# Set the PHP timezone on RHEL-based systems
php_timezone() {
	local ZONE

	# Grab timezone from OS configuration (sets $ZONE)
	if [ "$dist" == "el7" ]; then
		ZONE=$(timedatectl | sed -n 4p | awk -F'Timezone: ' '{print $2}' | awk -F'(' '{print $1}' | sed 's/ *$//')
	else
		if [ -r /etc/sysconfig/clock ]; then
			. /etc/sysconfig/clock
		fi
	fi

	# Set timezone if possible
	sed -i "s:^;date\.timezone =$:date.timezone = $ZONE:" "$phpini" || true
}

# Install SourceGuardian PHP extension
install_sourceguardian() {
	local phpver ixedfile entry zipfile

	# Get PHP version
	phpver=$(php -v | head -n 1 | cut -d ' ' -f 2 | cut -d . -f 1,2)

	ixedfile="ixed.$phpver.lin"
	entry="extension=$ixedfile"

	if [ "$arch" = "x86_64" ]; then
		zipfile="sourceguardian/ixed4.lin.x86-64.zip"
	else
		zipfile="sourceguardian/ixed4.lin.x86-32.zip"
	fi

    # Make sure we are using the exact php extension dir
	if [ `command -v php-config` ]; then
		php_extension_dir=$(php-config --extension-dir)
	fi

	# Extract SourceGuardian extension to the proper directory
	unzip -o "$zipfile" "$ixedfile" -d "$php_extension_dir"

	if [ -f "$php_extension_dir/$ixedfile" ]; then
		echo "Sourceguardian extension found for PHP version $phpver"
	else
		error "No valid Sourceguardian extension found for PHP" \
			"version $phpver"
	fi

	if grep -q "$entry" "$phpini" "$phpconfd"/*; then
		echo "Sourceguardian extension already in php.ini"
	else
		echo "Adding Sourceguardian extension to php.ini"
		echo "$entry" > "$phpconfd/sourceguardian.ini"
	fi

	# Add to the CLI ini file if it exists (debian systems)
	if [ $phpcliini ]; then
		if grep -q "$entry" "$phpcliini"; then
			echo "Sourceguardian extension already in php.ini"
		else
			echo "Adding entry to PHP CLI php.ini file"
			echo "$entry" > "$phpcliini"
		fi
	fi
}

# Open the specified TCP ports
open_tcp_ports() {
	local chain rulenum

	if [ "$dist" == "el7" ]; then
		if [ `command -v firewalld` ]; then
			set +e
			for port; do
				firewall-cmd --zone=public --add-port="${port/:/-}"/tcp --permanent
			done
			firewall-cmd --reload
			set -e
		fi
	else
		# determine information for the rules
		chain=$(iptables -L | awk '/^Chain.*INPUT/ {print $2; exit(0)}')
		rulenum=$((`iptables -L $chain | wc -l` - 2))

		# test to make sure we aren't using less than the minimum 1
		if [ $rulenum -lt 1 ]; then rulenum=1; fi

		# add the rules
		for port; do
			iptables -I "$chain" "$rulenum" -m state --state NEW -m tcp \
				-p tcp --dport "$port" -j ACCEPT
		done

		# save changes
		service iptables save
		service iptables restart
	fi
}

# Open the specified UDP ports
open_udp_ports() {
    local chain rulenum

    if [ "$dist" == "el7" ]; then
        if [ `command -v firewalld` ]; then
            set +e
            for port; do
                firewall-cmd --zone=public --add-port="${port/:/-}"/udp --permanent
            done
            firewall-cmd --reload
            set -e
        fi
    else
        # determine information for the rules
        chain=$(iptables -L | awk '/^Chain.*INPUT/ { print $2; exit(0)}')
        rulenum=$((`iptables -L $chain | wc -l` - 2))

        # test to make sure we aren't using less tha n the minimum 1
        if [ $rulenum -lt 1 ]; then rulenum=1; fi

        # add the rules
        for port; do
            iptables -I "$chain" "$rulenum" -m state --state NEW -m udp \
                     -p udp --dport "$port" -j ACCEPT
        done
            
        # save changes
        service iptables save
        service iptables restart
    fi
}

# Disable SELinux on RHEL-based systems
disable_selinux() {
	if selinuxenabled; then
		setenforce 0
		cat >/etc/selinux/config <<-EOF
			# This file controls the state of SELinux on the system.
			# SELINUX= can take one of these three values:
			#     enforcing - SELinux security policy is enforced.
			#     permissive - SELinux prints warnings instead of enforcing.
			#     disabled - No SELinux policy is loaded.
			SELINUX=disabled
			# SELINUXTYPE= can take one of these two values:
			#     targeted - Targeted processes are protected,
			#     mls - Multi Level Security protection.
			SELINUXTYPE=targeted
			# SETLOCALDEFS= Check local definition changes
			SETLOCALDEFS=0
		EOF
	fi
}

# Enable services at boot and make sure it's running
rc() {
	for svc; do
		if [ "$dist" == "el7" ]; then
			if [ "$svc" == "nagiosna" ]; then
				cp nagiosna.service /lib/systemd/system/nagiosna.service
			fi
			systemctl enable "$svc"
			systemctl restart "$svc"
		else
			chkconfig --level  345 "$svc" on
			chkconfig --level 0126 "$svc" off
		fi
	done
}

# If the system is Red Hat, make sure it's registered & has the appropriate
# channels enabled.
valid_rhel() {
	if [ -x /usr/sbin/rhn_check ] && ! /usr/sbin/rhn_check 2>/dev/null; then
		if [ -x /usr/bin/subscription-manager ] && [[ ! -z $(subscription-manager list | grep Status: | grep -qF Subscribed) ]]; then
			error "your Red Hat installation is not registered or does" \
				  "not have proper entitlements. Please register or" \
				  "enable entitlements at rhn.redhat.com."
		fi
	fi
}

# If the system is Red Hat, make sure it's subscribed to the specified channel.
# The first argument is a regexp to match the channel's label (e.g.
# rhel-.*-server-optional-6). The second argument is a human readable name for
# the channel (e.g. Optional).
has_rhel_channel() {
	if [ "$distro" = "RedHatEnterpriseServer" ] && ! rhn-channel -l | grep -q "$1"; then
		error "please add the '$2' channel to your Red Hat systems" \
			"subscriptions. You can do so in the Red Hat Network" \
			"web interface or by using the rhn-channel command."
	fi
}

# Run some standard checks - root user check, $PATH variable, RHEL validation
std_checks() {
	path_is_ok() {
		echo "$PATH" \
		| awk 'BEGIN{RS=":"} {p[$0]++} END{if (p["/sbin"] && p["/usr/sbin"]) exit(0); exit(1)}'
	}

	if [ $(id -u) -ne 0 ]; then
		error "This script needs to be run as root/superuser."
	fi

	valid_rhel

	if ! path_is_ok; then
		echo "Your system \$PATH does not include /sbin and" \
			"/usr/sbin. This is usually the result of installing" \
			"GNOME rather than creating a clean system."
		echo "Adding /sbin and /usr/sbin to \$PATH."
		PATH="$PATH:/sbin:/usr/sbin"
	fi
	unset -f path_is_ok
}

build_nfdump() {
	(
		cd subcomponents
		tar xf nfdump-1.6.16.tar.gz
		cd nfdump-1.6.16
		./configure --enable-sflow --enable-nsel
		make
		make install
		cd ..
		rm -rf nfdump-1.6.16
	)
}

build_rrdtool() {
    (
        cd subcomponents
        tar xf rrdtool-1.7.0.tar.gz
        cd rrdtool-1.7.0
        mkdir -p /root/.python-eggs
        ./configure --prefix=/usr/local --disable-perl
        make
        make install
        # Install python (and ignore temp file location perm warn)
        make site-python-install &>/dev/null
        cd ..
        rm -rf rrdtool-1.7.0
    )
}

# Detect OS & set global variables for other commands to use.
# OS variables have a detailed long variable, and a "more useful" short one:
# distro/dist, version/ver, architecture/arch. If in doubt, use the short one.
set_os_info() {
	if [ `uname -s` != "Linux" ]; then
		error "Unsupported OS detected. Can currently only detects" \
			"Linux distributions."
	fi

	# Get OS & version
	if which lsb_release &>/dev/null; then
		distro=`lsb_release -si`
		version=`lsb_release -sr`
	elif [ -r /etc/redhat-release ]; then

		if rpm -q centos-release; then
			distro=CentOS
		elif rpm -q sl-release; then
			distro=Scientific
		elif [ -r /etc/oracle-release ]; then
			distro=OracleServer
		elif rpm -q cloudlinux-release; then
			distro=CloudLinux
	    elif rpm -q fedora-release; then
			distro=Fedora
		elif rpm -q redhat-release || rpm -q redhat-release-server; then
			distro=RedHatEnterpriseServer
		fi >/dev/null

		version=`sed 's/.*release \([0-9.]\+\).*/\1/' /etc/redhat-release`
	else
		# Release is not RedHat or CentOS, let's start by checking for SuSE
		# or we can just make the last-ditch effort to find out the OS by sourcing os-release if it exists
		if [ -r /etc/os-release ]; then
			source /etc/os-release
			if [ -n "$NAME" ]; then
				distro=$NAME
				version=$VERSION_ID
			fi
		fi
	fi

	# Add patch for Debian which changed NAME on us...
	if [[ $distro == *"Debian"* ]]; then
		distro="Debian"
	fi

	# Add patch level to the version of SLES (because they don't...)
	if [ "$distro" == "SUSE LINUX" ]; then
		if [ -r /etc/SuSE-release ]; then
			patchlevel=$(cat /etc/SuSE-release | cut -d ' ' -f 3 -s | sed -n 3p)
			version="$version.$patchlevel"
		fi
	fi

	# Verify that we have a distro now
	if [ -z "$distro" ]; then
		echo "ERROR: Could not determine OS. Please make sure lsb_release is installed or your OS info is in /etc/os-release." >&2
		exit 1
	fi

	ver="${version%%.*}"

	case "$distro" in
		CentOS | RedHatEnterpriseServer | OracleServer | CloudLinux )
			dist="el$ver"
			;;
		Debian )
			dist="debian$ver"
			;;
		* )
			dist=$(echo "$distro$ver" | tr A-Z a-z)
	esac

	architecture=`uname -m`

	# i386 is a more useful value than i686 for el5, because repo paths and
	# package names use i386
	if [ "$dist $architecture" = "el5 i686" ]; then
		arch="i386"
	else
		arch="$architecture"
	fi

	httpd='httpd'
	mysqld='mysqld'

	apacheuser='apache'
	apachegroup='apache'
	nagiosuser='nagios'
	nagiosgroup='nagios'
	nagioscmdgroup='nagcmd'

	phpini='/etc/php.ini'
	phpconfd='/etc/php.d'
	httpdconfdir='/etc/httpd/conf.d'
	mrtgcfg='/etc/mrtg/mrtg.cfg'
	mibsdir='/usr/share/snmp/mibs'

	# This is set later by php-config if possible
	php_extension_dir='/usr/lib64/php/modules'

	case "$dist" in
		el5 | el6 | el7 )
			if [ "$dist" == "el7" ]; then
				mysqld="mariadb"
			fi
			;;
		ubuntu14 | ubuntu16 | ubuntu18 | debian7 | debian8 | debian9 )
			if [ "$dist" == "ubuntu18" ]; then
				phpini="/etc/php/7.2/apache2/php.ini"
                phpconfd="/etc/php/7.2/apache2/conf.d"
                phpconfdcli="/etc/php/7.2/cli/conf.d"
                phpcliini="/etc/php/7.2/cli/php.ini"
            elif [ "$dist" == "ubuntu16" ] || [ "$dist" == "debian9" ]; then
                phpini="/etc/php/7.0/apache2/php.ini"
                phpconfd="/etc/php/7.0/apache2/conf.d"
                phpconfdcli="/etc/php/7.0/cli/conf.d"
                phpcliini="/etc/php/7.0/cli/php.ini"
            else
                phpini="/etc/php5/apache2/php.ini"
                phpconfd="/etc/php5/apache2/conf.d"
                phpconfdcli="/etc/php5/cli/conf.d"
                phpcliini="/etc/php5/cli/php.ini"
            fi
			mibsdir="/usr/share/mibs"
			httpdconfdir="/etc/apache2/sites-available"
            apacheuser="www-data"
            apachegroup="www-data"
          	httpdconf="/etc/apache2/apache2.conf"
            httpdroot="/var/www/html"
            
			httpd="apache2"
            ntpd="ntp"
            crond="cron"
            mysqld="mysql"
			;;
	esac
}

# Get curent php version 5.3 or higher
# - The $phpversion value will equal 1 if PHP >= 5.3.0
get_php53_or_higher() {
	phpversion=$(php -r "print version_compare(PHP_VERSION, '5.3.0');")
}

# Currently supporting:
#	CentOS / RHEL / Orcale / CloudLinux 6, 7
#
# Will install on:
# 	Ubuntu 14, 16, 18 (LTS ONLY)
#	Debian 7, 8, 9
#
# No longer supported:
#	CentOS / RHEL 5
#
# Checks if the system is able to be installed on
do_install_check() {

	# Check if NNA is already installed
	if [ -d "/usr/local/nagiosna" ]; then
		echo "It looks like Nagios Network Analyzer is already installed." >&2
		exit 1
	fi

	# Check valid versions
	if [ "$dist" == "el5" ]; then
		echo "" >&2
		echo "CentOS / RHEL 5 is not supported." >&2
		echo "" >&2
		exit 1
	elif [ "$dist" == "el6" ] || [ "$dist" == "el7" ]; then
		echo "Installing on $distro $version"
	elif [ "$dist" == "ubuntu14" ] || [ "$dist" == "ubuntu16" ] || [ "$dist" == "ubuntu18" ]; then
		echo "Installing on $distro $version"
	elif [ "$dist" == "debian7" ] || [ "$dist" == "debian8" ] || [ "$dist" == "debian9" ]; then
		echo "Installing on $distro $version"
	else
		echo "" >&2
		echo "$dist is not currently supported. Please use one of the following distros:" >&2
        echo "  CentOS, RHEL, Oracle 6 or 7" >&2
        echo "  Ubuntu 14, 16, or 18 LTS" >&2
        echo "  Debian 7, 8 or 9" >&2
        echo "" >&2
		exit 1
	fi

}

# Checks to verify that the upgrade can be performed
do_upgrade_check() {

	# Check if NNA is already installed
	if [ ! -d $proddir ]; then
		echo "Could not find an installed version of Nagios Network Analyzer."
		exit 0
	fi

	# Check php version > 5.3.0
	get_php53_or_higher

	# Do check for CentOS/RHEL 5 (no longer supported unless PHP is upgraded)
	if [ $phpversion -ne 1 ] && [ "$dist" == "el5" ]; then
		echo ""
		echo "CentOS / RHEL 5"
		echo "---------------"
		echo "Nagios Network Analyzer 2.3 and above requires PHP 5.3 or higher"
		echo ""
		echo "If you want to continue upgrades for this OS you must install"
		echo "PHP version 5.3, 5.4, 5.5, 5.6, 7.0, 7.1, or 7.2 and these modules:"
		echo "php, php-common, php-ldap"
		echo ""
		exit 0
	fi

}

# Initialize installation - run basic checks and detect OS info
set_os_info
std_checks
