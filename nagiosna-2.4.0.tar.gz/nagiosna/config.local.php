<?php 
/* local configuration options */

// database configuration
$config['db']['hostname'] = 'localhost';
$config['db']['username'] = 'nagiosna';
$config['db']['password'] = 'nagiosna';
$config['db']['database'] = 'nagiosna';
$config['db']['db_debug'] = 'TRUE';
$config['db']['dbdriver'] = 'mysqli';
$config['db']['dbprefix'] = 'nagiosna_';

$config['nfdump'] = '/usr/local/bin/nfdump';

// admin email (used as 'from' for system emails)
$config['admin_email'] = 'nagiosna@localhost';

// make sure this is unique and difficult to guess
//$config['encryption_key'] = 'somethingsecret';
$config['encryption_key'] = sha1($_SERVER['HTTP_HOST']);

// base url of site
$config['site_url'] = '//'.$_SERVER['HTTP_HOST'].'/nagiosna';

// where to find media files
$config['media_url'] = $config['site_url'] .'/media';

