#!/bin/sh
#
# Bash script for resetting the 'nagiosadmin' user password
# Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved.
#
# Resets the nagiosadmin user password by replacing the hash in the db.
#

newpass=''

# Dispaly how to use
usage () {
    echo ""
    echo "Use this script to reset the nagiosadmin password in Nagios Network Analyzer."
    echo " -p           The password to set the nagiosadmin's password to."
    echo ""
    echo "Exmaple: ./reset_nagiosadmin_password.sh -p testpass"
    echo ""
}

# Grab the new password or display usage
while [ -n "$1" ]; do
    case "$1" in
        -h | --help)
            usage
            exit 0
            ;;
        -p | --password)
            newpass=$2
            ;;
    esac
    shift
done

if [ "$newpass" == '' ]; then
    echo "You must enter a password."
    usage
    exit 1
fi

# Verify that elasticsearch is running
if service mysqld status | grep -q 'stopped'; then
    echo "Error: MySQL must be running."
    exit 1
fi

# Create a new salt
salt=$(echo $RANDOM | openssl sha1)
salt=${salt:9}
salt=${salt:0:10}

# Generate a new hashed password
passhash=$(echo -n "$salt$newpass" | openssl sha1)
passhash=${passhash:9}
passhash=$salt${passhash:0:${#passhash}-10}

sql="USE nagiosna; UPDATE nagiosna_users SET password = '$passhash' WHERE id = 1;"
mysql -u nagiosna -pnagiosna -e "$sql"

echo "The password has been set for nagiosadmin user."
