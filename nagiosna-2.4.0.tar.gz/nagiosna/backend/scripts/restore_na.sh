#!/bin/bash
#
# Bash script for restoring Nagios Network Analyzer
# Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved.
#
# Restores a backup of Nagios Network Analyzer
#

# Make sure we have the backup file
if [ $# != 1 ]; then
	echo "Usage: $0 <backupfile>"
	echo "This script restores your Nagios Network Analyzer system using a previously made Nagios NA backup file."
	echo "Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved."
	exit 1
fi

# Get file name without extention
backupfilefull=$1
backupfile=${backupfilefull%%.*}
ROOTDIR="/store/backups/nagiosna"
BASEDIR=$(dirname $0)

# Import the Nagios Network Analyzer config vars
eval $(php $BASEDIR/import_naconfig.php)

# MySQL root password
mysqlpass="nagiosna"

# Must be root
me=`whoami`
if [ $me != "root" ]; then
	echo "You must be root to run this script."
	exit 1
fi

##############################
# MAKE SURE BACKUP FILE EXIST
##############################
if [ ! -f $backupfilefull ]; then
	echo "Unable to find backup file $backupfilefull!"
	exit 1
fi

##############################
# MAKE TEMP RESTORE DIRECTORY
##############################
ts=`date +%s`
echo "TS=$ts"
mydir=${ROOTDIR}/${ts}-restore
mkdir -p $mydir
cp -f $backupfilefull $mydir
if [ ! -d $mydir ]; then
	echo "Unable to create restore directory $mydir!"
	exit 1
fi

##############################
# UNZIP BACKUP
##############################
echo "Extracting backup to $mydir..."
cd $mydir
tar xzfps $backupfilefull

# Change to subdirectory
cd `ls`

# Make sure we have at least the flows tarball in here...
backupdir=`pwd`
echo "In $backupdir..."
if [ ! -f $backupdir/nagiosna-flows.tar.gz ]; then
	echo "Unable to find flow files to restore in $backupdir"
	exit 1
fi

echo "Backup files look okay.  Preparing to restore..."


##############################
# SHUTDOWN SERVICES
##############################
echo "Shutting down services..."
/etc/init.d/nagiosna stop

##############################
# RESTORE DIRS
##############################
flowdir=/usr/local/nagiosna/var/

echo "Restoring flow files to ${flowdir}..."
cd $flowdir && tar xzfps $backupdir/nagiosna-flows.tar.gz


##############################
# RESTORE DATABASES
##############################

echo "Restoring MySQL databases..."

mysql -h $config__db__hostname -u nagiosna --password=$mysqlpass < $backupdir/mysql/nagiosna.sql
res=$?
if [ $res != 0 ]; then
	echo "Error restoring MySQL database 'nagiosna' - check the password in this script!"
	exit;
fi

echo "Restarting database servers..."
service mysqld restart

##############################
# RESTORE CRONJOB ENTRIES
##############################
# Not necessary

##############################
# RESTORE SUDOERS
##############################
# Not necessary

##############################
# RESTORE LOGROTATE
##############################

##############################
# RESTORE APACHE CONFIG FILES
##############################
echo "Restoring Apache config files..."
cp -rp $backupdir/httpd/*.conf /etc/httpd/conf/

##############################
# RESTART SERVICES
##############################
/etc/init.d/nagiosna start

##############################
# DELETE TEMP RESTORE DIRECTORY
##############################

rm -rf $mydir

echo " "
echo "==============="
echo "RESTORE COMPLETE"
echo "==============="

exit 0;