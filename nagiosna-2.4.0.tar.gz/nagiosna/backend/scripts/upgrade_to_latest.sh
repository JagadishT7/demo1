#!/bin/sh -e
#
# Automatic Upgrade Script
# Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved.
#
# Automatically upgrades the Nagios Network Analyzer script to the latest version
# available online.
#

PATH=$PATH:/sbin:/usr/sbin
TS=$(date +%s)
error=false

checkerrors () {
	"$@"
	if [ $? -ne 0 ]; then
		error=true
	fi
}

###############################
# USAGE / HELP
###############################
usage () {
	echo ""
	echo "Use this script to upgrade your Nagios Network Analyzer instance to the latest version."
	echo "Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved."
	echo ""
	echo " -t | --time             	Send a timestamp for the log to be renamed as once finished"
	echo " -f | --file              The filename/url/location of the nna update"
	echo ""
}

###############################
# GET THE VARIABLES
###############################
while [ -n "$1" ]; do
	case "$1" in
		-h | --help)
			usage
			exit 0
			;;
		-t | --time)
			TS=$2
			;;
		-f | --file)
			FILE=$2
			;;
	esac
	shift
done

# Create a log file
rm -rf /usr/local/nagiosna/tmp/upgrade.log
touch /usr/local/nagiosna/tmp/upgrade.log
chown nna:nnacmd /usr/local/nagiosna/tmp/upgrade.log

# Backup NNA before upgrade
#echo "---- Starting Nagios Network Analyzer Backup ----" > /usr/local/nagiosna/tmp/upgrade.log
#cd /usr/local/nagiosna/scripts
#./backup_nna.sh -p autoupgrade_backup >> /usr/local/nagiosna/tmp/upgrade.log 2>&1

# Perform upgrade
echo "" >> /usr/local/nagiosna/tmp/upgrade.log
echo "---- Starting Nagios Network Analyzer Upgrade ----" >> /usr/local/nagiosna/tmp/upgrade.log
echo "Cleaning up temp directory..." >> /usr/local/nagiosna/tmp/upgrade.log
cd /usr/local/nagiosna/tmp
rm -rf nagiosna nagiosna-*.tar.gz
echo "Downloading Latest Nagios Network Analyzer Tarball..." >> /usr/local/nagiosna/tmp/upgrade.log
wget "$FILE"
tar xzf nagiosna-*.tar.gz
cd nagiosna

checkerrors ./upgrade -n >> /usr/local/nagiosna/tmp/upgrade.log 2>&1
if $error ; then
	FN="failed.$TS"
else
	FN="success.$TS"
fi

# Make log directory if it doesnt exist and give proper permissions for apache to be able to read it
if [[ ! -e /usr/local/nagiosna/var/upgrades ]]; then
	mkdir -p /usr/local/nagiosna/var/upgrades
	chown apache:nnacmd /usr/local/nagiosna/var/upgrades
	chmod 754 /usr/local/nagiosna/var/upgrades
	chmod +x /usr/local/nagiosna/var/upgrades
fi

# Copy over the file and give error or not
cp /usr/local/nagiosna/tmp/upgrade.log /usr/local/nagiosna/var/upgrades/$FN.log
chown -R apache:nnacmd /usr/local/nagiosna/var/upgrades
chmod 644 /usr/local/nagiosna/var/upgrades/$FN.log