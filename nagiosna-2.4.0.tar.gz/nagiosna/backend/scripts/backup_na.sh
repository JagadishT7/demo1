#!/bin/bash
#
# Bash script for creating a backup of Nagios Network Analyzer
# Copyright 2014-2017 - Nagios Enterprises, LLC. All Rights reserved.
#
# Creates a full backup of Nagios Network Analyzer
#

BASEDIR=$(dirname $0)

# Import the Nagios Network Analyzer config vars
eval $(php $BASEDIR/import_naconfig.php)

ts=`date +%s`

###############################
# USAGE / HELP
###############################
usage () {
    echo ""
    echo "Use this script to backup Nagios Network Analyzer."
    echo ""
    echo " -n | --name              Set the name of the backup minus the .tar.gz"
    echo " -p | --prepend           Prepend a string to the .tar.gz name"
    echo " -a | --append            Append a string to the .tar.gz name"
    echo " -d | --directory         Change the directory to store the compressed backup"
    echo ""
}

###############################
# ADDING LOGIC FOR NEW BACKUPS
###############################
while [ -n "$1" ]; do
    case "$1" in
        -h | --help)
            usage
            exit 0
            ;;
        -n | --name)
            fullname=$2
            ;;
        -p | --prepend)
            prepend=$2"."
            ;;
        -a | --append)
            append="."$2
            ;;
        -d | --directory)
            rootdir=$2
            ;;
    esac
    shift
done

if [ -z $rootdir ]; then
    rootdir="/store/backups/nagiosna"
fi

# Move to root dir to store backups
cd $rootdir

#############################
# SET THE NAME & TIME
#############################
name=$fullname

if [ -z $fullname ]; then
    name=$prepend$ts$append
fi

# Get current Unix timestamp as name
if [ -z $name ]; then
    name=$ts
fi

# My working directory
mydir=$rootdir/$name

# Make directory for this specific backup
mkdir -p $mydir

##############################
# BACKUP DIRS
##############################

echo "Backing up Flows directory..."
mkdir $mydir/var

cp -rp /usr/local/nagiosna/var/. $mydir/var

# Remove non-dirs
find $mydir/var -maxdepth 1 -type f -delete

# Compress flows
cd $mydir
tar czpf nagiosna-flows.tar.gz -C var .
rm -rf var

# Bring version file along for the ride
cp /var/www/html/nagiosna/naversion $mydir

##############################
# BACKUP DATABASES
##############################

echo "Backing up MySQL databases..."
mkdir -p $mydir/mysql

mysqldump -h $config__db__hostname -u $config__db__username --password="$config__db__password" --add-drop-database -B $config__db__database > $mydir/mysql/nagiosna.sql
res=$?
if [ $res != 0 ]; then
    echo "Error backing up MySQL database $config__db__database - check the password in this script!"
    exit $res;
fi

##############################
# BACKUP CRONJOB ENTRIES
##############################
# Not necessary

##############################
# BACKUP SUDOERS
##############################
# Not necessary

##############################
# BACKUP LOGROTATE
##############################
# Not necessary

##############################
# BACKUP APACHE CONFIG FILES
##############################
echo "Backing up Apache config files..."
mkdir -p $mydir/httpd
cp -rp /etc/httpd/conf.d/nagiosna.conf $mydir/httpd

##############################
# COMPRESS BACKUP
##############################
echo "Compressing backup..."

# Move back to backup directory
cd $rootdir
tar czpf $name.tar.gz $name
rm -rf $name

chown nna:nnacmd $name.tar.gz
chmod 0664 $name.tar.gz

if [ -s $name.tar.gz ];then

    echo " "
    echo "==============="
    echo "BACKUP COMPLETE"
    echo "==============="
    echo "Backup stored in $rootdir/$name.tar.gz"

    exit 0;
else
    echo " "
    echo "==============="
    echo "BACKUP FAILED"
    echo "==============="
    echo "File was not created at $rootdir/$name.tar.gz"

    exit 1;
fi
