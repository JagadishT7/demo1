<?php 
header('Location: nagiosna/');
?>