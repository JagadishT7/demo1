
function get_human_friendly_date(nfdump_date)
{
    var datetime = nfdump_date.split('.');
    var sd = datetime[0].split('/');
    
    var sd = sd[1] + "/" + sd[2] + "/" + sd[0];
    var readable = sd + " " + datetime[1];
    
    return readable;
}

function reset_all() {
    $('input[name="loaded_id"]').val('');
        
    name.val('');
    $('#test').html('');
    $('#test-name').html('');
}

function human_readable_headers(header) {        
    switch (header) {
        case 'start':
            return 'Start Date';
        case 'end':
            return 'End Date';
        case 'duration':
            return 'Duration';
        case 'protocol':
            return 'Protocol';
        case 'srcip':
            if (resolve_hosts) { return 'Source Hostname'; }
            return 'Source IP';
        case 'dstip':
            if (resolve_hosts){ return 'Destination Hostname'; }
            return 'Destination IP';
        case 'srcport':
            return 'Source Port';
        case 'dstport':
            return 'Destination Port';
        case 'flows':
            return 'Flows';
        case 'flowspercent':
            return 'Flow %';
        case 'bytes':
            return 'Bytes';
        case 'bytespercent':
            return 'Byte %';
        case 'packets':
            return 'Packets';
        case 'packetspercent':
            return 'Packet %';
        case 'pps':
            return 'Packets/Sec';
        case 'bps':
            return 'Bits/Sec';
        case 'bpp':
            return 'Bytes/Packet';
        default:
            return '';
    }
}
