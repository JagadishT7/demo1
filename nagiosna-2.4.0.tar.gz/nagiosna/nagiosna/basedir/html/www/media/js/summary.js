$(document).ready(function() {

    if (type == 'sid') {
        load_status();
    }

});

function load_tts(begindate, enddate) {
    if (type == 'sid') {
        id = source_id;
    } else if (type == 'gid') {
        id = group_id;
    }

    load_toptalker(1, 'dstip', begindate, enddate);
    load_toptalker(2, 'srcip', begindate, enddate);
    load_toptalker(3, 'dstport', begindate, enddate);
    load_toptalker(4, 'srcport', begindate, enddate);
}

function hash_string(input) {
    var hash = 0,
        i = 0,
        char;
    
    for(i = 0, l = input.length; i < l; i++) {
        char = input.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0;
    }
    
    return hash;
}

function load_toptalker(rid, target, begindate, enddate)
{
    $('.warningbox').hide();
    
    if (begindate != undefined && enddate != undefined) {
        // Do a custom report
        var reporturl   = site_url + 'api/reports/execute_anonymous';
        var reportargs  = { 'q[top]': '5',
                            'q[toporder]': 'bytes',
                            'q[toptype]': target,
                            'q[begindate]': begindate,
                            'q[enddate]': enddate }
    } else {
        var reporturl   = site_url + 'api/reports/execute';
        var reportargs  = { 'q[rid]': rid };
    }

    if (type == 'sid') {
        reportargs['q[sid]'] = source_id;
    } else if (type == 'gid') {
        reportargs['q[gid]'] = group_id;
    }

    if (view_id) {
        reportargs['q[vid]'] = view_id;
    }
        
    $.get(reporturl, reportargs, function(d) {
        if(d.error || d.records.length == 0) {
            $('#tt'+target).html('<tr><td colspan="999">No data found.</td></tr>');
        } else {
            load_tt_div('#tt'+target, d, target);

            // If we are in the wrong raw data lifetime, display the error
            if (d.warning) {
                $('.warningtext').html(d.warning);
                $('.warningbox').show();
            }

        }
    }, 'json');
}

function load_tt_div(target, data, rawtarget) 
{
    var records = data.records;
    
    var toc = records[0];
    var talkers = records.slice(1)
    var subject;
    var complement;

    for (var prop in toc) {
        if (toc[prop] == 'val') {
            subject = prop;
            complement = get_complement(subject);
            break;
        }
    }

    var id = (Math.round(Math.random()*100000000)) + "_bind";

    $(target).empty();
    
    $.each(talkers, function(i, d) {
        var item = talkers[i][subject];
        var bytes = talkers[i]['bytes'];
        var percent = talkers[i]['bytespercent'];
        var hash = Math.abs(hash_string(item))
        var queryurl = get_tt_query_url(subject, complement, item);

        title = "";
        if (resolve_hosts) {
            if (subject == 'srcip') {
                title = item;
                item = talkers[i]['srcdn'];
            } else if (rawtarget == 'dstip') {
                title = item;
                item = talkers[i]['dstdn'];
            }
        }

        html = '<tr><td><a class="lookup" id="' + hash + '" data-toggle="tooltip" title="'+title+'" href="' + queryurl +'">' + item + '</a></td><td style="text-align: center; cursor: default;"><span class="'+id+'" style="display: block;" title="'+human_readable_size(bytes)+'">' + percent + '</span></td></tr>';
        
        $(target).append(html);
    });
    
    $('.'+id).tooltip({ placement: 'left' });

    if (!resolve_hosts) {
        $(target).find('.lookup').each(function(d) {
            var item = $(this).text();
            var node = this;
            $.getJSON(site_url + 'api/system/reverse_lookup/' + item, function(d) {
                $(node).attr("title", d.hostname);
                $(node).attr("data-toggle", "tooltip");
            });
        });
    }
}

function get_tt_query_url(subject, complement, item)
{
    var queryurl;
    if (type == 'sid') {
        queryurl = site_url + 'sources/queries/' + source_id; 
    } else if (type == 'gid') {
        queryurl = site_url + 'groups/queries/' + group_id;
    }
    
    try {
        var modified = $('#source-graph-tp').val().split('|');
    }
    catch(err) {
        var dates = get_correct_datetimes();
        var modified = [];
        modified.push(dates.start);
        modified.push(dates.end);
    }
    var begindate = modified[0];
    var enddate = modified[1];
    
    var query = subject.slice(0, 3) + " " + subject.slice(3);
    
    var queryargs = {   'q[begindate]': begindate,
                        'q[enddate]': enddate,
                        'q[aggregate_csv]': subject + "," + complement,
                        'q[rawquery]': query + " " + item };
    
    
    
    return queryurl + "?" + $.param(queryargs);
}

function get_complement(subject) {
    switch(subject) {
        case 'srcip':
            return 'dstip';
            break;
        case 'dstip':
            return 'srcip';
            break;
        case 'srcport':
            return 'dstport';
            break;
        case 'dstport':
            return 'srcport';
            break;
        default:
            return undefined;
            break;
    }
}

function hc_date_selector(event) {
    var start = Highcharts.dateFormat('%Y/%m/%d.%H:%M:%S', event.xAxis[0].min);
    var end = Highcharts.dateFormat('%Y/%m/%d.%H:%M:%S', event.xAxis[0].max);
    
    var start_epoch = Math.round(event.xAxis[0].min / 1000);
    var end_epoch = Math.round(event.xAxis[0].max / 1000);
    
    var amalgam = start + "|" + end + "|" + start_epoch + "|" + end_epoch;
    
    var range_start = Highcharts.dateFormat('%m/%d/%Y %H:%M', event.xAxis[0].min);
    var range_end = Highcharts.dateFormat('%m/%d/%Y %H:%M', event.xAxis[0].max);

    if($('#source-custom-option').length == 0) {
        $('#source-graph-tp').append('<option id="source-custom-option" value="' + amalgam + '">Date Range</option>');
        $('#range_start').val(range_start);
        $('#range_end').val(range_end);
    } else {
        $("#source-custom-option").attr('value', amalgam);
        $('#range_start').val(range_start);
        $('#range_end').val(range_end);
    }
    
    $('#range-inputs').show();
    $("#source-graph-tp").val(amalgam);
    //~ load_graph(start_epoch, end_epoch, hc_date_selector);
    load_tts(start, end);
    
}

// Generate a graph based on selected data and dispaly
function load_graph(begindate, enddate, selector_func)
{
    loading($('#source-graph'));

    if(begindate == undefined) {
        begindate = '-24 hours';
    }
    if(enddate == undefined) {
        enddate = '-1 second';
    }

    var vars = { begindate: encodeURI(begindate), 
                 enddate: encodeURI(enddate),
                 'q[Bytes]': "bytes", 
                 'q[Flows]': "flows", 
                 'q[Packets]': "packets",
                 'q[Bytes/Sec]': "bps" }

    if (type == 'sid') {
        vars.sid = source_id;
    } else if (type == 'gid') {
        vars.gid = group_id;
    }

    if (view_id) {
        vars.vid = view_id;
    }
    
    $.get(site_url + 'api/graphs/execute', vars, function(data) {
        
        var title = "Bandwidth Graph";
        var text = "Select or deselect the types of data to show on the graph using the legend";
        var series;
        
        if (data.error || data[0].total == 0) {
            title = "No Data Available";
            text = "There is no data available for the currently selected time period.";
            series= [];
        } else {
            series = [{
                name: data[0].name,
                pointInterval: data[0].pointInterval,
                pointStart: data[0].pointStart, 
                data: data[0].data
            },
            {
                name: data[1].name,
                pointInterval: data[1].pointInterval,
                pointStart: data[1].pointStart, 
                data: data[1].data,
                visible: false
            },
            {
                name: data[2].name,
                pointInterval: data[2].pointInterval,
                pointStart: data[2].pointStart, 
                data: data[2].data,
                visible: false
            },
            {
                name: data[3].name,
                pointInterval: data[3].pointInterval,
                pointStart: data[3].pointStart, 
                data: data[3].data,
                visible: false
            }]
        }

        var gb = 1073741824; // bytes
        var mb = 1048576;
        var kb = 1024;

        GRAPH = new Highcharts.Chart({
            chart: {
                type: 'area',
                renderTo: 'source-graph',
                zoomType: 'x',
                events: {
                    selection: selector_func
                },
                resetZoomButton: {
                    theme: {
                        display: 'none'
                    }
                }
            },
            credits: {
                enabled: false
            },
            colors: [
                '#2156c3',
                '#5e8ff6',
                '#2e2929',
                '#3216B0'
            ],
            exporting: {
                enabled: true
            },
            title: {
                text: title
            },
            subtitle: {
                text: text
            },
            xAxis: {
                type: 'datetime',
                title: {
                    text: 'Time'
                }
            },
            yAxis: {
                title: {
                    text: ''
                },
                type: yAxis_type,
                labels: {
                    formatter: function() {
                        var maxElement = this.value;
                        if (maxElement > gb) {
                            return (this.value / gb).toFixed(1) + " G";
                        } else if (maxElement > mb) {
                            return (this.value / mb).toFixed(1) + " M";
                        } else if (maxElement > kb) {
                            return (this.value / kb).toFixed(1) + " K";
                        } else {
                            return (this.value) + " ";
                        }
                    }
                }
            },
            tooltip: {
                formatter: function() {
                        var h = '<b>' + Highcharts.dateFormat('%m/%d/%Y %H:%M', this.x) + '</b>';

                        $.each(this.points, function(i, point) {
                            if (this.series.name == 'Bytes') {
                                var newvalue = ""
                                if (point.y > gb) {
                                    newvalue = (point.y / gb).toFixed(1) + " GB";
                                } else if (point.y > mb) {
                                    newvalue = (point.y / mb).toFixed(1) + " MB";
                                } else if (point.y > kb) {
                                    newvalue = (point.y / kb).toFixed(1) + " KB";
                                } else {
                                    newvalue = (point.y).toFixed(1) + " B";
                                }

                                h += '<br/>' + point.series.name + ': ' + newvalue;
                            } else {
                                h += '<br/>' + point.series.name + ': ' + (point.y).toFixed(0);
                            }
                        });

                        return h;
                    },
                shared: true
            },
            legend: {
                borderWidth: 0
            },
            plotOptions: {
                area: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    }
                }
            },
            series: series
        })

    }, 'json');
}
