
function clear_all()
{
    $('#query_flowdata').hide();
    $('#query_summary').html('');
    $('#title').html('');
    qid = 0;
    $('#ag').val('');
    $('#rawquery').val('');
    set_time_range('-24 hours', '-1 second');
    $('#loaded_query_container').hide();
}

// Render the summary in data to target div
function render_summary(target, summary, title)
{
    $('#title').html("Query: " + title);

    if (summary.totalflows > 0) {
        var html = '<table class="table table-bordered table-striped"><tr><th>Total Bytes</th><th>Total Flows</th><th>Total Packets</th><th>Average Bytes/Packet</th><th>Average Bits/Sec</th><th>Average Packets/Sec</th></tr>';
        html += '<tr><td> ' + human_readable_size(summary.totalbytes) + ' </td>';
        html += '<td>' + human_readable_size(summary.totalflows, true) + '</td>';
        html += '<td>' + human_readable_size(summary.totalpackets, true) + '</td>';
        html += '<td>' + human_readable_size(summary.avgbpp, true) + '</td>';
        html += '<td>' + human_readable_size(summary.avgbps, true) + '</td>';
        html += '<td>' + human_readable_size(summary.avgpps, true) + '</td></tr></table>';
        $(target).html(html);
        $('#query_flowdata').show();
    } else {
        $(target).html('No query data was returned for your query.');
        $('#query_flowdata').hide();
    }
}

// Renders the flow data, takes care of pagination
function initialize_flowdata_div(target, records)
{
    PAGES = Math.floor(records.length / PERPAGE) + 1;
    LATEST_QUERY_GLOBAL = records;
    
    var pagin_str = '';
    
    // If there was any pagination from the previous query remove it
    var flowdata_list = $('#flowdata-pagination-list');
    flowdata_list.find('.flowdata-index').each(function(i,d) {
        $(d).remove();
    });
    
    // Add all of the pagination buttons
    for(i=0; i<PAGES; i++) {
        pagin_str += '<li class="flowdata-index" id="flowdata-index-' + i + '"><a href="javascript:void(0);" onclick="fill_flowdata_proper(' + i + ');" class="paginated-a-link">' + (i+1) + '</a></li>';
    }
    $('#flowdata-pagination-prev').after(pagin_str);
    
    // Fill the initial page
    fill_flowdata_proper(0);
}

function goto_next()
{
    if(CURRENT_PAGE != (PAGES - 1)) {
        fill_flowdata_proper(CURRENT_PAGE + 1);
    }
}

function goto_prev()
{
    if(CURRENT_PAGE != 0) {
        fill_flowdata_proper(CURRENT_PAGE - 1);
    }
}

function goto_last()
{
    fill_flowdata_proper(PAGES-1);
}

function star_if_zero(input) 
{
    if( input == 0              || 
        $.trim(input) == '0'    ||
        $.trim(input) == '0.0.0.0') {
        return '*';
    } else {
        return $.trim(input);
    }
}

function addtoquery(node)
{
    var rawquery = $('#rawquery').val();
    qid = 0;
    
    if(rawquery) {
        $('#rawquery').val('(' + rawquery + ') and (' + node.attr('alt') + ')');
    } else {
        $('#rawquery').val(node.attr('alt'));
    }
    
    $('#ag').val($('#ag').val() + ',' + node.attr('data'));
    $('#run_query').trigger('click');
}

// Gets the query update
function get_queryupdate(current)
{
    var query = [];
    
    if(star_if_zero(current.srcip) != '*') {
        query.push('src ip ' + $.trim(current.srcip));
    }
    if(star_if_zero(current.dstip) != '*') {
        query.push('dst ip ' + $.trim(current.dstip));
    }
    if(star_if_zero(current.srcport) != '*') {
        query.push('src port ' + $.trim(current.srcport));
    }
    if(star_if_zero(current.dstport) != '*') {
        query.push('dst port ' + $.trim(current.dstport));
    }
    
    return query.join(' and ');
}

function make_query_clickable(item, update, typename, title)
{
    var value = star_if_zero(item);
    var addclass = "";
    if (value == "*") {
        addclass = " centerme";
    }

    var mydiv = "<div data='" + typename + "' alt='" + update + "' onclick='addtoquery($(this))' class='queryclickable"+addclass+"'>";
    mydiv += "<a href='javascript:void(0);' title='" + title + "'>" + value + "</a>";
    mydiv += "</div>";
    return mydiv;
}

function adjust_paginator(index) {
    
    var flowdata_list = $('#flowdata-pagination-list');
    $('#flowdata-pagination-of').text('Of ' + PAGES);
    
    // Remove the active from all of the flowdata-index items
    flowdata_list.find('.flowdata-index').each(function(i, d) {
        $(d).removeClass('active');
    });
    
    // Mark the current index as active
    flowdata_list.find('#flowdata-index-' + index).each(function(i, d) {
        $(d).addClass('active');
    });
    
    // If there are more than 10 below it, hide them, otherwise show them
    // We must show them in case the user jumps to a later page, then
    // wants to go back.
    var min = 0;
    var visible = 0;
    
    if(index - PAGINATION_LOOKBEHIND > 0) {
        if(index + PAGINATION_TOTAL > PAGES) {
            min = PAGES - PAGINATION_TOTAL;
        } else {
            min = index - PAGINATION_LOOKBEHIND;
        }
    }
    
    for(var j=0;j<PAGES;j++) {
        flowdata_list.find('#flowdata-index-' + j).each(function(i,d) {
            $(d).hide();
        });
    }
    
    while(min < PAGES && visible < PAGINATION_TOTAL) {
        //console.log('#flowdata-index-' + min);
        flowdata_list.find('#flowdata-index-' + min).each(function(i,d) {
            $(d).show();
        });
        min++;
        visible++;
    }
}

function fill_flowdata_proper(index)
{
    CURRENT_PAGE = index;
    adjust_paginator(index);
    
    // Find our container that we will fill with flowdata
    var flowcon = $('#query_flowdata').find('#flowdata-proper-table tbody');
    flowcon.empty();
    
    // Get the flows that we'll be working with
    var first_record = index * PERPAGE;
    var last_record = (index*PERPAGE) + PERPAGE;
    
    // Get the slice of the query that we'll be displaying in the table
    var workspace = LATEST_QUERY_GLOBAL.slice(first_record, last_record);
    
    // Set aside our variables for the loop
    var tr;
    var queryupdate;
    
    for(var i=0, l=workspace.length; i<l; i++) {
        
        // Our current record
        var curr = workspace[i];

        // The URL that will be hit to see the results about the specific record
        var queryupdate = get_queryupdate(curr);

        csrcip = curr.srcip;
        cdstip = curr.dstip;
        srctitle = "";
        dsttitle = "";
        if (resolve_hosts) {
            srctitle = csrcip;
            dsttitle = cdstip;
            csrcip = curr.srcdn;
            cdstip = curr.dstdn;
        }
        
        tr = '<tr>'
        tr += '<td >' + curr.start + '</td>';
        tr += '<td>' + curr.end + '</td>';
        tr += '<td>' + curr.duration + '</td>';
        tr += '<td>' + make_query_clickable(csrcip, queryupdate, 'srcip', srctitle) + '</td>';
        tr += '<td>' + make_query_clickable(cdstip, queryupdate, 'dstip', dsttitle) + '</td>';
        tr += '<td>' + make_query_clickable(curr.srcport, queryupdate, 'srcport', '') + '</td>';
        tr += '<td>' + make_query_clickable(curr.dstport, queryupdate, 'dstport', '') + '</td>';
        tr += '<td class="packetssorter">' + human_readable_size(curr.packets, true) + '</td>';
        tr += '<td class="bytessorter">' + human_readable_size(curr.bytes, true) + '</td>';
        tr += '<td class="flowssorter">' + human_readable_size(curr.flows, true) + '</td>';
        tr += '<td class="bpssorter">' + human_readable_size(curr.bps, true) + '</td>';
        tr += '<td class="ppssorter">' + human_readable_size(curr.pps, true) + '</td>';
        tr += '<td class="bppsorter">' + human_readable_size(curr.Bpp, true) + '</td>';
        tr += '</tr>';
        flowcon.append(tr);
    }
    
    $('#flowdata-proper-table').find('.' + SORTCLASS).each(function(i,d) {
        $(d).addClass('highlight');
    });
}
