<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends NA_Controller
{
    function __construct()
    {
        parent::__construct();

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in()){
            redirect('login'); // make them log in
        } else {
            if (!$this->ion_auth->is_admin()) {
                redirect(''); // redirect to main dashboard
            }
        }

        $this->page = 'configure';
    }


    public function index()
    {
        $js = array('/js/vizhelpers.js');
        $this->init_page(lang('title_admin'), $this->page, $js);


        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "system"), true);
        $this->load->view('admin/home', $this->data);
    }

    # License information and set up (get amount of hosts, etc)
    public function license()
    {
        $this->init_page(lang('title_license'), $this->page);

        if ($this->input->post('setkey') && !$this->data['demo_mode']) {
            // Set license key if we can
            $key = trim($this->input->post('key'));
            if (is_valid_license_key($key)) {
                set_license_key($key);
            } else {
                $this->data['error'] = lang("license_error");
            }
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "license"), true);
        $this->load->view('admin/license', $this->data);
    }

    # Global default settings
    public function globals()
    {
        $this->init_page(lang('title_global_settings'), $this->page);
        $this->load->helper('timezone_helper');
        $this->load->helper('cmdsubsys_helper');

        if ($this->input->post('saveglobals') && !$this->data['demo_mode']) {

            $cache_time = intval($this->input->post('cache_time'));
            if ($cache_time < 0) {
                $cache_time = 0;
            }

            // Set the config option for language
            $this->config_option->set('language', $this->input->post('language'));
            $this->config_option->set('rel_map_max', $this->input->post('rel_map_max'));
            $this->config_option->set('resolve_hosts', $this->input->post('resolve_hosts'));
            $this->config_option->set('resolve_hosts_graphs', $this->input->post('resolve_hosts_graphs'));
            $this->config_option->set('cache_time', $cache_time);
            
            // Check if we need to change the timezone
            $tz = $this->input->post('timezone');
            if ($tz != get_current_timezone()) {
                $cid = submit_subsys_command(COMMAND_CHANGE_TIMEZONE, array('timezone' => $this->db->escape_str($tz)));
            }
            $this->data['set_timezone'] = $tz;

            $this->data['success'] = lang('global_saved_success');
        }

        // Get all languages
        $languages = array();
        $path = "/var/www/html/nagiosna/application/language";
        $results = scandir($path);
        foreach ($results as $r) {
            if ($r === '.' || $r === '..' || $r === '.svn') { continue; }
            if (is_dir($path . '/' . $r)) {
                $languages[] = $r;
            }
        }
        $this->data['languages'] = $languages;

        $lang = $this->config_option->get('language');
        $this->data['global_language'] = $lang->value;
        
        $rel_map_max = $this->config_option->get('rel_map_max');
        $this->data['rel_map_max'] = 60;
        if (!empty($rel_map_max->value)) {
            $this->data['rel_map_max'] = $rel_map_max->value;
        }

        $resolve_hosts = $this->config_option->get('resolve_hosts');
        $this->data['resolve_hosts'] = 0;
        if (!empty($resolve_hosts->value)) {
            $this->data['resolve_hosts'] = $resolve_hosts->value;
        }

        $resolve_hosts_graphs = $this->config_option->get('resolve_hosts_graphs');
        $this->data['resolve_hosts_graphs'] = 0;
        if (!empty($resolve_hosts_graphs->value)) {
            $this->data['resolve_hosts_graphs'] = $resolve_hosts_graphs->value;
        }

        $cache_time = $this->config_option->get('cache_time');
        $this->data['cache_time'] = $cache_time->value;

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "globals"), true);
        $this->load->view('admin/globals', $this->data);
    }

    # User list
    public function users()
    {
        $this->init_page('Users', $this->page);

        $this->data['myuserid'] = $this->session->userdata('user_id');

        // Get all the auth servers
        $q = $this->db->get('nagiosna_auth_servers');
        $auth_servers = $q->result();

        // Get all the users
        $this->data['users'] = $this->ion_auth->users()->result();
        foreach ($this->data['users'] as $k => $user) {
            $this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
            if (!empty($user->auth_server_id)) {
                foreach ($auth_servers as $aserver) {
                    if ($aserver->id == $user->auth_server_id) {
                        $this->data['users'][$k]->auth_server = $aserver;
                    }
                }
            }
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
        $this->load->view('admin/users', $this->data);
    }

    # Create new user
    public function create_user()
    {
        $this->init_page(lang('breadcrumb_create_user'), $this->page);

        // Do form validation
        $this->form_validation->set_rules('first_name', $this->lang->line('create_edit_user_fname_val'), 'xss_clean');
        $this->form_validation->set_rules('last_name', $this->lang->line('create_edit_user_lname_val'), 'xss_clean');
        $this->form_validation->set_rules('email', $this->lang->line('create_edit_user_email_val'), 'required|callback_xi_valid_email');
        $this->form_validation->set_rules('phone', $this->lang->line('create_edit_user_phone_val'), 'xss_clean');
        $this->form_validation->set_rules('company', $this->lang->line('create_edit_user_company_val'), 'xss_clean');
        $this->form_validation->set_rules('username', $this->lang->line('create_user_username'), 'required');
        $this->form_validation->set_rules('apiaccess', $this->lang->line('create_user_apiaccess'), 'required');
        $this->form_validation->set_rules('language', $this->lang->line('language'), 'required');

        $this->data['admin_checked'] = false;
        $this->data['user_checked'] = false;
        $group = $this->input->post('group');
        if ($group == 1) {
            $this->data['admin_checked'] = true;
        } else if ($group == 2) {
            $this->data['user_checked'] = true;
        }

        if (!$this->data['demo_mode']) {
            if ($this->form_validation->run() == true) {
                if (!empty($group)) {
                    $username = $this->input->post('username');
                    $email    = $this->input->post('email');
                    $password = $this->input->post('password');
                    $password2 = $this->input->post('password2');
                    $language = $this->input->post('language');
                    $account_type = $this->input->post('account_type');
                    $password = trim($password);

                    // Generate an API key if they have access
                    $apiaccess = $this->input->post('apiaccess');
                    $apikey = "";
                    if ($apiaccess) {
                        $apikey = sha1(uniqid() . 'nna');
                    }

                    $additional_data = array(
                        'first_name' => $this->input->post('first_name'),
                        'last_name'  => $this->input->post('last_name'),
                        'company'    => $this->input->post('company'),
                        'phone'      => $this->input->post('phone'),
                        'apiaccess'  => $apiaccess,
                        'apikey'     => $apikey,
                        'lang'       => $language
                    );

                    $cuser = false;

                    if ($account_type == "local") {
                        $additional_data['type'] = "local";
                        if ($password == $password2 && !empty($password) && strlen($password) >= 6) {
                            $cuser = true;
                        } else {
                            $this->data['error'] = 'Passwords must match. Passwords cannot be empty. Must be 6+ characters long.';
                        }
                    } else if ($account_type == "ad") {
                        $additional_data['type'] = "ad";
                        $additional_data['auth_server_id'] = $this->input->post('ad_server');
                        $additional_data['auth_server_data'] = serialize(array("username" => $this->input->post('ad_username')));
                        $password = uniqid();
                        $cuser = true;
                    } else if ($account_type == "ldap") {
                        $additional_data['type'] = "ldap";
                        $additional_data['auth_server_id'] = $this->input->post('ldap_server');
                        $additional_data['auth_server_data'] = serialize(array("dn" => $this->input->post('dn')));
                        $password = uniqid();
                        $cuser = true;
                    }

                    if ($cuser) {

                        // Create the new user
                        $id = $this->ion_auth->register($username, $password, $email, $additional_data);

                        if ($id) {
                            // Add new user to group
                            $this->ion_auth->remove_from_group(NULL, $id);
                            $this->ion_auth->add_to_group($group, $id);

                            // Finished! Send to main users page
                            redirect('admin/users');
                        } else {
                            $this->data['error'] = "Could not create the user.";
                        }
                    }
                } else {
                    $this->data['error'] = "You must select a user access level.";
                }
            } else {
                $this->data['error'] = validation_errors();
            }
        } else { 
            $this->data['error'] = "This action is not available in Demo Mode.";
        }

        // Get all languages
        $languages = array();
        $path = "/var/www/html/nagiosna/application/language";
        $results = scandir($path);
        foreach ($results as $r) {
            if ($r === '.' || $r === '..' || $r === '.svn') { continue; }
            if (is_dir($path . '/' . $r)) {
                $languages[] = $r;
            }
        }
        $this->data['languages'] = $languages;

        // Get all authentication servers
        $auth_servers = array();
        $ldap_servers = array();
        $ad_servers = array();
        $q = $this->db->get('nagiosna_auth_servers');
        foreach ($q->result() as $server) {
            $auth_servers[] = $server;
            if ($server->type == "ldap") { $ldap_servers[] = $server; }
            if ($server->type == "ad") { $ad_servers[] = $server; }
        }
        $this->data['auth_servers'] = $auth_servers;
        $this->data['ldap_servers'] = $ldap_servers;
        $this->data['ad_servers'] = $ad_servers;

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
        $this->load->view('admin/create_user', $this->data);
    }

    // Edit users
    public function edit_user($id)
    {
        if (empty($id)) { redirect('admin/users'); }
        $this->init_page(lang('breadcrumb_edit_user'), $this->page);

        // Grab the user's stuff
        $this->data['user'] = $this->ion_auth->user($id)->row();
        $this->data['user']->auth_server_data = unserialize($this->data['user']->auth_server_data);
        $groups = $this->ion_auth->get_users_groups($id)->result();
        foreach ($groups as $g) {
            if ($g->id == 1) { $this->data['admin_checked'] = true; }
            if ($g->id == 2) { $this->data['user_checked'] = true; }
        }

        // Do form validation stuff
        $account_type = $this->input->post('account_type');

        $this->form_validation->set_rules('first_name', $this->lang->line('create_edit_user_fname_val'), 'xss_clean');
        $this->form_validation->set_rules('last_name', $this->lang->line('create_edit_user_lname_val'), 'xss_clean');
        $this->form_validation->set_rules('email', $this->lang->line('create_edit_user_email_val'), 'required|callback_xi_valid_email');
        $this->form_validation->set_rules('phone', $this->lang->line('create_edit_user_phone_val'), 'xss_clean');
        $this->form_validation->set_rules('company', $this->lang->line('create_edit_user_company_val'), 'xss_clean');

        if ($account_type == "local" || $id == 1) {
            $this->form_validation->set_rules('password', $this->lang->line('create_edit_user_password_val'), 'matches[password2]');
            $this->form_validation->set_rules('password2', $this->lang->line('create_edit_user_password_confirm_val'), '');
        }

        $this->form_validation->set_rules('apiaccess', $this->lang->line('create_user_apiaccess'), 'required');
        $this->form_validation->set_rules('language', $this->lang->line('language'), 'required');

        $group = $this->input->post('group');
        if ($group == 1) {
            $this->data['admin_checked'] = true;
        } else if ($group == 2) {
            $this->data['user_checked'] = true;
        }

        if (!$this->data['demo_mode']) {
            if ($this->form_validation->run() == true) {
                if (!empty($group) || $id == 1) {

                    // Generate an API key if they have access
                    $apiaccess = $this->input->post('apiaccess');
                    $apikey = "";

                    if ($apiaccess) {
                        if (empty($this->data['user']->apikey ))
                            $apikey = sha1(uniqid() . 'nna');
                        else
                            $apikey = $this->data['user']->apikey;
                        
                        if ($id == $this->session->userdata('user_id')) {
                            $this->session->set_userdata('apikey', $apikey);
                            $this->session->set_userdata('apiaccess', 1);
                        }
                    } else {
                        if ($id == $this->session->userdata('user_id')) {
                            $this->session->set_userdata('apikey', '');
                            $this->session->set_userdata('apiaccess', 0);
                        }
                    }

                    $additional_data = array(
                        'first_name' => $this->input->post('first_name'),
                        'last_name'  => $this->input->post('last_name'),
                        'company'    => $this->input->post('company'),
                        'phone'      => $this->input->post('phone'),
                        'email'      => $this->input->post('email'),
                        'apiaccess'  => $apiaccess,
                        'apikey'     => $apikey,
                        'ip_address' => '',
                        'lang'       => $this->input->post('language')
                    );

                    // Update password/auth type
                    $set_super_pass = true;
                    if ($account_type == "local") {
                        $additional_data['type'] = "local";
                        $password = $this->input->post('password');
                        if (!empty($password)) {
                            $this->ion_auth_model->reset_password($this->data['user']->username, $password);
                            $set_super_pass = false;
                        }
                    } else if ($account_type == "ad") {
                        $additional_data['type'] = "ad";
                        $additional_data['auth_server_id'] = $this->input->post('ad_server');
                        $additional_data['auth_server_data'] = serialize(array("username" => $this->input->post('ad_username')));
                    } else if ($account_type == "ldap") {
                        $additional_data['type'] = "ldap";
                        $additional_data['auth_server_id'] = $this->input->post('ldap_server');
                        $additional_data['auth_server_data'] = serialize(array("dn" => $this->input->post('dn')));
                    }

                    // Set the superuser's password if it hasn't been set already
                    if ($id == 1 && $set_super_pass) {
                        $password = $this->input->post('password');
                        if (!empty($password)) {
                            $this->ion_auth_model->reset_password($this->data['user']->username, $password);
                        }
                    }

                    // Update user info
                    $this->ion_auth->update($id, $additional_data);

                    // Remove user from all groups and add what they should be in
                    if ($id > 1) {
                        $this->ion_auth->remove_from_group(NULL, $id);
                        $this->ion_auth->add_to_group($group, $id);
                    }

                    $this->session->set_flashdata('msg', lang('edit_user_success'));
                    redirect('admin/users');

                } else {
                    $this->data['error'] = lang('edit_user_access_level_msg');
                }
            } else {
                $this->data['error'] = validation_errors();
            }
        } else { 
            $this->data['error'] = lang('demo_mode_warning');
        }

        // Get all languages
        $languages = array();
        $path = "/var/www/html/nagiosna/application/language";
        $results = scandir($path);
        foreach ($results as $r) {
            if ($r === '.' || $r === '..' || $r === '.svn') { continue; }
            if (is_dir($path . '/' . $r)) {
                $languages[] = $r;
            }
        }
        $this->data['languages'] = $languages;

        // Get all authentication servers
        $auth_servers = array();
        $ldap_servers = array();
        $ad_servers = array();
        $q = $this->db->get('nagiosna_auth_servers');
        foreach ($q->result() as $server) {
            $auth_servers[] = $server;
            if ($server->type == "ldap") { $ldap_servers[] = $server; }
            if ($server->type == "ad") { $ad_servers[] = $server; }
        }
        $this->data['auth_servers'] = $auth_servers;
        $this->data['ldap_servers'] = $ldap_servers;
        $this->data['ad_servers'] = $ad_servers;

        $this->data['msg'] = $this->session->flashdata('msg');
        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
        $this->load->view('admin/edit_user', $this->data);
    }

    // Import users from LDAP/AD servers
    public function user_import()
    {
        $this->init_page(lang('index_import_users'), $this->page);

        // Get all servers
        $q = $this->db->get('nagiosna_auth_servers');
        $this->data['auth_servers'] = $q->result();

        $submitted = $this->input->post('submitted');
        if ($submitted) {
            do {

                // Grab the server information
                $auth_server_id = $this->input->post('auth_server_id');
                $this->data['auth_server_id'] = $auth_server_id;
                $q = $this->db->get_where('nagiosna_auth_servers', array("id" => $auth_server_id));
                $server = $q->row();

                if (empty($server)) {
                    $this->data['errors'] = "Could not get the AD / LDAP server selected.";
                    break;
                }

                // Verify that the user is able to access the AD/LDAP server
                $username = $this->input->post('username');
                $this->data['username'] = $username;
                $password = $this->input->post('password');

                if (empty($username) || empty($password)) {
                    $this->data['errors'] = "You must enter a valid Username / Password for a user with permissions to view your AD / LDAP tree.";
                    break;
                }

                $logged_in = false;

                // Connect to the server...
                if ($server->type == "ldap") {

                    $this->load->library('basicLDAP');

                    $use_ssl = false;
                    $use_tls = false;

                    if ($server->encryption == "ssl") {
                        $use_ssl = true;
                    } else if ($server->encryption == "tls") {
                        $use_tls = true;
                    }

                    $ldap = new basicLDAP($server->host, $server->port, $server->basedn, $server->encryption);

                    // Do actual authentication
                    if ($ldap->authenticate($username, $password)) {
                        $logged_in = true;
                    } else {
                        $this->data['errors'] = "Invalid credentials.";
                        break;
                    }

                } else if ($server->type == "ad") {

                    $this->load->library('adLDAP/adLDAP');

                    $use_ssl = false;
                    $use_tls = false;

                    if ($server->encryption == "ssl") {
                        $use_ssl = true;
                    } else if ($server->encryption == "tls") {
                        $use_tls = true;
                    }

                    $controllers = explode(',', $server->controllers);

                    // Create the adLDAP object...
                    $options = array('account_suffix' => $server->suffix,
                                     'base_dn' => $server->basedn,
                                     'domain_controllers' => $controllers,
                                     'use_ssl' => $use_ssl,
                                     'use_tls' => $use_tls);

                    try {
                        $ad = new adLDAP($options);
                    } catch (adLDAPException $e) {
                        var_dump($e);
                        die();
                    }

                    // Do actual authentication
                    if ($ad->authenticate($username, $password)) {
                        $logged_in = true;
                    } else {
                        $this->data['errors'] = "Invalid credentials.";
                        break;
                    }

                }

                if ($logged_in) {

                    $this->session->set_userdata('auth_import_username', $username);
                    $this->session->set_userdata('auth_import_password', $password);
                    $this->session->set_userdata('auth_import_server_id', $auth_server_id);
                    $this->session->set_userdata('auth_import_server_type', $server->type);

                    // Display the secret LDAP / AD import page!
                    $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
                    $this->load->view('admin/import_users_select', $this->data);
                    return;

                }

            } while (false);
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
        $this->load->view('admin/import_users', $this->data);
    }

    public function user_import_step2()
    {
        $this->init_page(lang('index_import_users'), $this->page);
        $this->load->helper('ldap_ad');

        $auth_server_id = $this->session->userdata('auth_import_server_id');
        $server_type = $this->session->userdata('auth_import_server_type');
        $this->data['server_type'] = $server_type;

        // Grab the server information
        $q = $this->db->get_where('nagiosna_auth_servers', array("id" => $auth_server_id));
        $this->data['server'] = $q->row();

        // Grab all user information
        $objs = $this->input->post('objs');
        $objs = explode('|', $objs);

        if (!empty($objs)) {
            $conn = create_auth_connection();
        }

        if ($server_type == 'ad') {

            // Connect to AD server
            $new_users = array();
            foreach ($objs as $username) {
                $userinfo = $conn->user()->info($username);
                $email = '';
                $phone = '';
                $first = '';
                $last = '';
                $dn = '';
                
                if (isset($userinfo[0]['mail'][0])) {
                    $email = $userinfo[0]['mail'][0];
                }

                if (isset($userinfo[0]['telephonenumber'][0])) {
                    $phone = $userinfo[0]['telephonenumber'][0];
                }

                if (isset($userinfo[0]['displayname'][0])) {
                    $fullname = $userinfo[0]['displayname'][0];
                    list($first, $last) = explode(' ', $fullname, 2);
                }

                if (isset($userinfo[0]['dn'])) {
                    $dn = $userinfo[0]['dn'];
                }

                // Generate a user with all information we want...
                $new_users[] = array("username" => $username,
                                     "firstname" => $first,
                                     "lastname" => $last,
                                     "phone" => $phone,
                                     "email" => $email,
                                     "dn" => $dn);
            }

        } else if ($server_type == 'ldap') {

            // Connect to LDAP server
            $new_users = array();
            foreach ($objs as $dn) {
                $userinfo = $conn->user_info($dn);
                $username = '';
                $email = '';
                $phone = '';
                $first = '';
                $last = '';

                if (isset($userinfo[0]['cn'][0])) {
                    $cn = $userinfo[0]['cn'][0];
                    list($first, $last) = explode(' ', $cn, 2);
                }

                if (isset($userinfo[0]['uid'][0])) {
                    $username = $userinfo[0]['uid'][0];
                }

                // Generate a user with all information we want...
                $new_users[] = array("username" => $username,
                                     "firstname" => $first,
                                     "lastname" => $last,
                                     "phone" => $phone,
                                     "email" => $email,
                                     "dn" => $dn);
            }

        }

        $this->data['new_users'] = $new_users;

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "users"), true);
        $this->load->view('admin/import_users_final', $this->data);
    }

    // Add the users (or error out)
    public function user_import_complete()
    {
        $import = $this->input->post('import');
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $username = $this->input->post('username');
        $email = $this->input->post('email');
        $level = $this->input->post('level');
        $apiaccess = $this->input->post('apiaccess');
        $account_type = $this->input->post('account_type');
        $server_id = $this->input->post('server_id');
        $ad_username = $this->input->post('ad_username');
        $dn = $this->input->post('dn');

        // Create a user for each imported user we selected
        foreach ($import as $uid => $imp) {
            if ($imp == 0) { continue; }

            // Generate an API key if they have access
            $apikey = "";
            if ($apiaccess[$uid]) {
                $apikey = sha1(uniqid() . 'nna');
            }

            $additional_data = array(
                'first_name'     => $first_name[$uid],
                'last_name'      => $last_name[$uid],
                'apiaccess'      => $apiaccess[$uid],
                'apikey'         => $apikey,
                'lang'           => 'default',
                'type'           => $account_type[$uid],
                'auth_server_id' => $server_id[$uid]
            );

            if ($account_type[$uid] == "ad") {
                $additional_data['auth_server_data'] = serialize(array("username" => $ad_username[$uid]));
                $password = uniqid();
            } else if ($account_type[$uid] == "ldap") {
                $additional_data['auth_server_data'] = serialize(array("dn" => $dn[$uid]));
                $password = uniqid();
            }
            // Create the new user
            $id = $this->ion_auth->register($username[$uid], $password, $email[$uid], $additional_data);

            if ($id) {
                // Add new user to group
                $this->ion_auth->remove_from_group(NULL, $id);
                $this->ion_auth->add_to_group($level[$uid], $id);
            }
        }

        // Remove session variables
        $this->session->unset_userdata('auth_import_username');
        $this->session->unset_userdata('auth_import_password');
        $this->session->unset_userdata('auth_import_server_id');
        $this->session->unset_userdata('auth_import_server_type');

        // Finished! Send to main users page
        redirect('admin/users');
    }

    // Management of LDAP/AD servers
    public function auth_servers()
    {
        $this->init_page(lang('breadcrumb_ldap_ad_servers'), $this->page);

        // Load all the servers...
        $q = $this->db->get('nagiosna_auth_servers');
        $servers = $q->result();

        // Load all users
        $q = $this->db->get('nagiosna_users');
        $users = $q->result();

        foreach ($servers as &$server) {
            $server->associated_users = 0;
            foreach ($users as $u) {
                if ($u->auth_server_id == $server->id) {
                    $server->associated_users += 1;
                }
            }
        }

        $this->data['servers'] = $servers;

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "auth_servers"), true);
        $this->load->view('admin/auth_servers/manage', $this->data); 
    }

    public function add_auth_server()
    {
        $this->init_page(lang('ldap_ad_add_server_title'), $this->page);

        // Check if we are submitting a form ... and check variables
        $create = $this->input->post('create');
        if (!empty($create)) {
            do {

                $type = $this->input->post('type');
                $enabled = $this->input->post('enabled');
                $name = $this->input->post('name');
                $basedn = $this->input->post('basedn');
                $encryption = $this->input->post('encryption');
                
                $suffix = $this->input->post('suffix');
                $controllers = $this->input->post('controllers');
                
                $host = $this->input->post('host');
                $port = $this->input->post('port');

                $this->data['type'] = $type;
                $this->data['basedn'] = $basedn;
                $this->data['enabled'] = $enabled;
                $this->data['name'] = $name;
                $this->data['encryption'] = $encryption;

                $this->data['suffix'] = $suffix;
                $this->data['controllers'] = $controllers;

                $this->data['host'] = $host;
                $this->data['port'] = $port;

                if (empty($name)) {
                    $this->data['errors'] = "Must enter a name to distinguish authentication servers from one another.";
                    break;
                }

                if (empty($basedn)) {
                    $this->data['errors'] = "Must fill out a base Distinguished Name.";
                    break;
                }

                // Check if it's AD or LDAP
                if ($type == "ad") {

                    if (empty($suffix) || empty($controllers)) {
                        $this->data['errors'] = "Active Directory servers require an Account Suffix and a list of Domain Controllers.";
                        break;
                    }

                } else if ($type == "ldap") {

                    if (empty($host) || empty($port)) {
                        $this->data['errors'] = "LDAP servers require an hostname/ip address and a port (default is 389).";
                        break;
                    }

                } else {
                    $this->data['errors'] = "Invalid type specified. Must be Active Directory or LDAP.";
                    break;
                }

                // We made it this far, so let's add this into the database
                $data = array("type" => $type,
                              "name" => $name,
                              "basedn" => $basedn,
                              "encryption" => $encryption,
                              "controllers" => $controllers,
                              "suffix" => $suffix,
                              "host" => $host,
                              "port" => $port);

                if (!empty($enabled)) {
                    $data['active'] = 1;
                } else {
                    $data['active'] = 0;
                }

                // Insert into the database
                $this->db->insert('nagiosna_auth_servers', $data);

                // Redirect
                redirect('admin/auth_servers');

            } while (false);
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "auth_servers"), true);
        $this->load->view('admin/auth_servers/add', $this->data);
    }

    public function edit_auth_server($id)
    {
        $this->init_page(lang('ldap_ad_edit_server_title'), $this->page);

        // Get the server based on the id
        $q = $this->db->get_Where('nagiosna_auth_servers', array("id" => $id));
        $server = $q->row();

        $this->data['enabled'] = $server->active;
        $this->data['name'] = $server->name;
        $this->data['host'] = $server->host;
        $this->data['id'] = $id;
        $this->data['type'] = $server->type;
        $this->data['encryption'] = $server->encryption;
        $this->data['basedn'] = $server->basedn;
        $this->data['suffix'] = $server->suffix;
        $this->data['controllers'] = $server->controllers;
        $this->data['port'] = $server->port;

        // Check if we are submitting a form ... and check variables
        $save = $this->input->post('save');
        if (!empty($save)) {
            do {

                // Grab all the passed variables
                $type = $this->input->post('type');
                $enabled = $this->input->post('enabled');
                $name = $this->input->post('name');
                $basedn = $this->input->post('basedn');
                $encryption = $this->input->post('encryption');
                
                $suffix = $this->input->post('suffix');
                $controllers = $this->input->post('controllers');
                
                $host = $this->input->post('host');
                $port = $this->input->post('port');

                $this->data['type'] = $type;
                $this->data['basedn'] = $basedn;
                $this->data['enabled'] = $enabled;
                $this->data['name'] = $name;
                $this->data['encryption'] = $encryption;

                $this->data['suffix'] = $suffix;
                $this->data['controllers'] = $controllers;

                $this->data['host'] = $host;
                $this->data['port'] = $port;

                // Check if we have everything we need to continue
                if (empty($name)) {
                    $this->data['errors'] = "Must enter a name to distinguish authentication servers from one another.";
                    break;
                }

                if (empty($basedn)) {
                    $this->data['errors'] = "Must fill out a base Distinguished Name.";
                    break;
                }

                // Check if it's AD or LDAP
                if ($type == "ad") {

                    if (empty($suffix) || empty($controllers)) {
                        $this->data['errors'] = "Active Directory servers require an Account Suffix and a list of Domain Controllers.";
                        break;
                    }

                } else if ($type == "ldap") {

                    if (empty($host) || empty($port)) {
                        $this->data['errors'] = "LDAP servers require an hostname/ip address and a port (default is 389).";
                        break;
                    }

                } else {
                    $this->data['errors'] = "Invalid type specified. Must be Active Directory or LDAP.";
                    break;
                }

                // We made it this far, so let's add this into the database
                $data = array("type" => $type,
                              "name" => $name,
                              "basedn" => $basedn,
                              "encryption" => $encryption,
                              "controllers" => $controllers,
                              "suffix" => $suffix,
                              "host" => $host,
                              "port" => $port);

                if (!empty($enabled)) {
                    $data['active'] = 1;
                } else {
                    $data['active'] = 0;
                }

                // Insert into the database
                $this->db->where('id', $id);
                $this->db->update('nagiosna_auth_servers', $data);

                // Redirect
                $this->session->set_flashdata('message', 'Server has been updated successfully.');
                redirect('admin/auth_servers');

            } while (false);
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "auth_servers"), true);
        $this->load->view('admin/auth_servers/edit', $this->data);
    }
    
    // Delete LDAP/AD server
    public function delete_auth_server($id=null)
    {
        if (empty($id)) {
            redirect('admin/auth_servers');
        }

        $q = $this->db->delete('nagiosna_auth_servers', array("id" => $id));

        // Redirect
        $this->session->set_flashdata('message', 'Auth server has been removed.');
        redirect('admin/auth_servers');
    }
    
    public function updates()
    {
        $this->init_page(lang('leftbar_updates'), $this->page);

        $this->data['locked'] = false;
        $this->data['locked_subsys_id'] = 0;
        define('AU_LOGFILE', "/usr/local/nagiosna/tmp/upgrade.log");
        define('AU_LOGDIR', "/usr/local/nagiosna/var/upgrades/");

        // Grab all recent upgrades
        $upgrades = array();
        if (is_dir(AU_LOGDIR)) {
            $direntries = scandir(AU_LOGDIR);
            foreach ($direntries as $de) {
                if (strpos($de, '.log') === false) continue;
                $logfile = $de;
                $name = str_replace(".log", "", $de);
                $ar = explode(".", $de);
                $ts = filemtime(AU_LOGDIR."/$logfile");
                $upgrades[] = array("file" => $logfile,
                    "name" => $name,
                    "status" => ucfirst($ar[0]),
                    "timestamp" => $ts,
                    "date" => date("m/d/Y H:i", $ts));
            }
        }
        $this->data['upgrades'] = $upgrades;

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "updates"), true);
        $this->load->view('admin/updates', $this->data);
    }

    // Delete a user (AJAX called)
    public function delete_user()
    {  
        $id = $this->input->post('id');
        if ($id == 1) {
            $json = array("success" => 0,
                          "errormsg" => lang('delete_superadmin'));
        } else {
            if ($this->ion_auth->delete_user($id)) {
                $json = array("success" => $val);
            } else {
                $json = array("success" => 0,
                              "errormsg" => lang('could_not_delete_user'));
            }
        }

        print json_encode($json);
    }

    public function backup()
    {
        $this->init_page(lang('title_backup'), $this->page);

        // Get all the backups
        $backup_dir = "/store/backups/nagiosna";
        $backup = array();

        $l = array();
        $d = $backup_dir;
        $x = "/\.gz/";

        foreach (array_diff(scandir($d), array('.', '..')) as $f) {
            if (is_file($d . '/' . $f) && (($x) ? preg_match($x, $f) : 1))
                $l[] = $f;
        }

        $direntries = $l;

        foreach ($direntries as $de) {

            $tarball = $de;
            $name = str_replace(".tar.gz", "", $de);
            $ar = explode(".", $name);
            $ts = filemtime("$backup_dir/$tarball");

            $backup[] = array(
                "file" => $tarball,
                "timestamp" => $ts,
                "name" => $name,
                "size" => humanize_filesize(filesize("/store/backups/nagiosna/" . $name . ".tar.gz")),
                "date" => date("Y-m-d H:i:s", $ts)
            );
        }

        // Sort backups by timestamp
        function date_compare($a, $b) {
            $t1 = $a['timestamp'];
            $t2 = $b['timestamp'];
            return $t2 - $t1;
        }

        usort($backup, 'date_compare');

        $this->data['backups'] = $backup;

        foreach ($this->data['backups'] as $k => $val) {
            $this->data['backups'][$k] = $val;
        }

        // check if we are redirected from delete function
        if ($this->session->flashdata('delete')) {
            $this->data['delete'] = $this->session->flashdata('delete');
        }

        $this->data['leftbar'] = $this->load->view('admin/leftbar', array("tab" => "backup"), true);
        $this->load->view('admin/backup', $this->data);
    }

    public function download_backup($name)
    {
        $this->load->helper('download_helper');

        $thefile = '/store/backups/nagiosna/' . $name;
        $path = file_get_contents($thefile);
        force_download($name, $path);
    }

    public function delete_backup($name)
    {
        $this->load->helper('download_helper');
        
        $backup_dir = "/store/backups/nagiosna/";
        $backup = $backup_dir . $name;
        $delete = array();

        // Check if file is writable
        $writable = is_writable($backup);
        if ($writable == false) {
            $delete['message'] = 'Backup file ' . $name . ' not writable.  Check permissions.';
            $delete['result'] = 1;
        }

        // Delete
        $result = unlink($backup);

        // Redirect on result
        if ($result) {
            $delete['message'] = 'Backup file ' . $name . ' has been deleted.';
            $delete['result'] = 0;
        } else {
            $delete['message'] = 'Backup file ' . $name . ' could not be deleted.  Check permissions on the files and backup directory.';
            $delete['result'] = 1;
        }

        $this->session->set_flashdata('delete', $delete);
        redirect('admin/backup');
    }
}
