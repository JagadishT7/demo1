<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends NA_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Source', array('NOLOAD' => TRUE));
        $this->load->library('View', array('NOLOAD' => TRUE));
        $this->load->library('Query', array('NOLOAD' => TRUE));
        $this->load->library('Report', array('NOLOAD' => TRUE));
        $this->load->library('Sourcegroup', array('NOLOAD' => TRUE));

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in() && !$this->token_has_api_access($this->input->get('token')))
        {
            redirect('login');
        }
    }

	public function index()
	{
	    $this->init_page(lang('title_reports'), 'reports');
	    $this->load->view('reports/home', $this->data);
	}

    public function reportviz()
    {
        $q = grab_request_var('q', array());
        $sid = grab_request_var('sid', NULL);
        $gid = grab_request_var('gid', NULL);
        $rid = grab_request_var('rid', NULL);
        $vid = grab_request_var('vid', NULL);

        try {
            /* Get our source items */
            if(empty($sid) === FALSE) {
                $sourcelike = new Source($sid);
                $sourcequery = "sid={$sid}";
            } else if (empty($gid) === FALSE) {
                $sourcelike = new Sourcegroup($gid);
                $sourcequery = "gid={$gid}";
            }
            else {
                throw new Exception(lang('exception_no_source'));
            }
            
            if(empty($vid) === FALSE) {
                $view = new View($vid);
                $sourcequery .= "&vid={$vid}";
                $sourcelike->compose($view);
            }
            
            /* Get our report */
            if(empty($rid) === FALSE) {
                $report = new Report($rid);
            }
            else if(empty($q) === FALSE) {
                $report = new Report($q);
            }
            else {
                throw new Exception(lang('exception_no_report'));
            }
            
            /* Run our report */
            $json = $report->run($sourcelike);
            $data['datasets'] = $report->get_other_toptypes();
            $nfquerystr = $report->get_query_from_top_n($json);
            $rjson = array_slice($json['records'], 1);
            $toptype = $report->toptype;
            $toporder = "{$report->toporder}percent";
            $djson = array();
            $total = 100;
            
            // Change for hostname resolution
            $resolve_hosts_graphs = $this->config_option->get('resolve_hosts_graphs');
            if (!empty($resolve_hosts_graphs->value)) {
                $i = 0;

                // Grab the cached hostnames out of the database
                $cache = array();
                $q = $this->db->get('nagiosna_hostname_cache');
                foreach ($q->result() as $c) {
                    $cache[$c->ip] = $c;
                }

                foreach ($json['records'] as &$record) {
                    $i++;
                    if ($i == 1) { continue; }
                    if ($toptype == 'srcip') {

                        $ip = trim($record->srcip);

                        // Check if it's in the cache
                        if (array_key_exists($ip, $cache)) {
                            $record->srcdn = $cache[$ip]->hostname;
                        } else {
                            // Do a get host by addr
                            $hostname = gethostbyaddr($ip);
                            $data = array('ip' => $ip,
                                          'hostname' => $hostname,
                                          'time' => time());
                            $this->db->insert('nagiosna_hostname_cache', $data);
                            $cache[$ip] = (object) $data;
                            $record->srcdn = $cache[$ip]->hostname;
                        }
                    }
                }
            }

            foreach(array_slice($json['records'], 1) as $record) {
                $y = (float)$record->$toporder;
                if (!empty($resolve_hosts_graphs->value)) {
                    $djson[] = array($record->srcdn, $y);
                } else {
                    $djson[] = array($record->$toptype, $y);
                }
                $total = $total - $y;
            }
            
            if($total != 0) {
                $djson[] = array('Other', $total);
            }
            
            $rjson = array('data' => $djson, 'type' => 'pie', 'name' => lang('percentage_of').' '.ucfirst($report->toporder));
        }
        catch (Exception $e) {
            $json['error'] = $e->getMessage();
            print json_encode($json);
            return;
        }
        
        $data['toporder'] = $report->toporder;
        $data['toptype'] = $report->toptype;
        $data['title'] = $report->name;
        $data['json'] = json_encode(array($rjson));

        $data['apiurl'] = 'api/graphs/queryviz';
        $data['chordquery'] = "{$sourcequery}&agg1={$report->toptype}&sortby={$report->toporder}&q[begindate]={$report->begindate}&q[rawquery]={$nfquerystr}";
        /* If it passed all of that then its safe to pass to our relational
         * graphing mechanism. */

        // If we are calling reportviz from Nagios XI
        $api_key = grab_request_var('token', '');
        if (!empty($api_key)) {
            $data['chordquery'] .= "&token=" . $api_key;
        }

        $this->load->view('generic/reportviz', $data);
    }
}