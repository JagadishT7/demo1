<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sources extends NA_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Source', array('NOLOAD' => TRUE));
        $this->load->library('Sourcegroup', array('NOLOAD' => TRUE));
        $this->load->library('View', array('NOLOAD' => TRUE));
        $this->load->library('Query', array('NOLOAD' => TRUE));
        $this->load->library('Report', array('NOLOAD' => TRUE));
        $this->load->model('Systemstat');
        $this->page = 'sources';

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in())
        {
            if ($this->data['bypass_auth'] && ($this->uri->segment(2) == 'reports' || $this->uri->segment(2) == 'queries' || $this->uri->segment(2) == 'percentile')) {
                // Access to reports for downloading
            } else {
                redirect('login');
            }
        }

        $this->data['type'] = 'sid';

        $this->data['resolve_hosts'] = 0;
        $resolve_hosts = $this->config_option->get('resolve_hosts');
        if ($resolve_hosts->value == 1) {
            $this->data['resolve_hosts'] = 1;
        }
    }

    // Basic listing of all the sources available
    public function index()
    {
        $js = array("/js/vizhelpers.js");
        $this->init_page(lang('header_tab_sources'), 'sources', $js);

        // Reset view id
        $this->reset_view_id();

        $this->load->view('sources/home', $this->data);
    }

    // Create a new source
    public function create()
    {
        // Admin only
        if (!$this->ion_auth->is_admin()) {
            redirect('sources');
        }

        $this->init_page(lang('title_create_source'), $this->page);

        $this->form_validation->set_rules('source_name', lang('netflow_source_name'), 'required'); // Unique
        $this->form_validation->set_rules('addresses', '', '');
        $this->form_validation->set_rules('directory', '', '');
        $this->form_validation->set_rules('port', lang('listening_port'), 'required|callback_port_available'); // Unique
        $this->form_validation->set_rules('flow_type', lang('flow_type'), 'required');
        $this->form_validation->set_rules('lifetime', lang('raw_data_lifetime'), 'required');
        $this->form_validation->set_rules('lifetime_suffix', lang('lifetime_suffix'), 'required');

        if (!$this->data['demo_mode']) {
            if ($this->form_validation->run() === TRUE) {
                $lifetime = $this->input->post('lifetime') . $this->input->post('lifetime_suffix');
                $q = array("name" => $this->input->post('source_name'), 
                           "flowtype" => $this->input->post('flow_type'),
                           "addresses" => $this->input->post('addresses'),
                           "port" => $this->input->post('port'),
                           "lifetime" => $lifetime);

                // Grab the data directory if they passed one
                $directory = $this->input->post('directory');
                if (!empty($directory)) {
                    $q['directory'] = $directory;
                }

                // Grab disable abnormal behavior...
                $q['disable_abnormal'] = 0;
                $disable_abnormal = $this->input->post('disable_abnormal');
                if (!empty($disable_abnormal)) {
                    $q['disable_abnormal'] = 1;
                }

                try {
                    $s = Source::create($q);

                    // Add source to "All Sources"
                    $group = new Sourcegroup(1);
                    $group->add_source_associations($s->sid);

                    // Start source and redirect
                    $this->Systemstat->start($s->sid);
                    
                    redirect('sources');
                }
                catch (Exception $e) {
                    $this->data['message'] = $e->getMessage();
                }
            }
        } else {
            $this->data['error'] = lang('demo_mode_warning');
        }

        $this->load->view('sources/create', $this->data);
    }

    // Edit a source
    public function edit($sid)
    {
        // Admin only
        if (!$this->ion_auth->is_admin()) {
            redirect('sources');
        }
        
        $js = array("/js/summary.js", "/js/helpers.js");
        $this->init_page(lang('title_edit_source'), $this->page, $js);
        $this->reset_view_id();

        $this->form_validation->set_rules('port', lang('listening_port'), 'required');
        $this->form_validation->set_rules('lifetime', lang('raw_data_lifetime'), 'required');
        $this->form_validation->set_rules('lifetime_suffix', lang('lifetime_suffix'), 'required');

        if (!$this->data['demo_mode']) {
            if ($this->form_validation->run() === TRUE) {
                $lifetime = $this->input->post('lifetime') . $this->input->post('lifetime_suffix');
                $s = array("sid" => $sid);
                $q = array("addresses" => $this->input->post('addresses'),
                           "port" => $this->input->post('port'),
                           "lifetime" => $lifetime);

                // Grab disable abnormal behavior...
                $q['disable_abnormal'] = 0;
                $disable_abnormal = $this->input->post('disable_abnormal');
                if (!empty($disable_abnormal)) {
                    $q['disable_abnormal'] = 1;
                }

                try {
                    $source = new Source($sid);
                    $this->Systemstat->stop($sid); // Helps make it remove pid/running process
                    if ($q['port'] != $source->port) {
                        $cmd = "sudo /usr/local/nagiosna/scripts/manage_firewall.sh -p '" . intval($source->port) . "' -t udp --rem";
                        exec($cmd);
                    }
                    $source->update($q);
                    $this->Systemstat->start($sid);
                    $this->data['message'] = lang('save_source_config');
                }
                catch (Exception $e) {
                    $this->data['error'] = $e->getMessage();
                }
            }
        } else {
            $this->data['error'] = lang('demo_mode_warning');
        }

        // Get source information
        $this->data['source'] = $this->pull_source($sid);
        $this->data['source']->lifetime_suffix = substr($this->data['source']->lifetime, -1, 1);

        $this->data['tab'] = 'edit';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('sources/edit', $this->data);
    }

    // Display a source
    public function source($sid)
    {
        // Initialize page with source js
        $js = array("/js/summary.js", "/js/helpers.js");
        $this->init_page(lang('title_source_summary'), $this->page, $js);
        $this->load_view_id();

        $this->data['source'] = $this->pull_source($sid);

        if ($this->input->get('p')) {
            $p = $this->input->get('p');
            $this->data['selected_bw'] = 1;
            $this->data['bw_start'] = $p['begindate'];
            $this->data['bw_end'] = $p['enddate'];

            // Get the epoch (take off 30 mins on each side)
            $start = strtotime($p['begindate']);
            $end = strtotime($p['enddate']);
            $this->data['bw_start_epoch'] = $start - (60*30);
            $this->data['bw_end_epoch'] = $start + (60*30);
            if ($this->data['bw_end_epoch'] > time()) {
                $this->data['bw_end_epoch'] = time();
            }

        } else {
            $this->data['selected_bw'] = 0;
        }

        $this->data['tab'] = 'summary';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('generic/summary', $this->data);
    }

    // Reports
    public function reports($sid)
    {
        $js = array("/js/reports.js", "/js/summary.js");
        $this->init_page(lang('title_reports'), $this->page, $js);
        $this->load_view_id();

        // Check to see if they want to download the report
        if ($this->input->get('download') == '1') {
            $this->data['download'] = 1;
        }

        // If there is a query sent here via get - let's get the information
        $this->data['cquery'] = grab_request_var('q');
        $this->data['crid'] = grab_request_var('rid', 'null');

        // Check if we sent a view ID and need to change our view...
        if (!empty($this->data['cquery']['vid'])) {
            $this->data['view_id'] = $this->data['cquery']['vid'];
        }

        $this->data['source'] = $this->pull_source($sid);

        $this->data['tab'] = 'reports';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('generic/reports', $this->data);
    }

    // Queries
    public function queries($sid)
    {
        $js = array("/js/helpers.js", "/js/summary.js", "/js/queries.js");
        $this->init_page(lang('title_queries'), $this->page, $js);
        $this->load_view_id();

        // Check to see if they want to download the report
        if ($this->input->get('download') == '1') {
            $this->data['download'] = 1;
        }

        // If there is a query sent here via get - let's get the information
        $this->data['cquery'] = grab_request_var('q');
        $this->data['cqid'] = grab_request_var('qid', 'null');

        // Check if we sent a view ID and need to change our view...
        if (!empty($this->data['cquery']['vid'])) {
            $this->data['view_id'] = $this->data['cquery']['vid'];
        }
        
        // Setup our source, gets its various information
        $this->data['source'] = $this->pull_source($sid);
        
        $this->data['tab'] = 'queries';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('generic/queries', $this->data);
    }

    // Views
    public function views($sid)
    {
        $js = array("/js/helpers.js", "/js/summary.js");
        $this->init_page(lang('title_views'), $this->page, $js);
        $this->load_view_id();
        
        // Setup our source, gets its various information
        $this->data['source'] = $this->pull_source($sid);

        $this->data['tab'] = 'views';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('sources/views', $this->data);
    }
    
    public function percentile($sid)
    {
        $js = array("/js/helpers.js", "/js/summary.js");
        $this->init_page(lang('title_percentile'), $this->page, $js);
        $this->load_view_id();

        $this->data['cquery'] = grab_request_var('q');

        // Check if we sent a view ID and need to change our view...
        if (!empty($this->data['cquery']['vid'])) {
            $this->data['view_id'] = $this->data['cquery']['vid'];
        }
        
        // Setup our source, gets its various information
        $this->data['source'] = $this->pull_source($sid);

        $this->data['tab'] = 'percentile';
        $this->data['tabs'] = $this->load->view('sources/tabs', $this->data, true); 
        $this->load->view('generic/percentile', $this->data);
    }

    public function summaryviz($sid)
    {
        $this->data['sid'] = $sid;
        $this->data['vid'] = grab_request_var('vid', NULL);
        $this->data['begindate'] = grab_request_var('begindate', '-30 minutes');
        $this->data['enddate'] = grab_request_var('enddate', '-1 second');
        $this->data['type'] = grab_request_var('type', 'bytes');
        
        $this->load->view('generic/summaryviz', $this->data);
    }
    
    // Return all source information
    private function pull_source($sid)
    {
        // Get source information
        $source = new Source($sid);
        $source->status = $this->Systemstat->source_status($sid);
        return $source;
    }
}
