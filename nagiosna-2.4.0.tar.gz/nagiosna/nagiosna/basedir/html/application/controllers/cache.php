<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cache extends NA_Controller {
    
    function __construct()
    {
        parent::__construct();
        if(!$this->input->is_cli_request()) {
            die("Not a cli request.");
        }
        $this->load->dbutil();
    }

    // Let's check if we should update the cache
    function index()
    {
        $this->info_logging = 0;
        $now = time();

        if ($this->info_logging) {
            print "Upating cached hostnames...";
        }

        // Get the cached time settings
        $ct = $this->config_option->get('cache_time');
        $cache_time = $ct->value;
        
        // Run the command to update if there are any cached hosts to update
        $c = $this->db->get('nagiosna_hostname_cache');
        foreach ($c->result() as $cached) {
            if ($cached->time+$cache_time < $now) {
                $hostname = gethostbyaddr($cached->ip);
                $data = array('hostname' => $hostname,
                              'time' => $now);
                $this->db->where('id', $cached->id);
                $this->db->update('nagiosna_hostname_cache', $data);
            }
        }

        // Finish by optimizing the table...
        $this->dbutil->optimize_table('nagiosna_hostname_cache');

        if ($this->info_logging) {
            print "Finished updating cached hostnames.\n";
        }
    }

}