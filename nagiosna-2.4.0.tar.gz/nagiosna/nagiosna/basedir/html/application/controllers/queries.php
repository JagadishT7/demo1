<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Queries extends NA_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Source', array('NOLOAD' => TRUE));
        $this->load->library('View', array('NOLOAD' => TRUE));
        $this->load->library('Query', array('NOLOAD' => TRUE));
        $this->load->library('Report', array('NOLOAD' => TRUE));
        $this->load->library('Sourcegroup', array('NOLOAD' => TRUE));

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in())
        {
            redirect('login');
        }
    }

	public function index()
	{
	    $this->init_page(lang('title_queries'), 'queries');

	    $this->load->view('queries/home', $this->data);
	}

    // Show the relational mapping of the flows in the source
    public function queryviz()
    {
        $q = grab_request_var('q', array());
        $sid = grab_request_var('sid', NULL);
        $gid = grab_request_var('gid', NULL);
        $qid = grab_request_var('qid', NULL);
        $sortby = grab_request_var('sortby', 'bytes');
        $vid = grab_request_var('vid', NULL);

        try {
            /* Validate our input */
            if(validate_toporder($sortby) === FALSE) {
                throw new Exception(lang('exception_qviz_sortby'));
            }
            
            /* Get our source items */
            if(empty($sid) === FALSE) {
                $sourcequery = "sid={$sid}";
            } else if (empty($gid) === FALSE) {
                $sourcequery = "gid={$gid}";
            }
            else {
                throw new Exception(lang('exception_no_source'));
            }
            
            if(empty($vid) === FALSE) {
                $sourcequery .= "&vid={$vid}";
            }
            
            /* Get our query */
            if(empty($qid) === FALSE) {
                $query = "qid={$qid}";
            }
            else if(empty($q) === FALSE) {
                $queryobj = new Query($q);
                $assembler = array();
                foreach($q as $key => $value) {
                    $assembler[] = "q[{$key}]={$value}";
                }
                $query = implode('&', $assembler);
            }
        }
        catch (Exception $e) {
            $json['error'] = $e->getMessage();
            print json_encode($json);
        }
        
        $ag = explode(',', $queryobj->aggregate_csv);
        
        switch($ag[0]) {
            case 'srcport':
            case 'dstport':
                $agg1 = 'srcport';
                $agg2 = 'dstport';
                break;
            case 'srcip':
            case 'dstip':
            default:
                $agg1 = 'dstip';
                $agg2 = 'srcip';
                break;
        }

        $data['apiurl'] = 'api/graphs/queryviz';
        $data['apiquery'] = "{$sourcequery}&{$query}&agg1={$agg1}&agg2={$agg2}&sortby={$sortby}";
        /* If it passed all of that then its safe to pass to our relational
         * graphing mechanism. */

        // If we are calling reportviz from Nagios XI
        $api_key = grab_request_var('token', '');
        if (!empty($api_key)) {
            $data['chordquery'] .= "&token=" . $api_key;
        }

        $this->load->view('generic/queryviz', $data);
    }
}