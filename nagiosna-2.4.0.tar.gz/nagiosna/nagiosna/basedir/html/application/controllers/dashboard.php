<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends NA_Controller
{
    function __construct()
    {
        parent::__construct();

        // Make sure that user is authenticated no matter what page they are on
        require_install();
        if (!$this->ion_auth->logged_in()) { redirect('login'); }
    }

    // Logs out user
    function logout()
    {
        //log the user out
        $logout = $this->ion_auth->logout();

        //redirect them to the login page
        $this->session->set_flashdata('message', $this->ion_auth->messages());
        redirect('login', 'refresh');
    }

    // Basic dashboard
    public function index()
    {
        $js = array('/js/vizhelpers.js');
        $this->init_page(lang('title_dashboard'), 'dashboard', $js);

        $this->data['hide_dashlet'] = unserialize(get_usermeta('hide_dashlets'));

        $this->load->view('dashboard', $this->data);
    }

    // Basic user profile (can't do much here - requires auth to change certain things)
    // - for api key mostly
    public function profile()
    {
        $this->init_page(lang('profile_heading'), 'profile');

        $this->data['user'] = $this->ion_auth->user()->row();

        // Get all languages
        $languages = array();
        $path = "/var/www/html/nagiosna/application/language";
        $results = scandir($path);
        foreach ($results as $r) {
            if ($r === '.' || $r === '..' || $r === '.svn') { continue; }
            if (is_dir($path . '/' . $r)) {
                $languages[] = $r;
            }
        }
        $this->data['languages'] = $languages;

        $this->load->view('profile', $this->data);
    }

    public function newkey()
    {
        // Generate a new API key
        $newkey = sha1(uniqid() . 'nnaapikey');

        // Update new key in database
        $user_id = $this->session->userdata('user_id');
        $verify_user_id = $this->input->post('user_id_verify', TRUE);

        if ($user_id == $verify_user_id) {
            // Update the new api key
            $this->db->where('id', $user_id);
            $this->db->update(DB_TABLE_USERS, array('apikey' => $newkey));
        }

        // Set session data
        $this->session->set_userdata('apikey', $newkey);

        redirect('profile');
    }

    public function setlanguage()
    {
        $user_id = $this->session->userdata('user_id');
        $language = $this->input->post('language');

        // Update db
        $this->db->where('id', $user_id);
        $this->db->update(DB_TABLE_USERS, array('lang' => $language));

        // Update session
        $this->session->set_userdata('language', $language);
    }

    public function save_dashboard_settings()
    {
        $sources = $this->input->post('sources');
        $checks = $this->input->post('checks');
        $abnormal = $this->input->post('abnormal');

        // Save into the database...
        $hide_dashlet = array("sources" => intval($sources),
                              "checks" => intval($checks),
                              "abnormal" => intval($abnormal));
        set_usermeta('hide_dashlets', serialize($hide_dashlet));
    }

    public function download($type, $stype, $id, $pdf_gen_uri)
    {
        $fn = '/tmp/page.pdf';
        $scheme = (!empty($_SERVER['HTTPS'])) ? 'https' : 'http';
        $url = $scheme.'://localhost/nagiosna/index.php';
        $base = '/';

        if ($stype == "source") {
            $base .= "sources";
        } else if ($stype == "sourcegroup") {
            $base .= "groups";
        }

        if ($type == "report") {
            $base .= "/reports";
            $title = "Network Analyzer Report";
            $orientation = "Portrait";
        } else if ($type == "query") {
            $base .= "/queries";
            $title = "Network Analyzer Query";
            $orientation = "Landscape";
        } else if ($type == "percentile") {
            $base .= "/percentile";
            $title = "Percentile Calculator";
            $orientation = "Portrait";
        } else {
            echo "Can not create a report of unknown type.";
            return;
        }

        // Get the main users api key...
        $this->db->select('apikey');
        $this->db->from('nagiosna_users');
        $this->db->where(array('id' => 1));
            
        $query = $this->db->get();
        $result = $query->row();
        $apikey = $result->apikey;

        $auth = 'download=1&token='.$apikey.'&';

        // Put the entire URL together
        $base .= "/".$id;
        $uri = base64_decode($pdf_gen_uri);
        $url .= $base . "?" . $auth . $uri;

        // Run the report generating command
        $cmd = '/usr/local/bin/wkhtmltopdf --no-outline -O '.escapeshellarg($orientation).' --footer-spacing 3 --margin-bottom 14mm --footer-font-size 9 --footer-left '.escapeshellarg($title).' --footer-right "Page [page] of [toPage]" '.escapeshellarg($url).' '.escapeshellarg($fn);
        shell_exec($cmd);

        if (!file_exists($fn)) {
            echo "ERROR: Failed to render report as '" . $fn;
        } else {
            // We'll be outputting a PDF
            header('Content-type: application/pdf');
            header('Content-Disposition: inline; filename="'.$type.'.pdf"');

            // Read and then remove the pdf file from temp directory
            readfile($fn);
            unlink($fn);
        }
    }
}