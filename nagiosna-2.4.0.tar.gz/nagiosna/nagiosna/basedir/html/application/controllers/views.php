<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Views extends NA_Controller
{
    function __construct()
    {
        parent::__construct();

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in())
        {
            redirect('login');
        }
    }

	public function index()
	{
	    $this->init_page(lang('title_views'), 'views');

	    $this->load->view('views/home', $this->data);
	}
}