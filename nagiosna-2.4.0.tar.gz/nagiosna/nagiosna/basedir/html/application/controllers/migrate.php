<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Migrate extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('migration');
        $this->output->enable_profiler(FALSE);
        
        // Do a integrity check
        $this->load->model('integrity');
        //$this->integrity->check();
    }

	/**
	 * Index Page for this controller.
	 */
	public function run()
	{
        if (!defined('STDIN')) {
            flash_error('Migrations cannot be performed via the web interface. Please invoke the migration by using command line tools.');
            redirect('incidents');
        }
        if (!$this->migration->current()) {
            echo $this->migration->error_string()."\n";
            exit(1);
        } else {
            echo "The database was migrated successfully.\n";
            exit(0);
        }
	}
}
