<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Alerting extends NA_Controller
{
    function __construct()
    {
        parent::__construct();

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in())
        {
            redirect('login');
        }

        if (!$this->ion_auth->is_admin()) {
            redirect('');
        }

        $this->page = 'alerting';
    }

    public function index()
    {
        $this->init_page(lang('header_tab_alerting'), $this->page);
        
        // Initialize page with source js

        $this->data['tab'] = 'checks';
        $this->data['tabs'] = $this->load->view('alerting/tabs', $this->data, true);
        $this->load->view('alerting/checks', $this->data);
    }
    
    public function servers()
    {
        // Initialize page with source js
        $this->init_page(lang('header_tab_alerting'), $this->page);

        $this->data['tab'] = 'servers';
        $this->data['tabs'] = $this->load->view('alerting/tabs', $this->data, true);
        $this->load->view('alerting/servers', $this->data);
    }
    
    public function snmp()
    {
        $this->init_page(lang('header_tab_alerting'), $this->page);

        $this->data['tab'] = 'snmp';
        $this->data['tabs'] = $this->load->view('alerting/tabs', $this->data, true);
        $this->load->view('alerting/snmp', $this->data);
    }

    public function commands()
    {
        $this->init_page(lang('header_tab_commands'), $this->page);

        $this->data['tab'] = 'commands';
        $this->data['tabs'] = $this->load->view('alerting/tabs', $this->data, true);
        $this->load->view('alerting/commands', $this->data);
    }
}
