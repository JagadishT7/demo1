<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Groups extends NA_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Sourcegroup', array('NOLOAD' => TRUE));
        $this->page = 'groups';

        // Make sure that user is authenticated no matter what page they are on
        if (!$this->ion_auth->logged_in())
        {
            if ($this->data['bypass_auth'] && ($this->uri->segment(2) == 'reports' || $this->uri->segment(2) == 'queries' || $this->uri->segment(2) == 'percentile')) {
                // Access to reports for downloading
            } else {
                redirect('login');
            }
        }

        $this->data['type'] = 'gid';

        $this->data['resolve_hosts'] = 0;
        $resolve_hosts = $this->config_option->get('resolve_hosts');
        if ($resolve_hosts->value == 1) {
            $this->data['resolve_hosts'] = 1;
        }
    }

    // Basic listing of all the source groups available
    public function index()
    {
        $this->init_page(lang('breadcrumb_sourcegroups'), $this->page);

        $this->load->view('sourcegroups/home', $this->data);
    }

    // Create a new source group
    public function create()
    {
        // Admin only
        if (!$this->ion_auth->is_admin()) {
            redirect('groups');
        }

        $this->init_page(lang('title_create_sg'), $this->page);
        $this->load->view('sourcegroups/create', $this->data);
    }

    // Edit a source group
    public function edit($gid)
    {
        // Admin only
        if (!$this->ion_auth->is_admin() || $gid == 1) {
            redirect('groups');
        }

        $js = array("/js/summary.js", "/js/helpers.js");
        $this->init_page(lang('title_edit_sg'), $this->page, $js);

        $this->data['group'] = $this->pull_group($gid);

        $this->data['tab'] = 'edit';
        $this->data['tabs'] = $this->load->view('sourcegroups/tabs', $this->data, true); 
        $this->load->view('sourcegroups/edit', $this->data);
    }

    // Display a source group
    public function group($gid)
    {
        // Initialize page with source js
        $js = array("/js/summary.js", "/js/helpers.js");
        $this->init_page(lang('title_sg_summary'), $this->page, $js);

        $this->data['group'] = $this->pull_group($gid);
        $this->data['selected_bw'] = 0;

        $this->data['tab'] = 'summary';
        $this->data['tabs'] = $this->load->view('sourcegroups/tabs', $this->data, true); 
        $this->load->view('generic/summary', $this->data);
    }

    // Reports
    public function reports($gid)
    {
        $js = array("/js/reports.js", "/js/summary.js");
        $this->init_page(lang('title_reports'), $this->page, $js);

        // Check to see if they want to download the report
        if ($this->input->get('download') == '1') {
            $this->data['download'] = 1;
        }

        $this->data['cquery'] = grab_request_var('q');
        $this->data['crid'] = grab_request_var('rid', 'null');

        // Check if we sent a view ID and need to change our view...
        if (!empty($this->data['cquery']['vid'])) {
            $this->data['view_id'] = $this->data['cquery']['vid'];
        }

        $this->data['group'] = $this->pull_group($gid);

        $this->data['tab'] = 'reports';
        $this->data['tabs'] = $this->load->view('sourcegroups/tabs', $this->data, true); 
        $this->load->view('generic/reports', $this->data);
    }

    // Queries
    public function queries($gid)
    {
        $js = array("/js/helpers.js", "/js/summary.js", "/js/queries.js");
        $this->init_page(lang('title_queries'), $this->page, $js);

        // Check to see if they want to download the report
        if ($this->input->get('download') == '1') {
            $this->data['download'] = 1;
        }

        // If there is a query sent here via get - let's get the information
        $this->data['cquery'] = grab_request_var('q');
        $this->data['cqid'] = grab_request_var('qid', 'null');

        // Check if we sent a view ID and need to change our view...
        if (!empty($this->data['cquery']['vid'])) {
            $this->data['view_id'] = $this->data['cquery']['vid'];
        }

        // Setup our source, gets its various information
        $this->data['group'] = $this->pull_group($gid);
        
        $this->data['tab'] = 'queries';
        $this->data['tabs'] = $this->load->view('sourcegroups/tabs', $this->data, true); 
        $this->load->view('generic/queries', $this->data);
    }

    // Percentile calculator
    public function percentile($gid)
    {
        $js = array("/js/helpers.js", "/js/summary.js");
        $this->init_page(lang('title_percentile'), $this->page, $js);

        $this->data['cquery'] = grab_request_var('q');

        // Setup our source, gets its various information
        $this->data['group'] = $this->pull_group($gid);
        
        $this->data['tab'] = 'percentile';
        $this->data['tabs'] = $this->load->view('sourcegroups/tabs', $this->data, true); 
        $this->load->view('generic/percentile', $this->data);
    }

    private function pull_group($gid)
    {
        $group = new Sourcegroup($gid);
        return $group;
    }
}