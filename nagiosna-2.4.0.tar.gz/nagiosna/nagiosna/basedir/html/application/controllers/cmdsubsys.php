<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cmdsubsys extends NA_Controller {
    
    function __construct()
    {
        parent::__construct();
        if(!$this->input->is_cli_request()) {
            die("Not a cli request.");
        }
    }

    /***************************************
     * Subsystem commands
     ***************************************/

    function process_cmds()
    {
        // Grab all jobs in the DB and run them
        $sql = "SELECT * FROM nagiosna_cmdsubsys WHERE processing = 0 AND completed = 0;";
        $q = $this->db->query($sql);

        $cmds = 0;
        if ($q->num_rows() < 1) {
            print ".";
            return;
        }

        foreach ($q->result() as $cmd) {

            $sql = "UPDATE nagiosna_cmdsubsys SET processing = 1 WHERE id = '".$cmd->id."';";
            $this->db->query($sql);
            $args = unserialize($cmd->args);

            print "Running command...\n\n";

            // Process the query
            switch ($cmd->command) {

                // Change timezone
                case COMMAND_CHANGE_TIMEZONE:
                    $c = "sudo /usr/local/nagiosna/scripts/change_timezone.sh -z '".$args['timezone']."'";
                    exec($c, $output, $return);
                    break;

                case COMMAND_UPDATE_TO_LATEST:
                    $file = 'https://assets.nagios.com/downloads/nagios-network-analyzer/nagiosna-latest.tar.gz';
                    $c = "sudo /usr/local/nagiosna/scripts/upgrade_to_latest.sh -f '$file'";
                    exec($c, $output, $return);
                    break;

                case COMMAND_RUN_BACKUP:
                    $c = "/usr/local/nagiosna/scripts/backup_na.sh -n '" . $args['name'] . "'";
                    exec($c, $output, $return);
                    break;
            }

            // Update the database to show we completed the command
            $sql = "UPDATE nagiosna_cmdsubsys SET completed = 1, processing = 0 WHERE id = '".$cmd->id."';";
            $this->db->query($sql);

            if ($return == 0) {
                print "Command completed. OK.";
            } else {
                print "Command did not complete successfully. ERROR.";
            }
            print "\n\n";
            $cmds ++;
        }

        print "PROCESSED $cmds COMMANDS.\n\n";
    }

    function cleanup_db()
    {
        $cleanup_timestamp = time() - (24 * 60 * 60);
        $sql = "DELETE FROM nagiosna_cmdsubsys WHERE timestamp < '".$cleanup_timestamp."' AND completed = 1;";
        $this->db->query($sql);
    }
    
    function index()
    {
        $max_time = 50;
        $sleep_time = 15; // in seconds
        $this->logging = 1;
        $start_time = time();

        while(1) {

            // Bail if if we're been here too long
            $now = time();
            if (($now-$start_time) > $max_time) {
                break;
            }
                
            $this->process_cmds();

            usleep($sleep_time*100000);
        }

        $this->cleanup_db();

        if ($this->logging) {
            print "Finished running commands.\n";
        }
    }
}