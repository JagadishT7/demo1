<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Reserved routes
$route['default_controller'] = 'dashboard';
$route['404_override'] = '';

// Auth stuff
$route['login'] = 'auth/login';
$route['forgot_password'] = 'auth/forgot_password';
$route['reset_password/(:any)'] = 'auth/reset_password/$1';
$route['logout'] = 'dashboard/logout';

// Profile
$route['profile'] = 'dashboard/profile';
$route['profile/password'] = 'auth/change_password';
$route['profile/newkey'] = 'dashboard/newkey';

// Install/enter key
$route['enterkey'] = 'install/enterkey';

// Sources
$route['sources/(:num)'] = 'sources/source/$1';

// Source groups
$route['groups/(:num)'] = 'groups/group/$1';

// User section
$route['admin/users/create'] = 'admin/create_user';
$route['admin/users/delete'] = 'admin/delete_user';
$route['admin/users/edit/(:num)'] = 'admin/edit_user/$1';
$route['admin/users/import'] = 'admin/user_import';
$route['admin/users/import/step2'] = 'admin/user_import_step2';
$route['admin/users/import/complete'] = 'admin/user_import_complete';

// Backup section
$route['admin/backup/download/(:any)'] = 'admin/download_backup/$1';
$route['admin/backup/delete/(:any)'] = 'admin/delete_backup/$1';

// Downloading PDF
$route['download/(:any)/(:any)/(:num)/(:any)'] = 'dashboard/download/$1/$2/$3/$4';