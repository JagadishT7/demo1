<?php 
$config['email']['useragent'] = 'NagiosNA Mailer';
$config['email']['protocol'] = 'mail';
