<?php

/* Probably won't change */
$lang['nna'] = 'Nagios Network Analyzer';
$lang['ne'] = 'Nagios Enterprises, LLC';

/* Errors */
$lang['error_csrf'] = 'This form post did not pass our security checks.';
$lang['demo_mode_warning'] = "This action is not available in Demo Mode.";

// Account Creation
$lang['account_creation_successful'] 	  	 = 'Account Successfully Created';
$lang['account_creation_unsuccessful'] 	 	 = 'Unable to Create Account';
$lang['account_creation_duplicate_email'] 	 = 'Email Already Used or Invalid';
$lang['account_creation_duplicate_username'] = 'Username Already Used or Invalid';

// Password
$lang['password_change_successful'] 	 	 = 'Password Successfully Changed';
$lang['password_change_unsuccessful'] 	  	 = 'Unable to Change Password';
$lang['forgot_password_successful'] 	 	 = 'Password Reset Email Sent';
$lang['forgot_password_unsuccessful'] 	 	 = 'Unable to Reset Password';

// Login / Logout
$lang['login_successful'] 		  	         = 'Logged In Successfully';
$lang['login_unsuccessful'] 		  	     = 'Incorrect Login';
$lang['login_unsuccessful_not_active'] 		 = 'Account is inactive';
$lang['login_timeout']                       = 'Temporarily Locked Out.  Try again later.';
$lang['logout_successful'] 		 	         = 'Logged out successfully';

// Account Changes
$lang['update_successful'] 		 	         = 'Account Information Successfully Updated';
$lang['update_unsuccessful'] 		 	     = 'Unable to Update Account Information';
$lang['delete_successful']               	 = 'User Deleted';
$lang['delete_unsuccessful']           		 = 'Unable to Delete User';

// Email Subjects
$lang['email_forgotten_password_subject']    = 'Forgotten Password Verification';

/* Singles */
$lang['actions'] = 'Actions';
$lang['yes_button'] = 'Yes';
$lang['no_button'] = 'No';
$lang['save_button'] = 'Save';
$lang['create_button'] = 'Create';
$lang['update_button'] = 'Update';
$lang['cancel_button'] = 'Cancel';
$lang['language'] = 'Language';
$lang['or'] = 'or';
$lang['admin'] = 'Admin';
$lang['about'] = 'About';
$lang['legal'] = 'Legal';
$lang['hours'] = 'Hours';
$lang['days'] = 'Days';
$lang['weeks'] = 'Weeks';
$lang['stop'] = 'Stop';
$lang['start'] = 'Start';
$lang['restart'] = 'Restart';
$lang['delete'] = 'Delete';
$lang['loading'] = 'Loading...';
$lang['clear'] = 'Clear';
$lang['select_all'] = 'Select All';
$lang['query'] = 'Query';
$lang['run'] = 'Run';
$lang['edit'] = 'Edit';
$lang['download'] = 'Download';
$lang['rename'] = 'Rename';
$lang['external_api'] = 'External API';
$lang['load'] = 'Load';
$lang['view'] = 'View';
$lang['default'] = 'Default';
$lang['change'] = 'Change';
$lang['add'] = 'Add';
$lang['running'] = 'Running';
$lang['to'] = 'to';
$lang['ago'] = 'ago';
$lang['copyright'] = 'Copyright';
$lang['date_range'] = 'Date Range';
$lang['custom_report'] = 'Custom Report';
$lang['no_data'] = 'No Data.';
$lang['flow_start'] = 'Flow Start';
$lang['flow_end'] = 'Flow End';
$lang['duration'] = 'Duration';
$lang['email'] = 'Email';
$lang['phone'] = 'Phone';
$lang['fax'] = 'Fax';
$lang['view_edit'] = 'View / Edit';
$lang['no_view'] = 'No View';
$lang['and'] = 'And';
$lang['where_the'] = 'Where The';
$lang['port'] = 'Port';
$lang['ip'] = 'IP';
$lang['network'] = 'Network';
$lang['is'] = 'is';
$lang['is_not'] = 'is not';
$lang['required'] = 'required';
$lang['percentage_of'] = 'Percentage of';
$lang['ip_address'] = 'IP Address';
$lang['netflow_source_name'] = 'Netflow Source Name';
$lang['listening_port'] = 'Listening Port';
$lang['flow_type'] = 'Flow Type';
$lang['raw_data_lifetime'] = 'Raw Data Lifetime';
$lang['raw_data'] = 'raw data';
$lang['lifetime_suffix'] = 'Lifetime Suffix';
$lang['close'] = "Close";
$lang['api_show'] = "Use Via HTTP";
$lang['req'] = "Required";
$lang['error'] = "Error";
$lang['download_pdf'] = "Download PDF";
$lang['running_on_view'] = "Running on view";
$lang['aggregated_by'] = "aggregated by";
$lang['showing'] = "Showing";
$lang['for_query'] = "for query";
$lang['enabled'] = 'Enabled';
$lang['disabled'] = 'Disabled';
$lang['active_directory'] = 'Active Directory';
$lang['ldap'] = 'LDAP';
$lang['no_servers'] = 'No Servers';
$lang['type'] = 'Type';
$lang['encryption'] = 'Encryption';
$lang['remove_server'] = 'Remove server';
$lang['associated_users'] = 'Associated Users';
$lang['servers'] = 'Server(s)';
$lang['ldap_server'] = 'LDAP Server';
$lang['ad_server'] = 'AD Server';
$lang['name'] = 'Name';
$lang['next'] = 'Next';
$lang['advanced_settings'] = 'Advanced Settings';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['select_none'] = 'Select None';
$lang['user'] = 'User';
$lang['user_type'] = 'User Type';
$lang['api_access'] = 'API Access';
$lang['nnafooter'] = "Nagios NA";

$lang['rle_1'] = 'This report runs on';
$lang['rle_1_alt'] = 'This query runs on';
$lang['rle_2'] = 'Your current start time';
$lang['rle_3'] = 'is longer than your raw data lifetime';
$lang['rle_4'] = 'You will only be seeing the last';
$lang['rle_5'] = 'of data';

$lang['data_directory'] = 'Data Directory';
$lang['data_directory_desc'] = 'The directory where the source\'s flow data is stored. The directory above requires <strong>nna:users at 775</strong> permissions to be written to. Will create a <strong>folder</strong> with the clean <strong>source name</strong> inside the directory given.';

$lang['show_api_header'] = "How to Use the API Via HTTP Calls";
$lang['show_api_body'] = "Using the API Key for your user you can make HTTP API calls. The examples below are using the current api query as an example.";
$lang['show_api_get'] = "GET Example";
$lang['show_api_post'] = "POST Example";

/* User Types */
$lang['user_level'] = 'User (Read Only)';
$lang['admin_level'] = 'Admin (Full Access)';

/* Graphs */
$lang['pie_chart'] = 'Pie Chart';
$lang['relational_mapping'] = 'Relational Mapping';
$lang['chord_diagram'] = 'Chord Diagram';
$lang['fullscreen_chord'] = 'Show full size chord diagram';
$lang['fullscreen_pie'] = 'Show full size pie chart';
$lang['guage_cpu'] = 'CPU';
$lang['guage_disk'] = 'Disk';
$lang['guage_mem'] = 'Memory';
$lang['guage_swap'] = 'Swap';

/* Selections */
$lang['source_ip'] = 'Source IP';
$lang['destination_ip'] = 'Destination IP';
$lang['source_host'] = 'Source Hostname';
$lang['destination_host'] = 'Destination Hostname';
$lang['source_port'] = 'Source Port';
$lang['destination_port'] = 'Destination Port';
$lang['flows'] = 'Flows';
$lang['packets'] = 'Packets';
$lang['bytes'] = 'Bytes';
$lang['bits_sec'] = 'Bits/Sec';
$lang['packets_sec'] = 'Packets/Sec';
$lang['bytes_packet'] = 'Bytes/Packet';
$lang['destination'] = 'Destination';
$lang['source'] = 'Source';
$lang['either'] = 'Destination or Source';

/* States */
$lang['ok'] = 'OK';
$lang['warning'] = 'WARNING';
$lang['critical'] = 'CRITICAL';
$lang['unknown'] = 'UNKNOWN';
$lang['pending'] = 'PENDING';

/* Time Ranges & Select Menus */
$lang['timerange_2hrs'] = 'Last 2 Hours';
$lang['timerange_4hrs'] = 'Last 4 Hours';
$lang['timerange_6hrs'] = 'Last 6 Hours';
$lang['timerange_12hrs'] = 'Last 12 Hours';
$lang['timerange_24hrs'] = 'Last 24 Hours';
$lang['timerange_2days'] = 'Last 2 Days';
$lang['timerange_week'] = 'Last Week';
$lang['timerange_month'] = 'Last Month';
$lang['timerange_custom_range'] = 'Custom Date Range';
$lang['timerange_custom_elapsed'] = 'Custom Elapsed Time';
$lang['timerange_elsapsed_desc'] = 'The available time types are seconds, minutes, hours, days, weeks, months, years (examples: 2 days or 1 month)';

/* Breadcrumbs */
$lang['breadcrumb_source'] = 'Source';
$lang['breadcrumb_sourcegroup'] = 'Source Group';
$lang['breadcrumb_sourcegroups'] = 'Source Groups';
$lang['breadcrumb_edit_user'] = 'Edit User';
$lang['breadcrumb_users'] = 'Users';
$lang['breadcrumb_create_user'] = 'Create User';
$lang['breadcrumb_license'] = 'Update License';
$lang['breadcrumb_snmp'] = 'SNMP';
$lang['breadcrumb_servers'] = 'Servers';
$lang['breadcrumb_checks'] = 'Checks';
$lang['breadcrumb_globals'] = 'Global Settings';
$lang['breadcrumb_ldap_ad_servers'] = 'LDAP/AD Integration';
$lang['breadcrumb_commands'] = 'Commands';
$lang['breadcrumb_percentile'] = 'Percentile Calculator';
$lang['breadcrumb_ldap_ad_add_server'] = 'Add LDAP/AD Server';
$lang['breadcrumb_ldap_ad_edit_server'] = 'Edit LDAP/AD Server';
$lang['breadcrumb_backup'] = 'System Backup';

/* Languages */
$lang['language_english'] = 'English';
$lang['language_japanese'] = 'Japanese';
$lang['language_german'] = 'German';
$lang['language_spanish'] = 'Spanish';
$lang['language_french'] = 'French';
$lang['language_italian'] = 'Italian';
$lang['language_korean'] = 'Korean';
$lang['language_portuguese'] = 'Portuguese';
$lang['language_russian'] = 'Russian';
$lang['language_japanese'] = 'Japanese';

/* header.php */
$lang['header_notice'] = 'Notice';
$lang['header_expiration_pre'] = 'This copy of Nagios Network Analyzer will expire in';
$lang['header_expiration_post'] = 'days';
$lang['header_purchase_license'] = 'Purchase a license';
$lang['header_enter_license'] = 'enter it now';
$lang['header_acct_type'] = 'Your account type';
$lang['header_username'] = 'Your username';
$lang['header_tab_dashboard'] = 'Dashboard';
$lang['header_tab_sources'] = 'Sources';
$lang['header_tab_sourcegroups'] = 'Source Groups';
$lang['header_tab_views'] = 'Views';
$lang['header_tab_reports'] = 'Reports';
$lang['header_tab_queries'] = 'Queries';
$lang['header_tab_alerting'] = 'Alerting';
$lang['header_tab_help'] = 'Help';
$lang['header_tab_configure'] = 'Administration';
$lang['header_tab_logout'] = 'Log Out';
$lang['header_tab_login'] = 'Log In';
$lang['header_tab_install'] = 'Install';
$lang['header_tab_enterkey'] = 'Enter License Key';
$lang['header_tab_commands'] = 'Commands';

/* footer.php */
$lang['footer_check_updates'] = 'Check for updates';

/* dashboard.php */
$lang['dashboard_checks'] = 'Alert Summary';
$lang['dashboard_checks_ok'] = 'Ok';
$lang['dashboard_checks_warning'] = 'Warning';
$lang['dashboard_checks_critical'] = 'Critical';
$lang['dashboard_checks_all'] = 'All';
$lang['dashboard_checks_table_name'] = 'Check Name';
$lang['dashboard_checks_table_status'] = 'Status';
$lang['dashboard_checks_table_message'] = 'Check Message';
$lang['dashboard_checks_none_found'] = 'No entries';

$lang['dashboard_system'] = 'System Dashboard';
$lang['dashboard_system_cpu'] = 'Server CPU Load';
$lang['dashboard_system_disk'] = 'Disk Usage';
$lang['dashboard_system_memory'] = 'Memory Usage';
$lang['dashboard_system_swap'] = 'Swap Usage';
$lang['dashboard_system_table_name'] = 'Name';
$lang['dashboard_system_table_usage'] = 'Usage';
$lang['dashboard_system_table_status'] = 'Status';

$lang['dashboard_aberrant'] = 'Abnormal Behavior';
$lang['dashboard_aberrant_popover_title'] = 'Status Information';
$lang['dashboard_aberrant_popover_normal'] = 'The source appears to be reporting normal bandwidth.';
$lang['dashboard_aberrant_popover_abnormal'] = 'The source appears to have irregular traffic at this time.';
$lang['dashboard_aberrant_timeframe_title'] = 'Time frame Information';
$lang['dashboard_aberrant_timeframe_tt1'] = 'Top Talking Source Port';
$lang['dashboard_aberrant_timeframe_tt2'] = 'Top Talking Source IP';
$lang['dashboard_aberrant_timeframe_tt3'] = 'Top Talking Destination Port';
$lang['dashboard_aberrant_timeframe_tt4'] = 'Top Talking Destination IP';
$lang['dashboard_aberrant_view_problem'] = 'View Problem';
$lang['dashboard_aberrant_title'] = 'Source';

$lang['dashboard_sources'] = 'Pinned Sources';
$lang['dashboard_sources_link'] = 'View All';
$lang['dashboard_sources_table_status'] = 'Status';
$lang['dashboard_sources_table_name'] = 'Source Name';
$lang['dashboard_sources_pin'] = 'Successfully pinned to the dashboard!';
$lang['dashboard_sources_unpin'] = 'Unpinned from the dashboard!';
$lang['dashboard_manage_link'] = 'Manage';

$lang['dashboard_close'] = 'Close';
$lang['dashboard_open'] = 'Open';

/* profile.php */
$lang['profile_heading'] = 'My Profile';
$lang['profile_desc'] = 'Edit your profile, contact information, and account information. You may also manage your API key.';
$lang['profile_info_heading'] = 'Personal Info';
$lang['profile_info_desc'] = 'Your personal information and account name.';
$lang['profile_username'] = 'Username';
$lang['profile_full_name'] = 'Full Name';
$lang['profile_company'] = 'Company';
$lang['profile_email'] = 'Email';
$lang['profile_phone'] = 'Phone';
$lang['profile_actions_heading'] = 'Account Actions';
$lang['profile_actions_desc'] = 'Make changes to your account-specific settings.';
$lang['profile_change_password'] = 'Change Password';
$lang['profile_change_password_desc'] = 'Your new password must be 8 or more characters long for security.';
$lang['profile_change_password_old'] = 'Old Password';
$lang['profile_change_password_new'] = 'New Password';
$lang['profile_change_password_new_conf'] = 'Confirm New Password';
$lang['profile_api_heading'] = 'API Access / Key';
$lang['profile_api_desc'] = 'Your unique API key used for external API access. You can read more about what you can do with the API in the API documents in the help section.';
$lang['profile_api_access_level'] = 'Access Level';
$lang['profile_api_access_admin'] = 'Full';
$lang['profile_api_access_user'] = 'Read-Only';
$lang['profile_api_newkey'] = 'Generate New Key';
$lang['profile_api_noaccess'] = 'No API Access';

/* login.php */
$lang['login_heading'] = 'Log In';
$lang['login_username_label'] = 'Username';
$lang['login_password_label'] = 'Password';
$lang['login_remember_label'] = 'Keep me logged in';
$lang['login_button_label'] = 'Log In';
$lang['login_forgot_password'] = 'Forgot your password?';
$lang['login_about_heading'] = 'About Nagios Network Analyzer';
$lang['login_about_desc'] = 'Nagios Network Analyzer is an enterprise-class NetFlow monitoring solution that provides organizations with insight into traffic patterns and bandwidth usage before problems affect critical business processes. For more information on Nagios Network Analyzer, visit the';
$lang['login_about_desc_link'] = 'Nagios Network Analyzer product page';
$lang['login_learning_opportunities'] = 'Nagios Learning Opportunities';
$lang['login_learning_opportunities_conference'] = 'Want to learn about how other experts are utilizing Nagios? Do not miss your chance to attend the next <a href="http://go.nagios.com/nwcna">Nagios World Conference</a> held every year in St. Paul, Minnesota.';
$lang['login_learning_opportunities_training'] = 'Learn about Nagios <a href="http://www.nagios.com/services/training">training</a> and <a href="http://www.nagios.com/services/certification">certification</a> programs.';
$lang['login_contact_us'] = 'Contact Us';
$lang['login_contact_us_text'] = 'Have a question or technical problem? Contact us today';
$lang['login_contact_us_support'] = 'Support';
$lang['login_contact_us_support_forum'] = 'Online Support Forum';
$lang['login_contact_us_sales'] = 'Sales';
$lang['login_contact_us_web'] = 'Web';

/* Sources */

/* sources/create.php */
$lang['create_source_heading'] = 'Create Source';
$lang['create_source_subheading'] = 'When adding a new source, make sure you set up the source to send flow data to your NNA installation IP address at the port you specify below to receive data.';
$lang['create_source_info_heading'] = 'Source Information';
$lang['create_source_name'] = 'Source Name';
$lang['create_source_name_desc'] = '<strong>Must be unique.</strong> Name of the flow data collector. Used in back-end file system. Use a nice name that is easily associated with the flow data sending device.';
$lang['create_source_ip'] = 'Sender IP Address(es)';
$lang['create_source_ip_desc'] = '<strong>Optional</strong>. Use this to internally show what IP address(es) of switches, routers, or servers are sending to this source.';
$lang['create_source_port'] = 'Listening Port';
$lang['create_source_port_desc'] = '<strong>Must be unique.</strong> Port that the flow data is received on for this source. Multiple switches, routers, and servers can send to one port.';
$lang['create_source_submit_btn'] = 'Create Source';
$lang['create_source_breadcrumb'] = 'Create Source';
$lang['create_source_flow_type'] = 'Incoming Flow Type';
$lang['create_source_data_lifetime'] = 'Raw Data Lifetime';
$lang['create_source_data_lifetime_desc'] = 'The length of time you want <strong>granular flow data</strong> to be stored on your server, recommended 24hr period saves disk space.';
$lang['create_source_data_lifetime_popup_text'] = 'This value sets that length of time for granular data to be saved. This option was added to save disk space. In extreme conditions, sources can gather over 10GB of data in a day. This amount of data is so large that we compress and aggregate the data after the data lifetime to effectively keep the disk usage in check. The longer the data lifetime the longer you will have granular data but the more disk space you will use.';
$lang['create_source_data_lifetime_popup_title'] = 'What is Raw Data Lifetime?';
$lang['create_source_data_lifetime_popup'] = 'More info.';
$lang['create_source_flow_type_explanation'] = "Use NetFlow if you're using a device that supports NetFlow, jFlow, IPFIX, etc.";
$lang['sources_disable_abnormal'] = 'Disable abnormal behavior checks (removes from front page)';

/* sources/edit.php */
$lang['edit_source_heading'] = 'Edit Source';
$lang['edit_source_subheading'] = 'Edit the source ip address, port, and raw data lifetime. Your source will be restarted.';

/* sources/home.php */
$lang['sources_home_desc'] = 'Full list of all sources in your system. Only viewable sources are shown.';
$lang['sources_home_create_button'] = 'Create Source';
$lang['sources_home_th_status'] = 'Status';
$lang['sources_home_th_name'] = 'Source Name';
$lang['sources_home_th_30m_avg'] = 'Traffic last 30 minutes';
$lang['sources_home_th_disk'] = 'Disk Usage';
$lang['sources_home_th_lifetime'] = 'Data Lifetime';
$lang['sources_home_th_flow_type'] = 'Flow Type';
$lang['sources_home_error_loading'] = 'Error loading';
$lang['sources_home_search_no_results'] = 'No sources matching that name exist.';
$lang['sources_home_search_placeholder'] = 'Search by source name';
$lang['sources_home_none'] = 'No sources currently exist.';
$lang['sources_home_delete_question'] = 'Are you sure you want to delete the source';
$lang['sources_unpin'] = 'Unpin from Dashboard';
$lang['sources_pin'] = 'Pin to Dashboard';

/* sources/tabs.php */
$lang['tabs_source_default_view'] = 'Default (All Data)';
$lang['tabs_source_display_view'] = 'Display View';
$lang['tabs_summary'] = 'Summary';
$lang['tabs_reports'] = 'Reports';
$lang['tabs_queries'] = 'Queries';
$lang['tabs_percentile'] = 'Percentile Calculator';
$lang['tabs_views'] = 'Manage Views';
$lang['tabs_edit'] = 'Edit';
$lang['tabs_remove'] = 'Remove';
$lang['tabs_delete_modal_header'] = 'Are You Sure?';
$lang['tabs_delete_modal_text'] = 'Deleting this source will permanently remove <strong>all related data</strong>. This action can not be undone. Do you still want to delete this source?';
$lang['create_view_modal_header'] = 'Create View';
$lang['create_view_modal_text1'] = 'Views are used to specify specific data retention settings';
$lang['create_view_modal_text2'] = 'for a select ip or port for a different amount of time than the actual source.';
$lang['create_view_modal_explain'] = 'explain';
$lang['create_view_modal_popup_text'] = 'A view is like a filtered data collector. Say you want to keep data for your web server traffic. Create a view for port 80 and set the data lifetime to 30 days. This will retain data for port 80 for 30 days even if the data lifetime is set to 24 hours.';
$lang['create_view_modal_popup_title'] = 'What is a View?';
$lang['create_view_modal_source'] = 'Source';
$lang['create_view_modal_name'] = 'Name';
$lang['create_view_modal_limiter'] = 'Limiter';
$lang['create_view_modal_lifetime'] = 'Data Lifetime';
$lang['create_view_modal_limiter_popup'] = 'You can use things like ip x.x.x.x or port x or multiple using an and in-between. i.e. port 22 and port 80.';

/* sources/views.php */
$lang['view_source_header'] = 'View Management';
$lang['view_source_desc'] = 'Manage the views associated with this source. Views allow granular data storage of a certain combination of flow data.';
$lang['view_source_associate_button'] = 'Associate';
$lang['view_source_associate_sel_button'] = 'Associate Selected';
$lang['view_source_associated'] = 'Associated';
$lang['view_source_associated_popup'] = 'Views must be associated with a source to view or gather any data. These are not filters. Like sources, it requires time to gather data.';
$lang['view_source_unassociate_button'] = 'Remove Association';
$lang['view_source_unassociate_sel_button'] = 'Remove Association with Selected';
$lang['view_source_unassociated'] = 'Not Associated';
$lang['view_source_unassociated_popup'] = 'Views that are not associated with this source are not collecting data. You can add (associate) them to this source to start gathering data.';
$lang['view_source_no_assoc'] = 'There are no associated views.';
$lang['view_source_no_views'] = 'There are no views to associate.';
$lang['view_source_th_name'] = 'View Name';
$lang['view_source_th_lifetime'] = 'Data Lifetime';
$lang['view_source_th_actions'] = 'Actions';
$lang['view_source_delete_okay'] = 'Are you sure you want to delete this view?';
$lang['view_source_delete_perm1'] = 'This will permanently delete the view';
$lang['view_source_delete_perm2'] = 'It will be removed from the following sources if you delete it';

/* Generic */

/* generic/reports.php */
$lang['report'] = 'Report';
$lang['report_nodata'] = 'No Data.';
$lang['report_generic_pie_title'] = 'Pie Chart';
$lang['report_generic_custom'] = 'Custom Report';
$lang['report_generic_saved'] = 'Saved Report';
$lang['report_generic_piechart'] = 'For the pie charts to display you must enter a value less than 20.';
$lang['report_modal_name'] = 'Please enter a name for your report:';
$lang['report_modal_name_none'] = 'You must enter a name.';
$lang['report_modal_fill_out'] = 'Please fill out the whole form to save your custom report.';
$lang['report_delete_question'] = 'Are you sure you want to delete the report';
$lang['report_custom_desc1'] = 'Displaying top';
$lang['report_custom_desc2'] = 'from';
$lang['report_custom_desc3'] = 'grouping by';
$lang['report_custom_desc4'] = 'and ordering by';
$lang['report_custom_title'] = 'Custom Report';
$lang['report_no_records'] = 'There were no results in the time period specified.';
$lang['report_generic_run'] = 'Run Report';
$lang['report_error'] = 'Error!';
$lang['report_generic_modal_title'] = 'Update Custom Report';
$lang['report_generic_modal_desc'] = 'Update the custom report options and time range. You can not change the name here but you can under the reports tab. The report will be ran again upon update.';
$lang['report_generic_modal_name'] = 'Report Name';
$lang['report_generic_modal_top'] = 'Display top';
$lang['report_generic_modal_range'] = 'Time Range';
$lang['report_generic_modal_group'] = 'Group By';
$lang['report_generic_modal_order'] = 'Order By';

/* generic/queries.php */
$lang['query_generic_rm'] = 'Relational Mapping';
$lang['query_generic_save'] = 'Query saved successfully.';
$lang['query_generic_delete'] = 'Are you sure you want to delete';
$lang['query_generic_delete_end'] = 'This is a permanent action and can not be undone.';
$lang['query_generic_no_timerange'] = 'You must enter a time range.';
$lang['query_generic_no_ag'] = 'You must enter at least one field to be aggregated by.';
$lang['query_generic_default_name'] = 'Custom Query';
$lang['query_generic_loaded'] = 'Loaded Query';
$lang['query_generic_ag'] = 'Aggregate By';
$lang['query_generic_ag_desc'] = 'Aggregate the query by these fields. Fields you can use are srcip, srcport, dstip, dstport.';
$lang['query_generic_tf'] = 'Time Frame';
$lang['query_generic_run'] = 'Run Query';
$lang['query_generic_error'] = 'Error!';
$lang['query_generic_page_first'] = 'First';
$lang['query_generic_page_last'] = 'Last';
$lang['query_generic_load_title'] = 'Load a Query';
$lang['query_generic_load_desc'] = 'Load a query from the selected queries below.';
$lang['query_generic_load_name'] = 'Name';
$lang['query_generic_load_desc_input'] = 'Description';
$lang['query_generic_load_button'] = 'Load Query';
$lang['query_generic_save_title'] = 'Save Query';
$lang['query_generic_save_desc'] = 'Save your query for later use on this source or other sources and source groups.';
$lang['query_generic_save_button'] = 'Save Query';

/* generic/summary.php */
$lang['summary_graph_using'] = 'Graph using';
$lang['summary_graph_log'] = 'Logarithmic';
$lang['summary_graph_linear'] = 'Linear';
$lang['summary_graph_timeframe'] = 'View bandwidth graph and top talkers for the';
$lang['summary_talkers_title'] = 'Top 5 Talkers';
$lang['summary_bytes'] = 'Bytes';
$lang['summary_talkers1'] = 'Destination IP';
$lang['summary_talkers1_alt'] = 'Destination Hostname';
$lang['summary_talkers2'] = 'Source IP';
$lang['summary_talkers2_alt'] = 'Source Hostname';
$lang['summary_talkers3'] = 'Dest. Port';
$lang['summary_talkers4'] = 'Src. Port';

/* Alerting */

/* alerting/tabs.php */
$lang['alert_tab_desc'] = 'Here you can create and manage your alerts that will integrate with your Nagios deployment(s).';
$lang['alert_tab_checks'] = 'Checks';
$lang['alert_tab_nagios'] = 'Nagios Setup';
$lang['alert_tab_snmp'] = 'SNMP Receivers';
$lang['alert_tab_commands'] = 'Commands';

/* alerting/snmp.php */
$lang['alert_snmp_none'] = 'No receivers created.';
$lang['alert_snmp_delete_success'] = 'Successfully deleted SNMP receiver.';
$lang['alert_snmp_saved_success'] = 'Successfully saved SNMP receiver.';
$lang['alert_snmp_new_button'] = 'New SNMP Receiver';
$lang['alert_snmp_th_name'] = 'Name';
$lang['alert_snmp_th_ip'] = 'IP Address';
$lang['alert_snmp_th_version'] = 'Version';
$lang['alert_snmp_th_actions'] = 'Actions';
$lang['alert_snmp_step1_title'] = 'Enter Information';
$lang['alert_snmp_step1_desc'] = 'Enter information about the device that will receive SNMP traps.';
$lang['alert_snmp_step1_name'] = 'Name';
$lang['alert_snmp_step1_ip'] = 'IP Address';
$lang['alert_snmp_step1_port'] = 'Port';
$lang['alert_snmp_step1_version'] = 'SNMP Version';
$lang['alert_snmp_step1_cstring'] = 'Community String';
$lang['alert_snmp_step1_username'] = 'Username';
$lang['alert_snmp_step1_auth_lvl'] = 'Authorization Level';
$lang['alert_snmp_step1_auth_pro'] = 'Authorization Protocol';
$lang['alert_snmp_step1_auth_pass'] = 'Authorization Password';
$lang['alert_snmp_step1_priv_pro'] = 'Privacy Protocol';
$lang['alert_snmp_step1_priv_pass'] = 'Privacy Password';
$lang['alert_snmp_step1_button'] = 'Finish &amp; Save';
$lang['alert_snmp_modal_title'] = 'Delete SNMP Receiver';
$lang['alert_snmp_modal_desc'] = 'Are you sure you want to delete this SNMP receiver?';

/* alerting/servers.php */
$lang['alert_service_new'] = 'New Service/Hostname';
$lang['alert_service_th_name'] = 'Servicename';
$lang['alert_service_th_hostname'] = 'Hostname';
$lang['alert_service_th_server'] = 'Associated Server';
$lang['alert_service_th_actions'] = 'Actions';
$lang['alert_server_new'] = 'New Nagios Server';
$lang['alert_server_th_name'] = 'Name';
$lang['alert_server_th_address'] = 'NRDP Address';
$lang['alert_server_th_token'] = 'NRDP Token';
$lang['alert_server_th_actions'] = 'Actions';
$lang['alert_modal_title'] = 'Enter Information';
$lang['alert_modal_service_desc'] = 'Enter information about the Servicename/Hostname.';
$lang['alert_modal_server_desc'] = 'Enter information about the Nagios Server.';
$lang['alert_service_delete_title'] = 'Delete Hostname Servicename Association';
$lang['alert_service_delete_desc'] = 'Are you sure you want to delete this Hostname Servicename association?';
$lang['alert_server_delete_title'] = 'Delete Nagios Server';
$lang['alert_server_delete_desc'] = 'Are you sure you want to delete this Nagios Server?';
$lang['alert_error_server_delete'] = 'Could not delete server. Make sure there are no checks or hostname/servicename associations.';
$lang['alert_error_noserver'] = 'You must create a server before creating a servicename/hostname.';
$lang['alert_success_server_delete'] = 'Successfully deleted Nagios Server.';
$lang['alert_success_service_delete'] = 'Successfully deleted Hostname/Servicename.';
$lang['alert_success_server_create'] = 'Successfully created Nagios server.';
$lang['alert_success_service_create'] = 'Successfully created Hostname/Servicename. If you are using Nagios XI, log into Nagios XI and apply the new config.';
$lang['alert_noservers'] = 'No servers created.';
$lang['alert_noservices'] = 'No associations created.';
$lang['alert_server_save_host'] = 'Host was successfully saved, however.';
$lang['alert_server_label_delete_assoc'] = 'Delete Hostname Service Association';
$lang['alert_server_label_delete'] = 'Delete Nagios Server';

/* alerting/checks.php */
$lang['alert_check_new_button'] = 'New Check';
$lang['alert_check_th_name'] = 'Name';
$lang['alert_check_th_assoc'] = 'Associated With';
$lang['alert_check_th_last'] = 'Last Date Ran';
$lang['alert_check_th_status'] = 'Last Status';
$lang['alert_check_th_stdout'] = 'Last Stdout';
$lang['alert_check_th_actions'] = 'Actions';
$lang['alert_check_validation_error'] = 'Validation Error';
$lang['alert_check_step1_title'] = 'Step 1 - Select Source';
$lang['alert_check_step1_name'] = 'Please name the check for management: (Required)';
$lang['alert_check_step1_sg'] = 'Sourcegroup';
$lang['alert_check_step1_source'] = 'Source';
$lang['alert_check_step1_view'] = 'View';
$lang['alert_check_step1_continue'] = 'Step Two';
$lang['alert_check_step2_title'] = 'Step 2 - Select Criteria';
$lang['alert_check_step2_analyze'] = 'Analyze traffic for';
$lang['alert_check_step2_warning'] = 'Warning threshold is';
$lang['alert_check_step2_critical'] = 'Critical threshold is';
$lang['alert_check_step2_forward'] = 'Step Three';
$lang['alert_check_step2_backward'] = 'Step One';
$lang['alert_check_step3_title'] = 'Step 3 - Select Alerting Methods';
$lang['alert_check_step3_desc'] = 'Select how you would like to be notified of these checks. Select any of the items in the lists under the tabs, and all the selected elements will be notified.';
$lang['alert_check_step3_tab_email'] = 'Email Users';
$lang['alert_check_step3_tab_nagios'] = 'Nagios';
$lang['alert_check_step3_tab_trap'] = 'SNMP Traps';
$lang['alert_check_step3_tab_cmd'] = 'Commands';
$lang['alert_check_step3_tab_email_desc'] = 'Select the users to be email with check results. Hold ctrl and click to un-select users.';
$lang['alert_check_step3_tab_nagios_desc'] = 'Select the Host/Service associations you would like to send the check results as. Removing: Hold ctrl and click to un-select Host/Services.';
$lang['alert_check_step3_tab_trap_desc'] = 'Select the SNMP trap receivers to send traps to regarding this check. Removing: Hold ctrl and click to un-select SNMP trap receivers.';
$lang['alert_check_step3_tab_cmd_desc'] = 'Select local scripts or commands to be run when the check happens. Hold ctrl and click to un-select commands.';
$lang['alert_check_step3_backward'] = 'Step Two';
$lang['alert_check_step3_finish'] = 'Finish &amp; Save';
$lang['alert_check_valid_warning'] = 'Warning threshold not a valid Nagios threshold.';
$lang['alert_check_valid_critical'] = 'Critical threshold not a valid Nagios threshold.';
$lang['alert_check_req_fields'] =  'Required fields were not filled out.';
$lang['alert_check_deleted'] = 'Successfully deleted check.';
$lang['alert_check_not_created'] = 'No checks created.';
$lang['alert_check_abnormal_behavior'] = "Abnormal behavior checks can only be run on sources, not views or sourcegroups";

$lang['alert_command_new_button'] = 'New Command';
$lang['alert_command_th_name'] = 'Name';
$lang['alert_command_th_location'] = 'Script Location';
$lang['alert_command_th_script'] = 'Script Name';
$lang['alert_command_th_args'] = 'Passed Arguments';
$lang['alert_command_create_btn'] = 'Create';
$lang['alert_command_save_btn'] = 'Save';
$lang['alert_command_create_title'] = 'New Command';
$lang['alert_command_edit_title'] = 'Edit Command';
$lang['alert_command_create_desc'] = 'Specify a script to run when an alert happens.';
$lang['alert_command_create_desc2'] = 'You can pass some basic macros to the script via arguments that will be auto-populated when the script is executed.';
$lang['alert_command_create_macro1'] = 'the name of the source that is being alerted on';
$lang['alert_command_create_macro2'] = 'the port the source is listening on';
$lang['alert_command_create_macro3'] = 'the alert state (ok, warning, critical, unknown)';
$lang['alert_command_create_macro4'] = 'the return code of the check (0 to 3)';
$lang['alert_command_create_macro5'] = 'the full output of the check';

/* Setup */

/* setup/enterkey.php */
$lang['setup_enterkey_trial_expired'] = 'Trial License Expired!';
$lang['setup_enterkey_trial_expired_desc'] = 'Thank you for trying Nagios Network Analyzer. Sadly, your free trial license has expired.';
$lang['setup_enterkey_setkey'] = 'Set Key';
$lang['setup_enterkey_text'] = 'If you do not have a license key yet, you can purchase one <a href="http://www.nagios.com/products/nagios-network-analyzer" target="_blank">from the nagios website</a>.';

/* setup/install.php */
$lang['setup_install_header'] = 'Final Installation Steps';
$lang['setup_install_desc'] = 'Almost done! Update the license and configure the admin account.';
$lang['setup_install_license_header'] = 'License Setup';
$lang['setup_install_license_desc'] = 'Choose a trial license, enter your key, or <a href="http://www.nagios.com/products/nagios-network-analyzer" target="_blank">get a license now</a>.';
$lang['setup_install_trial'] = 'Free 60 Day Trial';
$lang['setup_install_have_key'] = 'I already have a key';
$lang['setup_install_license_key'] = 'License Key';
$lang['setup_install_account_header'] = 'Admin Account Setup';
$lang['setup_install_account_desc'] = 'Choose or enter your admin profile and account settings. The default username is nagiosadmin, which you can change.';
$lang['setup_install_account_username'] = 'Username';
$lang['setup_install_account_password'] = 'Password';
$lang['setup_install_account_conf_password'] = 'Confirm Password';
$lang['setup_install_account_email'] = 'Email Address';
$lang['setup_install_language'] = 'Language';
$lang['setup_install_timezone'] = 'System Timezone';
$lang['setup_install_finish_button'] = 'Finish Installation';

/* Views, Queries, Reports Tabs */

/* views/home.php */
$lang['view_home_desc'] = 'A list of all your saved views. You can edit, delete, or run them on a selected source.';
$lang['view_home_delete_all_warning'] = 'Are you sure you want to permanently delete all the selected views and their data? This action can not be undone!';
$lang['view_home_create'] = 'Create View';
$lang['view_home_search_placeholder'] = 'Search by view name';
$lang['view_home_th_name'] = 'View Name';
$lang['view_home_th_assoc'] = 'Source Associations';
$lang['view_home_th_lifetime'] = 'Data Lifetime';
$lang['view_home_th_actions'] = 'Actions';
$lang['view_home_modal_assoc_title'] = 'View Associations';
$lang['view_home_modal_assoc_desc'] = 'Make changes to the associations for this view.';
$lang['view_home_modal_view'] = 'View';
$lang['view_home_modal_unassoc'] = 'Sources not Associated';
$lang['view_home_modal_assoc'] = 'Associated Sources';
$lang['view_home_modal_assoc_btn_title'] = 'Associate with source';
$lang['view_home_modal_unassoc_btn_title'] = 'Unassociate from source';
$lang['view_update_title'] = 'Update View';
$lang['view_update_desc'] = 'Edit the view selected and save.';

/* queries/home.php */
$lang['query_home_desc'] = 'A list of all your saved queries. You can edit, delete, or run them on a selected source.';
$lang['query_home_modal_create'] = 'Create Query';
$lang['query_home_modal_update'] = 'Update Query';
$lang['query_home_delete'] = 'Are you sure you want to delete the query';
$lang['query_home_none'] = 'No saved queries currently exist.';
$lang['query_home_create'] = 'Create Query';
$lang['query_name_search'] = 'Search by query name';
$lang['query_home_th_name'] = 'Query Name';
$lang['query_home_th_desc'] = 'Description';
$lang['query_home_th_actions'] = 'Actions';
$lang['query_home_modal_desc'] = 'Queries can be loaded and ran on any source, sourcegroup, or view.';
$lang['query_home_modal_name'] = 'Name';
$lang['query_home_modal_desc_input'] = 'Description';
$lang['query_home_modal_ag'] = 'Aggregate By';
$lang['query_home_modal_ag_desc'] = 'Aggregate the query by these fields. Fields you can use are srcip, srcport, dstip, dstport.';
$lang['query_home_modal_tf'] = 'Time Frame';
$lang['query_home_modal_raw'] = 'Raw Query';
$lang['query_home_run_title'] = 'Run a Query';
$lang['query_home_run_desc'] = 'Select the source or sourcegroup to run the query on.';
$lang['query_home_run_button'] = 'Run Query';
$lang['query_home_run_on'] = 'Run On';
$lang['query_home_are_you_sure'] = 'Are you sure you want to permanently delete all the selected queries? This action can not be undone!';

/* reports/home.php */
$lang['report_home_delete_multi'] = 'Are you sure you want to permanently delete all the selected reports? This action can not be undone!';
$lang['report_home_delete'] = 'Are you sure you want to delete';
$lang['report_home_none'] = 'No reports currently exist.';
$lang['report_home_desc'] = 'A list of all saved reports you can run. These reports can be run on any source, sourcegroup, or view.';
$lang['report_home_create'] = 'Create Report';
$lang['report_home_search'] = 'Search by report name';
$lang['report_home_static'] = 'Static';
$lang['report_home_th_name'] = 'Report Name';
$lang['report_home_th_actions'] = 'Actions';
$lang['report_home_modal_title'] = 'Custom Report';
$lang['report_home_modal_desc'] = 'A custom report can be run on any source and is not linked to sources specifically. Use a limiter query to get data for specific ports or ips.';
$lang['report_home_modal_name'] = 'Report Name';
$lang['report_home_modal_top'] = 'Display top';
$lang['report_home_modal_range'] = 'Time Range';
$lang['report_home_modal_group'] = 'Group By';
$lang['report_home_modal_order'] = 'Order By';
$lang['report_home_modal_limiter'] = 'Limiter (Optional)';
$lang['report_home_modal_limiter_desc'] = 'Not Required! You can use things like ip x.x.x.x or port x or multiple using an and in-between. i.e. port 22 and port 80.';
$lang['report_home_run_title'] = 'Run a Report';
$lang['report_home_run_desc'] = 'Select the source or sourcegroup to run the report on.';
$lang['report_home_run_on'] = 'Run On';
$lang['report_home_run_button'] = 'Run Report';
$lang['report_home_tooltip'] = 'For the pie charts to display you must enter a value less than 20.';

/* Source groups */

/* sourcegroups/create.php */
$lang['create_sourcegroup_heading'] = 'Create Source Group';
$lang['create_sourcegroup_subheading'] = 'You will need to add one or more source(s) to a sourcegroup. Fill out all information below.';
$lang['create_sourcegroup_submit_btn'] = 'Create Source Group';
$lang['create_sourcegroup_no_name'] = 'You must enter a group name.';
$lang['create_sourcegroup_no_sources'] = 'You must select at least one source.';
$lang['create_sourcegroup_name'] = 'Source Group Name';
$lang['create_sourcegroup_sources'] = 'Sources in Group';
$lang['create_sourcegroup_add'] = 'Add to sourcegroup';
$lang['create_sourcegroup_remove'] = 'Remove from sourcegroup';
$lang['create_sourcegroup_lifetime'] = 'Raw Data Lifetime';
$lang['create_sourcegroup_lifetime_text'] = 'Same lifetime as the source with the shortest raw data lifetime.';
$lang['create_sourcegroup_all_sources'] = 'Available Sources';

/* sourcegroups/edit.php */
$lang['edit_sourcegroup_edit'] = 'Edit';
$lang['edit_sourcegroup_heading'] = 'Edit Source Group';
$lang['edit_sourcegroup_save'] = 'Source Group saved successfully.';

/* sourcegroups/home.php */
$lang['home_sourcegroup_none_exist'] = 'No source groups currently exist.';
$lang['home_sourcegroup_are_you_sure'] = 'Are you sure you want to delete the group:';
$lang['home_sourcegroup_title'] = 'Source Groups';
$lang['home_sourcegroup_desc'] = 'Full list of source groups in your system. Source groups can consist of multiple sources and act like a single source for data accounting purposes and one source can be in multiple source groups.';

/* sourcegroups/tabs.php */
$lang['tab_sourcegroup_sources'] = 'Sources';
$lang['tab_sourcegroup_sources_seeall'] = 'See All';
$lang['tabs_sourcegroup_delete_modal_text'] = 'Deleting this source group will permanently remove this group. Are you sure you want to delete this source group?';
$lang['home_sourcegroup_create'] = 'Create Source Group';
$lang['home_sourcegroup_search_placeholder'] = 'Search by source group name';
$lang['home_sourcegroup_th_name'] = 'Source Group Name';
$lang['home_sourcegroup_th_sources'] = 'Sources in Group';
$lang['home_sourcegroup_assoc_header'] = 'Sources in Source Group';
$lang['home_sourcegroup_showall'] = 'Show all sources';

/* Admin Area */

/* admin/create_user.php */
$lang['create_user_heading'] = 'Create User';
$lang['create_user_subheading'] = 'Please enter all fields of the new users information below. Starred fields are required.';
$lang['create_user_details_heading'] = 'User Details';
$lang['create_user_name'] = 'First &amp; Last Name';
$lang['create_user_company'] = 'Company Name';
$lang['create_user_contact_heading'] = 'Contact Information';
$lang['create_user_email'] = 'Email';
$lang['create_user_phone'] = 'Phone';
$lang['create_user_account_heading'] = 'Account Information';
$lang['create_user_username'] = 'Username';
$lang['create_user_password'] = 'Password';
$lang['create_user_conf_password'] = 'Confirm Password';
$lang['create_user_submit_btn'] = 'Create User';
$lang['user_management_heading'] = 'User Management';
$lang['group_management_heading'] = 'Group Management';
$lang['create_user_al_title'] = 'User Access Level';
$lang['create_user_al_desc'] = 'Set the user level of access inside the UI.';
$lang['create_user_al_admin'] = 'Admin';
$lang['create_user_al_admin_desc'] = 'Full Access. Admins can change/delete all components including sources, sourcegroups, views, reports, queries, and checks. They can also update the NNA configuration and manage users.';
$lang['create_user_al_user'] = 'User';
$lang['create_user_al_user_desc'] = 'Limited Full Access. Users can see everything except the configuration options. However, they can not edit anything except their own profile\'s password, contact info, and api key.';
$lang['create_user_api_title'] = 'API Access';
$lang['create_user_api_desc'] = 'If you want to allow this user to use the external API via an access key.';
$lang['create_user_account_auth'] = 'Authentication Settings';
$lang['create_user_account_auth_desc'] = 'User accounts can be authenticated in many different ways either from your local database or external programs such as Active Directory or LDAP. You can set up external authentication servers in the LDAP/AD Integration settings.';

/* admin/edit_user.php */
$lang['edit_user_heading'] = 'Edit User';
$lang['edit_user_subheading'] = 'Please enter the users information below.';
$lang['edit_user_submit_btn'] = 'Save User';
$lang['edit_user_validation_fname_label'] = 'First Name';
$lang['edit_user_validation_lname_label'] = 'Last Name';
$lang['edit_user_validation_email_label'] = 'Email Address';
$lang['edit_user_validation_phone1_label'] = 'First Part of Phone';
$lang['edit_user_validation_phone2_label'] = 'Second Part of Phone';
$lang['edit_user_validation_phone3_label'] = 'Third Part of Phone';
$lang['edit_user_validation_company_label'] = 'Company Name';
$lang['edit_user_validation_groups_label'] = 'Groups';
$lang['edit_user_validation_password_label'] = 'Password';
$lang['edit_user_validation_password_confirm_label'] = 'Password Confirmation';
$lang['create_edit_user_fname_val'] = 'First Name';
$lang['create_edit_user_lname_val'] = 'Last Name';
$lang['create_edit_user_email_val'] = 'Email Address';
$lang['create_edit_user_company_val'] = 'Company Name';
$lang['create_edit_user_password_val'] = 'Password';
$lang['create_edit_user_password_confirm_val'] = 'Password Confirmation';

/* admin/home.php */
$lang['config_home_title'] = 'Configure Network Analyzer';
$lang['config_home_desc'] = 'Set the global retention settings, manage users, and update the general front-end settings for your Network Analyzer install. You can also update your license and check the license information.';

/* admin/leftbar.php */
$lang['leftbar_general'] = 'General';
$lang['leftbar_users_link'] = 'User Management';
$lang['leftbar_license'] = 'Licensing';
$lang['leftbar_license_link'] = 'Update License';
$lang['leftbar_dashboards'] = 'Dashboards';
$lang['leftbar_auth'] = 'Authentication';
$lang['leftbar_system_dashboard_link'] = 'System Dashboard';
$lang['leftbar_global_defaults_link'] = 'Global Settings';
$lang['leftbar_ldap_ad_servers'] = 'LDAP/AD Integration';
$lang['leftbar_updates'] = 'Check for Updates';
$lang['leftbar_backup_link'] = 'System Backup';
$lang['leftbar_backup'] = 'Backup';

/* admin/users.php */
$lang['users_delete'] = 'This action will permanently delete the user.';
$lang['index_name_th'] = 'Username';
$lang['index_email_th'] = 'Email';
$lang['index_status_th'] = 'Status';
$lang['index_action_th'] = 'Action';
$lang['index_create_user'] = 'Create User';
$lang['index_import_users'] = 'Add Users from LDAP/AD';
$lang['index_access_level_th'] = 'Access Level';
$lang['index_type_th'] = 'Account Type';
$lang['index_api_th'] = 'API Access';
$lang['index_create_backup'] = 'Create Backup';
$lang['index_backup_running'] = 'Backup in progress...';

/* admin/license.php */
$lang['license_heading'] = 'Update License';
$lang['license_desc'] = 'Update your Nagios Network Analyzer license code. If you do not have one, you can <a href="http://www.nagios.com/products/nagios-network-analyzer/pricing/buy" target="_new">purchase one</a>.';
$lang['license_trial_end'] = 'Update your license key. Your trial will end in';
$lang['license_trial_end_days'] = 'days';
$lang['license_valid'] = 'Your license key is valid and up to date!';
$lang['license_key'] = 'License Key';
$lang['license_set_key'] = 'Set Key';

/* admin/globals.php */
$lang['globals_desc'] = 'Edit default global settings for your Nagios Network Analyzer install.';
$lang['globals_default_language'] = 'Default Language';
$lang['globals_default_language_desc'] = 'The default language all users will see until they set their own.';
$lang['global_resolve_host'] = 'Resolve Hostnames in';
$lang['global_resolve_host_desc'] = 'This will automatically try to resolve the Hostname based on IP addresses (via DNS) throughout Network Analyzer using PHP\'s internal functions. Can be done on everything or just reports/queries or graphs.';
$lang['global_resolve_host_rq'] = 'Reports and Queries';
$lang['global_resolve_host_g'] = 'Graphs';
$lang['global_save_button'] = 'Save Settings';
$lang['global_saved_success'] = 'Successfully saved global settings.';
$lang['global_rel_mapping'] = 'Max Mapped Relations';
$lang['global_rel_mapping_desc'] = 'The max amount of relations you would like to see on the chord diagram relational maps.';
$lang['global_timezone'] = 'Change Timezone';
$lang['global_timezone_desc'] = 'Set the timezone on this server.';
$lang['global_cache_time'] = 'Hostname Cache Time';
$lang['global_cache_time_desc'] = 'Set the amount of time in seconds to refresh cached host data. Default is 7 days. Settings less than 1 hour (3600) will refresh every hour. Refreshing cached hostnames will happen in the back-end.';

/* admin/backup.php */
$lang['backup_heading'] = "System Backups";
$lang['backup_desc'] = 'Manage your Nagios Network Analyzer backups. Here you can create, download and delete a backup. Backups are stored in <b>/store/backups/nagiosna</b> by default.';
$lang['backup_name_th'] = 'Filename';
$lang['backup_size_th'] = 'Size';
$lang['backup_date_th'] = 'Date';
$lang['backup_action_th'] = 'Actions';
$lang['backup_success'] = 'Successfully sent a request to create a backup file. This may take a while..';
$lang['backup_failed'] = 'Creating backup file failed.  Please check file permission on /store/backup/nagiosna and verify the backup_na script exists.';

/* Auth */

/* auth/forgot_password.php */
$lang['forgot_password_heading'] = 'Forgot Password';
$lang['forgot_password_subheading'] = 'Please enter your account username to send a password reset request to.';
$lang['forgot_password_username_label'] = 'Username';
$lang['forgot_password_submit_btn'] = 'Send Email';

/* auth/reset_password.php */
$lang['reset_password_heading'] = 'Reset Password';
$lang['reset_password_subheading'] = 'Please enter a new password for your account.';
$lang['reset_password_new_password_label'] = 'New Password';
$lang['reset_password_new_password_confirm_label'] = 'Confirm New Password';
$lang['reset_password_submit_btn'] = 'Reset';

/* Email */

/* auth/email/forgot_password.php */
$lang['email_forgot_password_heading'] = 'Forgot Your Password';
$lang['email_forgot_password_desc'] = 'There has been a request to change your password for Nagios Network Analyzer. Please either click the link below or disregard the message.';

// Change password
$lang['change_password_msg_success'] = 'Your password was successfully changed.';
$lang['change_password_fail_auth'] = 'The old password you entered is not correct, please try again.';
$lang['change_password_fail_conf'] = 'Your new password does not match.';
$lang['update_profile_msg_success'] = 'Your profile information has been updated.';
$lang['update_profile_name_empty'] = 'You must enter a first and last name.';
$lang['update_profile_email_invalid'] = 'Please enter a valid email address.';

/* Help Section */

$lang['help_sidebar_resources'] = 'Help Resources';
$lang['help_sidebar_guides'] = 'Documentation Guides';
$lang['help_sidebar_admin_guide'] = 'Administrator Guide';
$lang['help_sidebar_support_kb'] = 'Support Knowledgebase';
$lang['help_sidebar_support_forum'] = 'Support Forum';
$lang['help_sidebar_library'] = 'Nagios Library';
$lang['help_title'] = 'Getting Started With Nagios Network Analyzer';
$lang['help_title_desc'] = 'The purpose of this help section is to get you started using Nagios Network Analyzer (NNA) and to direct you to documents, forums, and customer support if further help is needed. We have provided links to some of those areas along the left side.';
$lang['help_title_desc2'] = 'To get started using NNA we have a quick 2 step setup process to start collecting flow data.';
$lang['help_step1_title'] = 'Step 1: Create a Flow Data Sender';
$lang['help_step1_desc'] = 'To start using NNA you will need to have a flow data sender. A sender can be anything that will send flow data to an IP/Port using one of the flow types supported by NNA such as NetFlow or sFlow. If you do not already have senders set up, take a look at the help document(s) for the support netflow senders and how to set them up on switches, routers, windows, linux, vmware, and more.';
$lang['help_step1_desc2'] = 'Document on understanding flow data:';
$lang['help_step1_link'] = 'Understanding Network Flows';
$lang['help_flows_title'] = 'How to set up flow data senders:';
$lang['help_flows_routers'] = 'Routers/Switches';
$lang['help_flows_linux'] = 'Linux';
$lang['help_flows_windows'] = 'Windows';
$lang['help_flows_vmware'] = 'VMWare';
$lang['help_step1_desc3'] = 'Once you have flow data being generated and sent to the NNA IP address, we can create sources to capture that data and store it.';
$lang['help_step2_title'] = 'Step 2: Create a Source';
$lang['help_step2_desc'] = 'Creating a source in NNA is pretty self explanatory but we will go over it quickly because there are a few parts that need to be pointed out since they may not be familiar with you. Start off by heading over to the sources tab. Click on the create source button above the table. Note that only admins can create or edit sources. Some of the noticeable points on this page are shown below.';
$lang['help_step2_name'] = '<strong>Source Name:</strong> Source names must be unique, and may not be changed once set.';
$lang['help_step2_ip'] = '<strong>Sender IP Address(es):</strong> Use this to internally show what IP address(es) of switches, routers, or servers are sending to this source.';
$lang['help_step2_port'] = '<strong>Listening Port:</strong> Ports must be unique, and must be a port over 1024. Each sender will need to be configured to send to a separate port.';
$lang['help_step2_type'] = '<strong>Incoming Flow Type:</strong> The type of flow data being received.';
$lang['help_step2_lifetime'] = '<strong>Raw Data Lifetime:</strong> This value sets that length of time for granular data to be saved. This option was added to save disk space. In extreme conditions, sources can gather over 10GB of data in a day. This amount of data is so large that we compress and aggregate the data after the data lifetime to effectively keep the disk usage in check. The longer the data lifetime the longer you will have granular data but the more disk space you will use.';
$lang['help_step2_final'] = 'Done! Once created you can stop/start the source at any time to stop or start the collection of data.';

/* Internal Controllers */
$lang['title_admin'] = 'Administration';
$lang['title_license'] = 'License Information';
$lang['title_global_settings'] = 'Global Default Settings';
$lang['title_login'] = 'Login';
$lang['title_forgot_pw'] = 'Forgot Password';
$lang['title_dashboard'] = 'Dashboard';
$lang['title_my_profile'] = 'My Profile';
$lang['title_create_sg'] = 'Create Source Group';
$lang['title_edit_sg'] = 'Edit Source Group';
$lang['title_sg_summary'] = 'Source Group - Summary';
$lang['title_reports'] = 'Reports';
$lang['title_queries'] = 'Queries';
$lang['title_help'] = 'Help';
$lang['title_install'] = 'Install';
$lang['title_create_source'] = 'Create Source';
$lang['title_edit_source'] = 'Edit Source';
$lang['title_source_summary'] = 'Source - Summary';
$lang['title_views'] = 'Views';
$lang['title_percentile'] = 'Percentile Calculator';
$lang['title_backup'] = 'Backup';
$lang['license_error'] = 'The license key entered was not valid.';
$lang['edit_user_success'] = 'Your changes to the user have been saved.';
$lang['edit_user_access_level_msg'] = 'You must select a user access level.';
$lang['delete_superadmin'] = 'You can not delete the superadmin.';
$lang['could_not_delete_user'] = 'Could not delete that user.';
$lang['save_source_config'] = 'Source configuration has been saved!';

/* Install */
$lang['install_error_pw'] = 'You must enter a password.';
$lang['install_error_pw_match'] = 'Your passwords do not match. Please try again.';
$lang['install_error_form'] = 'Please fill out the entire form.';
$lang['install_error_email'] = 'Please enter a valid email address.';
$lang['install_complete'] = 'Installation Complete!';
$lang['license_key_updated'] = 'License Key Updated!';
$lang['license_key_invalid'] = 'The license key provided was invalid.';

/* Exceptions */
$lang['exception_qviz_sortby'] = 'sortby must be either flows, bytes, or packets';
$lang['exception_no_source'] = 'No source was specified.';
$lang['exception_no_report'] = 'No report specified.';

/* LDAP / AD Integration */
$lang['ldap_ad_header'] = 'LDAP / Active Directory Integration';
$lang['ldap_ad_desc'] = 'Manage authentication servers can be used to authenticate users against during login. Once a server has been added you can';
$lang['ldap_ad_import'] = 'import users';
$lang['ldap_ad_no_servers'] = 'No authentication servers have been added.';
$lang['ldap_ad_add_server'] = 'Add Server';
$lang['ldap_ad_add_server_title'] = 'Add LDAP / Active Directory Server';
$lang['ldap_ad_edit_server_title'] = 'Edit LDAP / Active Directory Server';
$lang['ldap_ad_add_server_desc'] = 'You must make sure that you can access the LDAP / Active Directory server from your Network Analyzer box. You should also verify that the correct encryption methods are available. If you\'re planning on using SSL or TLS with self-signed certificates you need to make sure the proper certificates are installed on the Network Analyzer server or you will not be able to connect to your LDAP / Active Directory server.';
$lang['ldap_ad_create_server'] = 'Create Server';
$lang['ldap_ad_server_type'] = 'Server Type';
$lang['ldap_ad_enabled_desc'] = 'Enabled servers can be used to authenticate against. Disabling a server means the users will still exist but they won\'t be able to log into Network Analyzer.';
$lang['ldap_ad_account_suffix'] = 'Account Suffix';
$lang['ldap_ad_account_suffix_desc'] = 'The part of the full user identification after the username, such as <strong>@nagios.com</strong>.';
$lang['ldap_ad_basedn'] = 'Base DN';
$lang['ldap_ad_basedn_desc'] = 'The LDAP-format starting object (distinguished name) that your users are defined below, such as <strong>DC=nagios,DC=com</strong>.';
$lang['ldap_ad_controllers'] = 'Domain Controllers';
$lang['ldap_ad_controllers_desc'] = 'A <strong>comma-separated</strong> list of domain controllers.';
$lang['ldap_ad_ldap_host'] = 'LDAP Host';
$lang['ldap_ad_ldap_host_desc'] = 'The IP address or hostname of your LDAP server.';
$lang['ldap_ad_ldap_port'] = 'LDAP Port';
$lang['ldap_ad_ldap_port_desc'] = 'The port your LDAP server is running on. (Default is 389)';
$lang['ldap_ad_encryption'] = 'Encryption Method';
$lang['ldap_ad_encryption_desc'] = 'Used when trying to connect to a server via <strong>SSL</strong> or <strong>TLS</strong> encryptions.';
$lang['ldap_ad_no_servers_select'] = 'No authentication servers available';
$lang['ldap_ad_auth_type'] = 'Auth Type';
$lang['ldap_ad_local'] = 'Local (Default)';
$lang['ldap_ad_server_name'] = 'Server Name';
$lang['ldap_ad_server_name_desc'] = 'The name of the server for internal purposes only. This will not affect the connection.';
$lang['ldap_ad_manage_servers_link'] = 'Manage Authentication Servers';
$lang['superuser_auth_warning'] = '<strong>Superuser Auth Settings</strong> You can not turn off local authentication for the nagiosadmin user. Even if you select a separate authentication method you will still be able to log in with the local password for this user.';
$lang['ldap_ad_save_server'] = 'Save Server';
$lang['ldap_ad_auth_identifier'] = 'Auth Identifier';

$lang['ldap_ad_import_title'] = 'LDAP / Active Directory Import Users';
$lang['ldap_ad_import_desc_step1'] = 'Log into your LDAP / Active Directory <strong>administrator</strong> or <strong>privileged account</strong> to be able to import users directly into Network Analyzer.';
$lang['ldap_ad_import_desc_step2'] = 'Select the users you would like to give access to Network Analyzer via LDAP / Active Directory authentication. You will be able to set user-specific permissions on the next page.';
$lang['ldap_ad_import_desc_step3'] = 'Set up the new users. Add missing information and update the account.';
$lang['ldap_ad_import_step2_subtitle'] = 'Select Users to Import';
$lang['ldap_ad_import_step3_subtitle'] = 'Fill Out New User Information';
$lang['ldap_ad_users_selected'] = 'users selected for import';
$lang['ldap_ad_add_selected'] = 'Add Selected Users';
$lang['ldap_ad_error_connection'] = 'Error: Unable to connect to LDAP server.';
$lang['ldap_ad_error_nousers'] = 'Must select at least one user to import.';
$lang['ldap_ad_create_users'] = 'Create Users';
$lang['ldap_ad_selected_desc'] = 'Select or de-select user to be created.';
$lang['ldap_ad_import_error_emails'] = 'Must enter a valid email address for each user.';
$lang['ldap_ad_import_error_usernames'] = 'Must be a unique username, the username(s) already exist.';

/* Also LDAP/AD, added for certificate management */
$lang['ldap_ad_hostname'] = 'Hostname';
$lang['ldap_ad_ca_management_header'] = 'Certificate Authority Management';
$lang['ldap_ad_ca_management_description'] = 'If you are using self-signed certificates to connect over SSL/TLS, you will need to add the domain controllers\' certificates to the local certificate authority.';
$lang['ldap_ad_issuer_ca'] = 'Issuer (CA)';
$lang['ldap_ad_expiration_date'] = 'Expiration Date';
$lang['ldap_ad_no_certs'] = 'No certificates have been added.';
$lang['ldap_ad_add_cert'] = 'Add Certificate';
$lang['ldap_ad_certificate_invalid'] = 'Certificate is invalid';
$lang['ldap_ad_cert_desc'] = 'To add a certificate to the certificate authority, copy and paste the actual certificate between, and including, the begin/end certificate sections.';
$lang['ldap_ad_cert'] = 'Certificate';

/* Percentile Calculator */
$lang['percentile_title1'] = 'Use the percentile calculator to calculate the bandwidth usage based on the netflow data collected.';
$lang['percentile_title2'] = 'There are limits to the accuracy of the data, please double check the data sample size when running this calculator over 2+ month time frames.';
$lang['percentile_how_button'] = 'How is this calculated?';
$lang['percentile_desc'] = 'The percentile calculation is done by taking samples of the data over a period of time you specify. Over that time period you get an amount of samples. Say you have 1000 samples. Each sample is of 5 minutes. A fairly common calculation is for the 95th percentile for billing. With 1000 samples, we will order the samples from smallest to largest size. We then take 5% of the samples off the higher side. We then take the leftover highest sample and that is the 95th percentile. We will generate a graph which shows a visual example of how we come to the conclusion on the right-hand side of the calculation area when a calculation is completed.';
$lang['percentile_timeframe'] = 'Time frame';
$lang['percentile_data_type'] = 'Select Data Type';
$lang['percentile'] = 'Percentile';
$lang['percentile_calc'] = 'Calculate';
$lang['percentile_error'] = 'You must fill out the time frame and percentile value.';
$lang['percentile_title'] = 'Percentile Calculation';
$lang['percentile_sample_size'] = 'Data sample size';
$lang['percentile_num_samples'] = 'Number of samples';
$lang['percentile_from'] = 'Generated for';

$lang['update_completed'] = 'Update Completed';
$lang['update_are_you_sure'] = 'Are you sure you want to perform an update?';
$lang['update_desc'] = 'Check with the Nagios server for updates to Network Analyzer. You can also install new updates directly from the web UI.';
$lang['update_check'] = 'Check for Updates';
$lang['update_available'] = 'Update Available';
$lang['update_now'] = 'Update Now';
$lang['update_none'] = 'You\'re running the latest version of Network Analyzer.';
$lang['update_running'] = '<strong>Starting Update.</strong> Please wait for update script to load...';
$lang['update_working'] = '<strong>Update in progress.</strong> Please wait. Update may take a few minutes.';
$lang['update_logs'] = 'Update Logs';
$lang['update_th1'] = 'Date of Update';
$lang['update_th2'] = 'Log File';
$lang['update_th3'] = 'Status';
$lang['update_no_logs'] = 'No updates have been performed through the web UI.';