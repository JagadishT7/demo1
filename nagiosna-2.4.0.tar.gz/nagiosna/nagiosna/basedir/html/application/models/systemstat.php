<?php

class Systemstat extends CI_Model
{

    // Non-nfcapd processes that make sense to restart.
    private $valid_subsystems = array('apache');

    // Load Source object
    function __construct() 
    {
        $this->load->library('Source', array('NOLOAD' => TRUE));
    }

    /**
     * @brief Start all NagiosNA related processes.
     */
    function start($sid)
    {
        $output = array();

        if(empty($sid) === FALSE) {
            $source = new Source($sid);
            $source_name = escapeshellarg($source->name);
        }
        
        exec("sudo -u nna /usr/local/nagiosna/bin/rc.py start {$source_name}", $output, $returncode);
        
        if($returncode !== 0) {
            throw new Exception(implode(' ', $output));
        }

        // Check for it to start before ending
        $offline = true;
        $timeout = 60;
        do {
            $s = $this->source_status($sid);
            if ($s->status == 'Running') {
                $offline = false;
            } else {
                sleep(1);
                $timeout = $timeout - 60;
                if ($timeout <= 0) {
                    $offline = false;
                }
            }
        } while($offline);

        return true;
    }
    
    /**
     * @brief Stop all NagiosNA related processes.
     */
    function stop($sid)
    {
        $output = array();
        
        if(empty($sid) === FALSE) {
            $source = new Source($sid);
            $source_name = escapeshellarg($source->name);
        }
        
        exec("sudo -u nna /usr/local/nagiosna/bin/rc.py stop {$source_name}", $output, $returncode);
        
        if($returncode !== 0) {
            throw new Exception(implode(' ', $output));
        }

        // Check for it to stop before ending
        $online = true;
        $timeout = 60;
        do {
            $s = $this->source_status($sid);
            if ($s->status == 'Stopped') {
                $online = false;
            } else {
                sleep(1);
                $timeout = $timeout - 60;
                if ($timeout <= 0) {
                    $online = false;
                }
            }
        } while($online);

        return true;
    }

    /**
     * @brief Restart all NagiosNA related processes.
     */
    function restart($sid)
    {
        $output = array();
        
        if(empty($sid) === FALSE) {
            $source = new Source($sid);
            $source_name = escapeshellarg($source->name);
        }
        
        exec("sudo -u nna /usr/local/nagiosna/bin/rc.py restart {$source_name}", $output, $returncode);

        if ($returncode !== 0) {
            throw new Exception(implode(' ', $output));
        }

        sleep(2);

        // Check for it to start before ending
        $offline = true;
        $timeout = 60;
        do {
            $s = $this->source_status($sid);
            if ($s->status == 'Running') {
                $offline = false;
            } else {
                sleep(1);
                $timeout = $timeout - 60;
                if ($timeout <= 0) {
                    $offline = false;
                }
            }
        } while($offline);

        return true;
    }

    /**
     * @brief Restart a part of NagiosNA that isn't nfcapd
     */
    function restart_subsystem($subsystem)
    {
        $result = array();

        if (!in_array($subsystem, $this->valid_subsystems)) {
            throw new Exception(lang('systemstat_invalid_subsystem'));
        }

        switch ($subsystem) {
            case 'apache':
                $cmd = 'nohup sudo /usr/bin/systemctl restart httpd > /dev/null 2>&1 &';
                break;
            default:
                break;
        }
        exec($cmd, $output, $ret);

        // Output the result and return to api to send as json
        $output = array_values(array_map('trim', array_filter($output)));

        $status = lang('systemstat_failed_restart');
        if ($ret == 0) {
            $status = lang('systemstat_restarting');
        }

        $result['return_code'] = $ret;
        $result['status'] = $status;

        return $result;
    }

    /**
     * @brief Status of the NagiosNA processes for a specific source.
     */
    function source_status($sid)
    {
        $source = new Source($sid);

        $selector = escapeshellarg($source->directory . '/' . $source->port . '.pid');
        $directory = escapeshellarg($source->directory);
        $output = array();
        exec('ps aux | grep ca*pd | grep '.$selector, $output);
        
        $diskusage = array();
        exec('du -sch '.$directory.' | tail -n1', $diskusage);
        $diskusage_output = explode("\t", $diskusage[0]);
        $json['diskusage'] = $diskusage_output[0];
        
        $json['icon'] = '<img src="' . base_url('media/icons/exclamation.png') . '" style="vertical-align: text-top;" title="Stopped" />';

        foreach($output as $line) {
            $matches = array();
            $matched = preg_match_all('/[^\s]+/', $line, $matches);
            if($matched !== 0 && $matched !== FALSE) {
                $json['status'] = 'Running';
                $json['pid'] = $matches[0][1];
                $json['owner'] = $matches[0][0];
                $json['icon'] = '<img src="' . base_url('media/icons/accept.png') . '" class="status-icon" title="Running" />';
                return $json;
            }
        }
        
        $json['status'] = 'Stopped';
        $json['pid'] = 'n/a';
        $json['owner'] = 'n/a';
        
        return $json;
    }
    
    /**
     * @brief Status of the hard disks on the machine
     */
    function cpu_status()
    {
        $output = array();
        exec('ps -eo pcpu', $output);
        
        $sum = 0.0;
        foreach($output as $percentage) {
            if(is_numeric($percentage)) {
                $sum += (float)$percentage;
            }
        }
            
        $user_load = $sum;
        
        return array("cpu_usage" => $user_load);
    }
    
    /**
     *  @brief Drive and filesystem status of local machine
     */
    function root_drive_status()
    {
        $output = array();
        
        exec('df -P /', $output);
        $output = preg_split('/ +/', $output[1]);
        return array(   'filesystem' => $output[0] * 1e3,
                        'size' => $output[1] * 1e3,
                        'used' => $output[2] * 1e3,
                        'available' => $output[3] * 1e3,
                        'percent' =>  1e2 * ($output[2] * 1e3) / ($output[1] * 1e3));
    }

    /**
     * @brief Memory available on the syste,
     */
    function memory_status() {
        $processed_free_lines = array();
        $mem = 0;
        $swap = 0;

        exec("free -m", $free_lines);

        foreach ($free_lines as $free_line) {
            $processed_free_lines[] = (preg_split('/\s+/', $free_line));
        }

        foreach ($processed_free_lines as $free_line) {
            if (empty($free_line[0]))
                continue;

            $free_line[0] = strtoupper($free_line[0]);

            if (substr($free_line[0], 0, 3) == "MEM") {
                $mem_total = $free_line[1];
                $mem_free = $free_line[3];
                $mem = (1 - ($mem_free / $mem_total)) * 100;
            } else if (substr($free_line[0], 0, 4) == "SWAP") {
                $swap_total = $free_line[1];
                $swap_free = $free_line[3];
                $swap = (1 - ($swap_free / $swap_total)) * 100;
            }
        }

        $json['used_percent'] = $mem;
        $json['swap_percent'] = $swap;

        return $json;
    }
}
