<?php

class Integrity extends CI_Model
{
    public function check()
    {
        if($this->config_option->get('dev_mode') || $this->config->item('dev_mode')) { return; }
       
        $file_list = array(
            dirname(__FILE__).'/../controllers/api/api_controller.php',
            dirname(__FILE__).'/../controllers/api/checks.php',
            dirname(__FILE__).'/../controllers/api/crud_controller.php',
            dirname(__FILE__).'/../controllers/api/graphs.php',
            dirname(__FILE__).'/../controllers/api/groups.php',
            dirname(__FILE__).'/../controllers/api/hostservices.php',
            dirname(__FILE__).'/../controllers/api/nagiosservers.php',
            dirname(__FILE__).'/../controllers/api/queries.php',
            dirname(__FILE__).'/../controllers/api/reports.php',
            dirname(__FILE__).'/../controllers/api/sources.php',
            dirname(__FILE__).'/../controllers/api/system.php',
            dirname(__FILE__).'/../controllers/api/trapreceivers.php',
            dirname(__FILE__).'/../controllers/api/views.php',
            dirname(__FILE__).'/../controllers/auth.php',
            dirname(__FILE__).'/../controllers/install.php',
            dirname(__FILE__).'/../controllers/trial.php',
            dirname(__FILE__).'/../core/NA_Controller.php',
            dirname(__FILE__).'/../helpers/licensing_helper.php',
            dirname(__FILE__).'/../helpers/nfdump_helper.php',
            dirname(__FILE__).'/../helpers/nfdump_validation_helper.php',
            dirname(__FILE__).'/../views/includes/header.php',
            dirname(__FILE__).'/../libraries/Check.php',
            dirname(__FILE__).'/../libraries/Exceptions.php',
            dirname(__FILE__).'/../libraries/Hostservices.php',
            dirname(__FILE__).'/../libraries/Query.php',
            dirname(__FILE__).'/../libraries/Report.php',
            dirname(__FILE__).'/../libraries/Server.php',
            dirname(__FILE__).'/../libraries/Source.php',
            dirname(__FILE__).'/../libraries/Sourcegroup.php',
            dirname(__FILE__).'/../libraries/Trapreceiver.php',
            dirname(__FILE__).'/../libraries/View.php',
        );
       
        foreach($file_list as $file) {
            $this->verify_file_integrity($file);
        }
    }

    function verify_file_integrity($file)
    {
        if(file_exists($file)) {
            if (!$this->is_file_properly_encrypted($file)) {
                echo "Corrupt file: ".$file."\n";
                file_put_contents($file, "<?php echo 'File Corrupt, Contact Nagios Support Immediately'; ?>");
            }
        }
    }

    function is_file_properly_encrypted($file)
    {
        $handle = fopen($file, 'r');
        $valid = false; // init as false
        while (($buffer = fgets($handle)) !== false) {
            if (strpos($buffer, "SourceGuardian") !== false) {
                $valid = TRUE;
                break; // Once you find the string, you should break out the loop.
            }
            if(strpos($buffer, "File Corrupt, Contact Nagios Support Immediately") !== false)
                break;
        }
        fclose($handle);
        if($valid)
            return true;
        return false;
    }
}
