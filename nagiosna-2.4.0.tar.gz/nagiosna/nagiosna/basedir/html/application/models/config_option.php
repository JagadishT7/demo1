<?php

class Config_Option extends CI_Model {

    const TABLE_NAME = 'nagiosna_cf_options';

    public $id;
    public $created;
    public $created_by;
    public $modified;
    public $name;
    public $value;

    public function __construct($data = array())
    {
        parent::__construct();
        $this->load->helper('data');
        import_data($this, $data);
    }

    /**
     * This is so the parent class can get our table name.
     **/
    public function get_table_name()
    {
        return self::TABLE_NAME;
    }

    /**********************
     * manager methods
     **********************/

    public function hydrate($data)
    {
        return new self($data);
    }

    /**
     * Get a list of all option name/value pairs
     **/
    public function get_all()
    {
        $this->db->select('*')->from(self::TABLE_NAME);
        $query = $this->db->get();
        return $this->result_as_model_objects($query->result());
    }

    /**
     * Get a single option item by id or name
     **/
    public function get($id_or_name)
    {
        if(is_numeric($id_or_name)) {
            $q = array('id' => $id_or_name);
        } else {
            $q = array('name' => $id_or_name);
        }
        $query = $this->db->get_where(self::TABLE_NAME, $q);
        if($query->num_rows() > 0) {
            return new self($query->row());
        }
        return FALSE;
    }

    /**
     * Create an option name/value pair
     **/
    public function create($name, $value)
    {
        if($user_id = $this->ion_auth->get_user_id()) {
            $created_by = $user_id;
        } else {
            $created_by = 0;
        }
        $this->db->insert(self::TABLE_NAME, array(
            'created' => date("Y-m-d H:i:s"),
            'created_by' => $created_by,
            'name' => $name,
            'value' => $value
        ));
    }

    /*
     * Set the value (create or update)
     */
    public function set($name, $value)
    {
        if (!$this->get($name)) {
            // Create
            $this->create($name, $value);
        } else {
            // Update
            $this->update($name, $value);
        }
    }

    /**
     * get created_by user (assumes created_by field on all children)
     **/
    public function get_created_by_user()
    {
        if($this->created_by) {
            return $this->created_by;
        }
        return FALSE;
    }

    /**
     * get modified_by user (assumes modified_by field on all children)
     **/
    public function get_modified_by_user()
    {
        if($this->modified_by) {
            return $this->modified_by;
        }
        return FALSE;
    }

    public function update($id_or_name, $value) {
        if($user_id = $this->ion_auth->get_user_id()) {
            $modified_by = $user_id;
        } else {
            $modified_by = 0;
        }

        if(is_numeric($id_or_name)) {
            $q = array('id' => $id_or_name);
        } else {
            $q = array('name' => $id_or_name);
        }

        $this->db->where($q);
        $this->db->update(self::TABLE_NAME, array('value' => $value));
    }

    /**
     * Delete this object from the db
     **/
    public function delete()
    {
        if($this->id) {
            $this->db->where('id', $this->id);
            $this->db->delete($this->get_table_name());
        }
    }

    /**
     * Mark this row as modified (wrapper for update())
     **/
    public function set_modified($date=FALSE)
    {
        if(!$this->id) {
            return FALSE;
        }
        if($date && strtotime($date) === -1) {
            return FALSE;
        }
        if($date == FALSE) {
            $date = date("Y-m-d H:i:s");
        }
        $this->update(array('modified' => $date, 'modified_by' => $this->ion_auth->get_user()->id));
    }

    /**
     * Turn a queryset of StdClass to actual ($this) model objects
     **/
    protected function result_as_model_objects($results)
    {
        $result = array();
        foreach($results as $data) {
            $result[] = $this->hydrate($data);
        }
        return $result;
    }
}
