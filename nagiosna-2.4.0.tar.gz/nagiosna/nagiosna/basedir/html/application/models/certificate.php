<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

class Certificate extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    // $raw_cert - a raw certificate string in PEM format
    public function add($raw_cert, $cert_dir, $cacert_dir)
    {

        if (!$this->verify_directory($cert_dir)) {
            $output = array("message" => sprintf(_("Could not write to %s"), $cert_dir),
                            "error" => 1);
            return $output;
        }

        if (!$this->verify_directory($cacert_dir)) {
            $output = array("message" => sprintf(_("Could not write to %s"), $cacert_dir),
                            "error" => 1);
            return $output;
        }

        if (openssl_x509_parse($raw_cert) === false) {
            return false;
        }

        $id = uniqid();
        $cert_file = "$cert_dir/$id.crt";
        $pem_file = "$cert_dir/$id.pem";

        file_put_contents($cert_file, $raw_cert);
        shell_exec("openssl x509 -in $cert_file -text > $pem_file");

        // Verify that the certificate doesn't already exist.
        $hash = trim(shell_exec("openssl x509 -noout -hash -in $pem_file"));

        $exists = false;
        if ($dh = opendir($cacert_dir)) {
            while (false !== ($entry = readdir($dh))) {
                if ($entry == $hash.".0") {
                    $exists = true;
                }
            }
            closedir($dh);
        }

        // Fail out if it exists or we can continue
        if ($exists) {
            // Remove files we created
            shell_exec("rm -rf $cert_file $pem_file");
            $output = array("message" => _("This certificate has already been added."),
                            "error" => 1);
            return $output;
        }

        shell_exec("cd $cacert_dir; ln -s $pem_file $hash.0;");

        $output = array('message' => _("Successfully added certificate!"),
                        'error' => 0,
                        'id' => $id);
        return $output;
    }

    public function remove($id, $cert_dir, $cacert_dir)
    {

        $pem_file = "$cert_dir/$id.pem";
        $cert_file = "$cert_dir/$id.crt";
        shell_exec("rm -rf $cacert_dir/`openssl x509 -noout -hash -in $pem_file`.0");
        shell_exec("rm -rf $pem_file $cert_file");
    }

    private function verify_directory($directory)
    {

        if (!is_dir($directory) && !mkdir($directory, 0770, true)) {
            return false;
        }

        if (!is_writable($directory)) {
            return false;
        }

        return true;
    }
}