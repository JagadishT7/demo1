<?php

class Hostservice extends CRUD_Model {

    function __construct()
    {
        parent::__construct();
        $this->t = "nagiosna_HostServiceAssociations";
    }
    
    /**
     * Create function that will add a Host/Service to the database.
     * 
     * @param $p Array containing arguments.
     *      
     *      servicename String representing the servicename on the Nagios server
     *      hostname String representing the hostname on the Nagios server
     *      servername String representing the servername of the Nagios Server
     * 
     * @throws Exception with database errors.
     * @throws ValidationError with validation errors
     */
    function create($q)
    {
        $this->load->model('Nagiosserver');
        
        if(empty($q['hostname']) === TRUE) {
            throw new ValidationError('Hostname is empty but must be given.');
        }
        
        if(empty($q['servicename']) === TRUE) { 
            throw new ValidationError('Servicename is empty but must be given.');
        }
        
        $server = $this->Nagiosserver->read_one(array('name' => $q['servername']));
        $q['serverid'] = $server->id;
        unset($q['servername']);
        
        $success = $this->db->insert($this->t, $q);
        
        if($success == FALSE) {
            throw new Exception($this->db->_error_message());
        }
    }
    
    /**
     * @brief Associate a Host/Service definition with a check.
     * 
     * @param $q
     *      name String name of the check that will be associated
     *      hostname String hostname of the Host/Service definition
     *      servicename String servicename of the Host/Service definition
     * 
     * Associates the two in a relational database for later use by
     * the subsystem to send out checks.
     * 
     * @throws ValidationError on validation errors
     * @throws Exception on database errors
     */
    function associate_with_check($q)
    {
        $ASSOCIATION_TABLE = 'nagiosna_ChecksHSALinker';
        $this->load->model('Check');
        
        if(array_key_exists('name', $q) === FALSE) {
            throw new ValidationError('name does not exist in query array');
        }
        
        if(array_key_exists('hostname', $q) === FALSE) {
            throw new ValidationError('hostname does not exist in query array');
        }
        
        if(array_key_exists('servicename', $q) === FALSE) {
            throw new ValidationError('servicename does not exist in query array');
        }
        
        $check = $this->Check->read_one(array('name' => $q['name']));
        $hostservice = $this->read_one(array(   'hostname' => $q['hostname'],
                                                'servicename' => $q['servicename'] ));
        
        $success = $this->db->insert($ASSOCIATION_TABLE, array( "cid" => $check->id,
                                                                "aid" => $hostservice->id ));
        
        if($success === FALSE) {
            throw new Exception($this->db->_error_message());
        }
    }
    
    /**
     * @brief Deletes the given Host/Service and all of its relations
     * 
     * @param $q
     *      Same as CRUD_Model->delete
     * 
     * Deletes all relations to Nagios Servers and Checks for the given
     * Host/Service.
     * 
     * @throws ValidationError on validation errors
     * @throws Exception on database errors
     */
    function delete($q)
    {
        try {
            $hostservice = $this->read_one($q);
        }
        catch (Exception $e) {
            log_message('info', 'Trying to delete non-existant host/service: '.$e->getMessage());
            return;
        }
        
        $ASSOCIATION_TABLE = 'nagiosna_ChecksHSALinker';
        $this->db->delete($ASSOCIATION_TABLE, array('aid' => $hostservice->id));
        
        parent::delete($q);
    }
}