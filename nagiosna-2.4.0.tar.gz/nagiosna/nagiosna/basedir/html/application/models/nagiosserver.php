<?php

class Nagiosserver extends CRUD_Model {

    function __construct()
    {
        parent::__construct();
        $this->t = "nagiosna_NagiosServers";
    }
    
    /**
     * @brief Validates the given NRDP server and token combination
     * 
     * @param $server The URL of the NRDP server
     * @param $token The token to access the NRDP server
     * 
     * Tests whether or not the given NRDP server/token combo is legitimate.
     * Attempts to connect to the NRDP server, and on failure throws
     * and acceptable reason for failure.
     * 
     * @throws ValidationError on missed connection or bad token
     */
    function validate_nrdp_server_with_token($server, $token)
    {
        $url = "{$server}?token={$token}&cmd=submitcmd";
        $xml = @file_get_contents($url);
        $parsed = @simplexml_load_string($xml);
        
        if($parsed === FALSE) {
            throw new ValidationError('URL does not appear to be an NRDP server: '.$server);
        }
        
        if(trim($parsed->message) !== 'NO COMMAND') {
            throw new ValidationError('NRDP server said '.trim($parsed->message));
        }
    }
    
    /**
     * @brief Create function that will add a report to the database.
     * 
     * @param $q Array containing arguments.
     *      
     *      token String representing the token to access the NRDP
     *      nrdp String representing the address to the NRDP server
     *      name String representing the nice name that will be displayed
     * 
     * @throws Exception with database errors.
     * @throws ValidationError with validation errors
     */
    function create($q)
    {
        $this->validate_nrdp_server_with_token($q['nrdp'], $q['token']);
        
        if($this->name_is_unique($q['name']) === FALSE) {
            throw new ValidationError('name is not unique');
        }
        
        $success = $this->db->insert($this->t, $q);
        
        if($success == FALSE) {
            throw new Exception($this->db->_error_message());
        }
    }
    
    function name_is_unique($name)
    {
        try {
            $this->read_one(array('name' => $name));
            return FALSE;
        }
        catch (Exception $e) {
            return TRUE;
        }
    }
}