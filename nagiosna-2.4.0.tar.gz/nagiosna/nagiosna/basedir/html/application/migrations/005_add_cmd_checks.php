<?php
//
// This migration adds the "ChecksCmdLinker" and "Commands" table into the Nagios NA MySQL database
// which allows adding the execute local command check type
//

class Migration_add_cmd_checks extends CI_Migration {
    
    function up()
    {
        // Generate the linker table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_ChecksCmdLinker` (
    `cid` INT NOT NULL,
    `cmdid` INT NOT NULL,
    PRIMARY KEY(`cid`, `cmdid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);

        // Generate the new command table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_Commands` (
    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200),
    `location` TEXT,
    `script` VARCHAR(200),
    `arguments` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);
    }
    
    function down()
    {
        // There is no down
    }
}