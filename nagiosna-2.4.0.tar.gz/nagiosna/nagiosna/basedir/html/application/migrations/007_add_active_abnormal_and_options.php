<?php
//
// This migration alters the option value size to be text, to allow for storing more
// data in the options database.
//
// This also adds abnormal_behavior as a metric type for active checks.
// 

class Migration_add_active_abnormal_and_options extends CI_Migration {
    
    function up()
    {
    	// Alter option size
        $sql = "ALTER TABLE nagiosna_cf_options MODIFY value TEXT;";
        $this->db->query($sql);

        // Add the metrc type abnormal_behavior
        $sql = "ALTER TABLE nagiosna_Checks MODIFY metric enum('bytes', 'flows', 'packets', 'bps', 'pps', 'bpp', 'abnormal_behavior');";
        $this->db->query($sql);
    }

    function down()
    {
        // There is no down
    }
}