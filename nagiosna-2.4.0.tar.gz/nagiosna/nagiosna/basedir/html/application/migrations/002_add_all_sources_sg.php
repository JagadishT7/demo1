<?php
//
// This migration adds the "All Sources" source group to the sql
//

class Migration_add_all_sources_sg extends CI_Migration {
    
    function up()
    {
    	// Load Pre-Reqs
        $this->load->library('Source', array('NOLOAD' => TRUE));
        $this->load->library('Sourcegroup', array('NOLOAD' => TRUE));

        // Grab all the Source Groups out of the DB and create/add group "All Sources"
        $sg_list = array();
        $sql = "SELECT * FROM `nagiosna_SourceGroups` WHERE `gid` = 1;";
        $query = $this->db->query($sql);
        if ($query->num_rows() == 1) {
            $sg = $query->row();

            // Check if we have to perform this migration or not
            if ($sg->name == "All Sources") {
                return;
            }

            // Update the source group's name
            $this->db->query("UPDATE `nagiosna_SourceGroups` SET `name` = 'All Sources' WHERE `gid` = 1");

            // Create a new source group
            $sgobj = Sourcegroup::create(array('name' => $sg->name));

            // Update checks with new SG gid
            $this->db->query("UPDATE `nagiosna_Checks` SET `gid` = ".intval($sgobj->gid)." WHERE `gid` = 1;");

            // Get all the associations with this sourcegroup
            $this->db->query("UPDATE `nagiosna_SGLinker` SET `gid` = ".intval($sgobj->gid)." WHERE `gid` = 1;");

        } else {
            $this->db->query("INSERT INTO `nagiosna_SourceGroups` (`gid`, `name`) VALUES (1, 'All Sources')");
        }

        // Add all sources to the new "All Sources" Source Group
        $sources = Source::enumerate();
        $sg = new Sourcegroup(1);
        foreach ($sources as $source) {
            $sg->add_source_associations($source['sid']);
        }
    }
    
    function down()
    {
    	// There is no down
    }
}

?>