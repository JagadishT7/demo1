<?php
//
// This migration adds the "Cmdsubsys" table into the Nagios NA MySQL database
// Also alters IP address table in sources to allow a list of ips
//

class Migration_add_cmdsubsys extends CI_Migration {
    
    function up()
    {
        // Generate a new table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_cmdsubsys` (
  `id` varchar(30) NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `command` int(11) unsigned NOT NULL,
  `args` TEXT,
  `processing` tinyint(1) unsigned DEFAULT 0,
  `completed` tinyint(1) unsigned DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);

        // Edit the ip column in nagiosna_Sources
        $this->db->query("ALTER TABLE nagiosna_Sources DROP INDEX ip;");
        $this->db->query("ALTER TABLE nagiosna_Sources MODIFY ip TEXT;");
        $this->db->query("ALTER TABLE nagiosna_Sources CHANGE ip addresses TEXT;");
    }
    
    function down()
    {
        // There is no down
    }
}