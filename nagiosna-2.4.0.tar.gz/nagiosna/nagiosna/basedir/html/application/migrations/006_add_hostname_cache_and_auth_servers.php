<?php
//
// This migration adds the "hostname_cache" and "auth_servers" table into the Nagios NA MySQL database
// which allows the caching of hostnames instead of having to look them up every time.
//
// This will also update/add fields to the user database to allow connecting to authenticaton servers
// such as LDAP / AD servers via a Distinguished Name (DN) on an authentication server.
//
// Also updates the nagiosna_Sources table adding a "disable_abnormal" field that is defaulted to 0.
//

class Migration_add_hostname_cache_and_auth_servers extends CI_Migration {
    
    function up()
    {
        // Generate the hostname caching table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_hostname_cache` (
                    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    `ip` VARCHAR(120),
                    `hostname` VARCHAR(200),
                    `time` VARCHAR(20),
                    INDEX (ip)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);

        // Generate the auth servers table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_auth_servers` (
                    `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    `active` TINYINT(1),
                    `name` TEXT,
                    `host` VARCHAR(200),
                    `type` ENUM('ad', 'ldap'),
                    `encryption` ENUM('none', 'ssl', 'tls'),
                    `basedn` TEXT,
                    `suffix` VARCHAR(160),
                    `controllers` TEXT,
                    `port` VARCHAR(10)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);

        // Update the users table for user type
        $sql = "ALTER TABLE nagiosna_users ADD type VARCHAR(100) DEFAULT 'local';";
        $this->db->query($sql);

        $sql = "ALTER TABLE nagiosna_users ADD auth_server_id INT;";
        $this->db->query($sql);

        $sql = "ALTER TABLE nagiosna_users ADD auth_server_data TEXT;";
        $this->db->query($sql);

        // Update the nagiosna_Sources fields
        $sql = "ALTER TABLE nagiosna_Sources ADD disable_abnormal TINYINT(1) DEFAULT 0;";
        $this->db->query($sql);
    }
    
    function down()
    {
        // There is no down
    }
}