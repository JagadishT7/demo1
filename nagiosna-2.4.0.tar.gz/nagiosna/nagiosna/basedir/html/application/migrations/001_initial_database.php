<?php
// Placeholder migration

class Migration_initial_database extends CI_Migration {
    
    function up() {}
    
    function down() {}
}

?>