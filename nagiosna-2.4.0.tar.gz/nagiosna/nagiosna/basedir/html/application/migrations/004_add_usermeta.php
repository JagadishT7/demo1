<?php
//
// This migration adds a user metadata table to the database
//

class Migration_add_usermeta extends CI_Migration {
    
    function up()
    {
        // Generate a new table
        $sql = "CREATE TABLE IF NOT EXISTS `nagiosna_usermeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $this->db->query($sql);
    }
    
    function down()
    {
        // There is no down
    }
}