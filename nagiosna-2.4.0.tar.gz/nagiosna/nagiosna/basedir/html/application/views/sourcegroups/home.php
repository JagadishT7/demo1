<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('breadcrumb_sourcegroups'); ?></li>
</ul>

<script type="text/javascript">
var GROUP_LIST = [];
$(document).ready(function() {

    load_group_list();

    // Make the enter key also work
    $('#sg_search_input').keyup(function(e) {
        if (e.keyCode == 13) {
            $('#sg_search').trigger('click');
        }
    });

    // Search sources
    $('#sg_search').click(function() {
        load_group_list();
    });

});

function load_group_list()
{
    $.post(site_url + 'api/groups/read', { 's[name]': $('#sg_search_input').val(), <?php echo get_csrf_block(); ?> }, function(groups) {
        GROUP_LIST = groups;
        var table = '';
        var cols = <?php if ($is_admin) { echo 3; } else { echo 2; } ?>;
        if (GROUP_LIST.length > 0) {
            $.each(GROUP_LIST, function(key, group) {
                table +='<tr><td><a href="' + site_url + 'groups/' + group.gid + '">' + group.name + '</a></td>';
                table += '<td id="groupid' + group.gid + '">';
                table += '</td>';
                <?php if ($is_admin) { ?>
                    if (group.gid != 1) {
                        table += '<td><a href="#" data-gid="' + group.gid + '" data-name="' + group.name + '" class="delete_group"><?php echo lang("delete"); ?></a></td>';
                    } else {
                        table += '<td></td>';
                    }
                <?php } ?>
                table +='</tr>';
            });
        } else {
            table += '<tr><td colspan="' + cols + '"><?php echo lang("home_sourcegroup_none_exist"); ?></td></tr>';
        }
        $('#table-body').html(table);
        bind_buttons();
        load_group_associations();
    }, 'json');
}

function bind_buttons()
{
    <?php if ($is_admin) { ?>
    $('.delete_group').unbind();
    $('.delete_group').click(function() {
        var group_name = $(this).data('name');
        var gid = $(this).data('gid');
        var conf = confirm("<?php echo lang('home_sourcegroup_are_you_sure'); ?> " + group_name);
        if (conf === true && gid != 1) {
            $.post(site_url + 'api/groups/delete', { 'q[gid]': gid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                } else {
                    load_group_list();
                }
            }, 'json');
        }
    });
    <?php } ?>
}

function load_group_associations()
{
    if (GROUP_LIST.length > 0) {
        $.each(GROUP_LIST, function(key, group) {
            $.post(site_url + 'api/groups/read_source_associations', { 'q[gid]': group.gid, <?php echo get_csrf_block(); ?> }, function(sources) {
                var text = '';
                var i = 0;
                $.each(sources, function(key, source) {
                    text += source.name;
                    i++;
                    if (sources.length > i) { text += ', '; }
                });
                
                // Add a list to the source group list?
                var edit = '';
                <?php if ($is_admin) { ?>
                    if (group.gid != 1) {
                        edit = ' (<a href="<?php echo site_url("groups/edit/' + group.gid + '"); ?>"><?php echo lang("change"); ?></a>)';
                    }
                <?php } ?>

                $('#groupid' + group.gid).html(text + edit);
            }, 'json');
        });
    }
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('home_sourcegroup_title'); ?></h2>
            <p><?php echo lang('home_sourcegroup_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 15px;">
        <div class="span6">
            <?php if ($is_admin) { ?>
            <a href="<?php echo site_url('groups/create'); ?>" class="btn"><i class="icon-th-large"></i> <?php echo lang('home_sourcegroup_create'); ?></a>
            <?php } ?>
        </div>
        <div class="span6" style="text-align: right;">
            <div class="form-horizontal">
                <input type="text" id="sg_search_input" placeholder="<?php echo lang('home_sourcegroup_search_placeholder'); ?>"></input> <button class="btn" id="sg_search"><i class="icon-search"></i></button>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th style="width: 40%;"><?php echo lang('home_sourcegroup_th_name'); ?></th>
                        <th><?php echo lang('home_sourcegroup_th_sources'); ?></th>
                        <?php if ($is_admin) { ?>
                        <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                        <?php } ?>
                    </tr>
                </thead>
                <tbody id="table-body">
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php echo $footer; ?>