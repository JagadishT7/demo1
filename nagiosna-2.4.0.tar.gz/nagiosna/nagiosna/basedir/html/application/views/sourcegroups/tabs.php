<script type="text/javascript">
<?php
echo 'var type = "' . $type . '";';
echo 'var group_id = ' . $group->gid . ';';
echo 'var apikey = "' . $apikey . '";';
echo 'var apiaccess = ' . $apiaccess . ';';
?>
var view_id = 0;

$(document).ready(function() {
    
    get_sourcegroup_assocs();

    // Set up remove source button
    $('#remove').click(function() {
        $('#remove-modal').modal('show');
    });

    $('.container').on('click', '.more-sources', function() {
        $('#assoc-modal').modal('show');
    });
});

function get_sourcegroup_assocs() {
    $.post(site_url + 'api/groups/read_source_associations', { 'q[gid]': group_id, <?php echo get_csrf_block(); ?> }, function(sources) {
        var text = '';
        var i = 0;
        var n = 0;
        $.each(sources, function(key, source) {
            $('#assoc-modal .sources').append('<tr><td><a href="'+site_url+'sources/'+source.sid+'">'+source.name+'</a></td></tr>');
            if (i < 4) {
                text += '<a href="'+site_url+'sources/'+source.sid+'">'+source.name+'</a>';
                i++;
                if (sources.length > i) { text += ', '; }
            } else {
                n++;
            }
        });
        if (n > 0) {
            text += '<a class="more-sources" title="<?php echo lang("home_sourcegroup_showall"); ?>">and '+n+' more sources</a> <i class="fa fa-plus-circle" title="<?php echo lang("home_sourcegroup_showall"); ?>"></i>';
        }
        $('#num_sources').html(text);
    });
}
</script>

    <!-- Show all associated sources, linking to them for easy access -->
    <div id="assoc-modal" class="modal hide fade">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 id="myModalLabel"><?php echo lang('home_sourcegroup_assoc_header'); ?></h3>
        </div>
        <div class="modal-body" style="max-height: 400px;">
            <table class="table table-striped table-condensed table-bordered" style="margin: 0;">
                <thead>
                    <tr>
                        <th>Source Name</th>
                    </tr>
                </thead>
                <tbody class="sources"></tbody>
            </table>
        </div>
        <div class="modal-footer">
            <button class="btn" data-dismiss="modal"><?php echo lang('close'); ?></button>
        </div>
    </div>

    <div class="row-fluid">
        <div class="span6">
            <div style="padding: 10px 0 20px 0;">
                <div style="margin-right: 20px; font-size: 32px; font-weight: bold; line-height: 28px;"><?php echo lang('breadcrumb_sourcegroup'); ?> - <?php echo $group->name; ?></div>
            </div>
        </div>
        <div class="span6 <?php if (!empty($download)) { echo 'hide'; } ?>" style="text-align: right; line-height: 60px;">
            <div id="status">
                <strong><?php echo lang('tab_sourcegroup_sources'); ?>:</strong> <span id="num_sources">Loading...</span><a href="#" class="btn btn-mini hide" style="margin-left: 6px;">View all</a>
            </div>
        </div>
    </div>
    <div class="row-fluid <?php if (!empty($download)) { echo 'hide'; } ?> generic-tab-box">
        <div class="span12">
            <ul class="nav nav-tabs" style="margin-bottom: 0;">
                <?php if ($tab == 'summary') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('groups/' . $group->gid); ?>"><i class="icon-home"></i> <?php echo lang('tabs_summary'); ?></a></li>
                <?php if ($tab == 'reports') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('groups/reports/' . $group->gid); ?>"><i class="icon-book"></i> <?php echo lang('tabs_reports'); ?></a></li>
                <?php if ($tab == 'queries') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('groups/queries/' . $group->gid); ?>"><i class="icon-play-circle"></i> <?php echo lang('tabs_queries'); ?></a></li>
                <?php
                if ($is_admin && $group->gid != 1) { ?>
                    <li style="float: right;"><a href="#" id='remove'><i class="icon-trash"></i> <?php echo lang('tabs_remove'); ?></a></li>
                    <?php if ($tab == 'edit') { echo '<li class="active" style="float: right;">'; } else { echo '<li style="float: right;">'; } ?>
                        <a href="<?php echo site_url('groups/edit/' . $group->gid); ?>"><i class="icon-wrench"></i> <?php echo lang('tabs_edit'); ?></a></li>
                <?php } ?>
                <?php if ($tab == 'percentile') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('groups/percentile/' . $group->gid); ?>"><i class="icon-signal"></i> <?php echo lang('tabs_percentile'); ?></a></li>
            </ul>
            <div id="remove-modal" class="modal hide fade" tabindex="-1" role="dialog">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3><?php echo lang('tabs_delete_modal_header'); ?></h3>
                </div>
                <div class="modal-body">
                    <?php echo lang('tabs_sourcegroup_delete_modal_text'); ?>
                </div>
                <div class="modal-footer">
                    <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
                    <a href="#" id="remove-modal-yes" class="btn btn-danger"><?php echo lang('yes_button'); ?></a>
                </div>
            </div>
        </div>
    </div>
