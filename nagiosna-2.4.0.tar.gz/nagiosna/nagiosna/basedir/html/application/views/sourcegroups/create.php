<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('groups'); ?>"><?php echo lang('header_tab_sourcegroups'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('create_sourcegroup_heading'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    // Load a list of sources
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(sources) {
        if (sources.length) {
            $.each(sources, function(key, value) {
                $('#sourcelist').append('<option value="' + value.sid + '">' + value.name + '</option>');
            });
        }
    });

    // Do add/remove additions

    $('#add_button').click(function() {
        var opsid = $('#sourcelist').val() || [];
        if (opsid.length > 0) {
            $.each(opsid, function(key, sid) {
                var name = $('#sourcelist option[value="' + sid + '"]').text();
                $('#group_sourcelist').append('<option value="' + sid + '">' + name + '</option>');
            });
        }
        $('#sourcelist option:selected').remove();
    });

    $('#remove_button').click(function() {
        var opsid = $('#group_sourcelist').val() || [];
        if (opsid.length > 0) {
            $.each(opsid, function(key, sid) {
                var name = $('#group_sourcelist option[value="' + sid + '"]').text();
                $('#sourcelist').append('<option value="' + sid + '">' + name + '</option>');
            });
        }
        $('#group_sourcelist option:selected').remove();
    });

    // Create the group
    $('#create_group').click(function() {
        $('#display_error').hide();
        $('#group_sourcelist option').attr('selected', 'selected');
        var selected_sids = $('#group_sourcelist').val() || [];
        var group_name = $('input[name="group_name"]').val();
        if (group_name == '') { $('#display_error').html("<?php echo lang('create_sourcegroup_no_name'); ?>").show(); }
        else if (selected_sids.length == 0) { $('#display_error').html("<?php echo lang('create_sourcegroup_no_sources'); ?>").show(); }
        else {
            $.post(site_url + 'api/groups/create', { 'q[name]': group_name, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status == 'success') {
                    $.post(site_url + 'api/groups/add_source_associations', { 'q[gid]': data.gid, 'q[sid]': selected_sids, <?php echo get_csrf_block(); ?> }, function(data) {
                        window.location.href = site_url + 'groups';
                    });
                } else {
                    // Display error
                    $('#display_error').html(data.error).show();
                }
            });
        }
    });

});
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('create_sourcegroup_heading');?></h2>
            <p><?php echo lang('create_sourcegroup_subheading');?></p>
            <div style="border-bottom: 1px solid #DDD; margin-bottom: 20px;">
            </div>
            <div class="hide alert alert-error" id="display_error"></div>
            <div>
                <table>
                    <tr>
                        <td class="form-left"><?php echo lang('create_sourcegroup_name'); ?>*:</td>
                        <td>
                            <div><input type="text" name="group_name" style="margin: 0;" value="<?php echo set_value('group_name'); ?>"></div>
                            <div style="font-size: 11px; padding-bottom: 10px;"><?php echo lang('create_sourcegroup_name_desc'); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"> </td>
                        <td>
                            <div style="float: left;">
                                <div style="font-weight:bold;"><?php echo lang('create_sourcegroup_all_sources'); ?></div>
                                <select size="8" multiple id="sourcelist">
                                </select>
                            </div>
                            <div style="float: left; padding: 20px 10px 10px 10px;">
                                <button type="button" class="btn btn-small" title="<?php echo lang('create_sourcegroup_add'); ?>" style="display: block; margin-bottom: 10px;" id="add_button"><i class="icon-arrow-right"></i></button>
                                <button type="button" class="btn btn-small btn-danger" title="<?php echo lang('create_sourcegroup_remove'); ?>" style="display: block;" id="remove_button"><i class="icon-arrow-left icon-white"></i></button>
                            </div>
                            <div style="float: left;">
                                <div style="font-weight:bold;"><?php echo lang('create_sourcegroup_sources'); ?></div>
                                <select size="8" multiple name="group_sourcelist[]" id="group_sourcelist">
                                </select>
                            </div>
                            <div class="clear"></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left" style="padding-top: 0;"><?php echo lang('create_sourcegroup_lifetime'); ?>:</td>
                        <td><?php echo lang('create_sourcegroup_lifetime_text'); ?></td>
                    </tr>
                </table>
            </div>
            <div style="margin-top: 15px;" class="form-actions">
                <button type="button" id="create_group" class="btn btn-primary"><?php echo lang('create_sourcegroup_submit_btn'); ?></button>
                <a href="<?php echo site_url('groups'); ?>" class="btn"><?php echo lang('cancel_button'); ?></a>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>