<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_views'); ?></li>
</ul>

<script type="text/javascript">
var VIEWS_LIST = [];

$(document).ready(function() {

    load_views_list();

    $('#view_search').click(function() {
        load_views_list();
    });
    
    $('#view_search_input').keyup(function(e) {
        if (e.keyCode == 13) {
            $('#view_search').trigger('click');
        }
    });

    <?php if ($is_admin) { ?>
    // Create
    $('#create_view_btn').click(function() {
        var vars = { <?php echo get_csrf_block(); ?> }
        vars['q[name]'] = $('#view_name').val();
        vars['q[limiter]'] = $('#limiter').val();
        vars['q[lifetime]'] = $('#lifetime').val() + $('#lifetime_suffix').val();

        $.post(site_url + 'api/views/create', vars, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                // Popup the next box!
                $('#create_view').modal('hide');
                load_views_list();
            }
        }, 'json');
    });

    // Delete multiple button
    $('#delete_multi_views_btn').click(function() {
        var view_ids = $('input:checkbox[name=views]:checked').map(function(_, el) {
            return $(el).val();
        }).get();
        var conf = confirm("<?php echo lang('view_home_delete_all_warning'); ?>");
        if (conf === true) {
            $.post(site_url + 'api/views/delete', { 'q[vid]': view_ids, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                } else {
                    load_views_list();
                }
            }, 'json');
        }
    });

    // Update view button
    $('#update_view_btn').click(function() {
        var vars = { <?php echo get_csrf_block(); ?> }
        vars['q[vid]'] = $('#vid').val();
        vars['u[name]'] = $('#update_view_name').val();
        vars['u[limiter]'] = $('#update_limiter').val();
        vars['u[lifetime]'] = $('#update_lifetime').val() + $('#update_lifetime_suffix').val();

        $.post(site_url + 'api/views/update', vars, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                $('#update_view').modal('hide');
                load_views_list();
            }
        }, 'json');
    });

    // Do add/remove additions

    $('#add_assoc_button').click(function() {
        var opsid = $('#sourcelist').val() || [];
        if (opsid.length > 0) {
            $.each(opsid, function(key, sid) {
                var name = $('#sourcelist option[value="' + sid + '"]').text();
                $('#assoc_sourcelist').append('<option value="' + sid + '">' + name + '</option>');
            });
        }
        $('#sourcelist option:selected').remove();
    });

    $('#remove_assoc_button').click(function() {
        var opsid = $('#assoc_sourcelist').val() || [];
        if (opsid.length > 0) {
            $.each(opsid, function(key, sid) {
                var name = $('#assoc_sourcelist option[value="' + sid + '"]').text();
                $('#sourcelist').append('<option value="' + sid + '">' + name + '</option>');
            });
        }
        $('#assoc_sourcelist option:selected').remove();
    });

    $('#assoc_view_btn').click(function() {
        var vid = $('#vid').val();
        $('#assoc_view_error').hide();
        $('#assoc_view_message').hide();
        $('#assoc_sourcelist option').prop('selected', true);
        var assoc_sids  = $('#assoc_sourcelist').val() || [];
        $('#sourcelist option').prop('selected', true);
        var unassoc_sids = $('#sourcelist').val() || [];

        console.log(assoc_sids);
        console.log(unassoc_sids);

        // if (selected_sids.length == 0) { $('#assoc_view_error').html("You must select at least one source.").show(); }
        $.post(site_url + 'api/views/delete_source_associations', { 'q[vid]': vid, 'q[sid]': unassoc_sids, <?php echo get_csrf_block(); ?> }, function(data) {
            if (data) {
                $.post(site_url + 'api/views/add_source_associations', { 'q[vid]': vid, 'q[sid]': assoc_sids, <?php echo get_csrf_block(); ?> }, function(data) {
                    //$('#assoc_view_message').html('View associations saved successfully.').show();
                    $('#assoc_view').modal('hide');
                    load_assoc_list();
                });
            } else {
                // Display error
                //$('#assoc_view_error').html(data.error).show();
                $('#assoc_view').modal('hide');
                load_assoc_list();
            }
        });
    });
    <?php } ?>

});

function bind_buttons()
{
    <?php if ($is_admin) { ?>
    $('.view_view').unbind();
    $('.view_view').click(function() {
        var vid = $(this).data('vid');

        // Get all view data
        $.post(site_url + 'api/views/read', { 's[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
            view = data[0];
            $('#update_view_name').val(view.name);
            $('#update_limiter').val(view.limiter);

            var lifetime = view.lifetime.slice(0, -1);
            var lifetime_suffix = view.lifetime.substring(view.lifetime.length - 1);
            $('#update_lifetime').val(lifetime);
            $('#update_lifetime_suffix').val(lifetime_suffix);
            $('#vid').val(vid);

            $('#update_view').modal('show');
        }, 'json');
    });

    $('.popup_assoc').unbind();
    $('.popup_assoc').click(function() {
        var name = $(this).data('name');
        var vid = $(this).data('vid');
        $('#vid').val(vid);
        $('#assoc_view_name').val(name);
        $('#assoc_view').modal('show');

        load_view_assoc_unassoc(vid);
    });

    $('.delete_view').unbind();
    $('.delete_view').click(function() {
        var name = $(this).data('name');
        var vid = $(this).data('vid');
        var conf = confirm("<?php echo lang('view_source_delete_okay'); ?>");
        if (conf === true) {
            $.post(site_url + 'api/views/read_source_associations', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.length > 0) { 
                    var text = "<?php echo lang('view_source_delete_perm1'); ?>: " + name + "\n<?php echo lang('view_source_delete_perm2'); ?>:\n\n";
                    $.each(data, function(key, value) {
                        text += value.name + "\n";
                    });
                    var conf2 = confirm(text);
                    if (conf2) {
                        remove_all_associations_and_delete(vid);
                    }
                } else {
                    delete_view(vid);
                }
            });
        }
    });
    <?php } ?>

    $('.tbl-chk-input').unbind();
    $('.tbl-chk-input').change(function() {
        var view_ids = $('input:checkbox[name=views]:checked').map(function(_, el) {
            return $(el).val();
        }).get();

        if (view_ids.length >= 1) {
            $('#delete_multi_views_btn').attr('disabled', false);
        } else {
            $('#delete_multi_views_btn').attr('disabled', true);
        }
    });
}

function remove_all_associations_and_delete(vid)
{
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(data) {
        var sids = [];
        $.each(data, function(key, value) {
            sids.push(value.sid);
        })
         $.post(site_url + 'api/views/delete_source_associations', { 'q[vid]': vid, 'q[sid]': sids, <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != "success") {
                alert(data.error);
            } else {
                delete_view(vid);
            }
         });
    });
}

function delete_view(vid)
{
    $.post(site_url + 'api/views/delete', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
        if (data.status != "success") {
            alert(data.error);
        }
        load_views_list();
    });
}

function load_view_assoc_unassoc(vid)
{
    var s = [];
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(all_sources) {
        $.post(site_url + 'api/views/read_source_associations', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(sources) {
            
            // Clear the fields
            $('#assoc_sourcelist').html('');
            $('#sourcelist').html('');

            // Add associated sources to list
            $.each(sources, function(key, source) {
                $('#assoc_sourcelist').append('<option value="' + source.sid + '">' + source.name + '</option>');
            });

            $.each(all_sources, function(key, source) {
                var x = true;
                 $.each(sources, function(key2, s2) {
                    if (s2.sid == source.sid) {
                        x = false;
                    }
                });
                if (x) { s.push(source); }
            });

            // Add unassociated sources to list
            $.each(s, function(key, source) {
                $('#sourcelist').append('<option value="' + source.sid + '">' + source.name + '</option>');
            });
        });
    });
}

function load_assoc_list()
{
    $('.assoc-list').each(function() {
        var list = '';
        var vid = $(this).data('vid');
        var name = $(this).data('name');
        var td = $(this);
        $.post(site_url + 'api/views/read_source_associations', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.length > 0) {
                var i = 0;
                $.each(data, function(key, value) {
                    if (i < 5) {
                        list += value.name;
                        i++;
                        if (i < data.length) { list += ', '; }
                    }
                });
                if (data.length > 5) {
                    list += ' (' + (data.length - 5) + ' More)';
                }
                list += ' (<a href="#" class="popup_assoc" data-vid="' + vid + '" data-name="' + name + '"><?php echo lang("change"); ?></a>)';
                td.html(list);
            } else {    
                td.html('None (<a href="#" class="popup_assoc" data-vid="' + vid + '" data-name="' + name + '"><?php echo lang("add"); ?></a>)');
            }
            bind_buttons();
        }, 'json');
    });
}

function load_views_list()
{
    var table;
    $.post(site_url + 'api/views/read', { 's[name]': $('#view_search_input').val(), <?php echo get_csrf_block(); ?> }, function(views) {
        VIEWS_LIST = views;
        if (VIEWS_LIST.length > 0) {
            $.each(VIEWS_LIST, function(key, view) {
                table += '<tr><td><label class="checkbox tbl-checkbox"><input type="checkbox" name="views" class="tbl-chk-input" value="' + view.vid + '"></label></td>';
                table += '<td>' + view.name + '</td>';
                table += '<td class="assoc-list" data-vid="' + view.vid + '" data-name="' + view.name + '"></td>';
                table += '<td>' + human_readable_lifetime(view.lifetime) + '</td>';
                <?php if ($is_admin) { ?>
                table += '<td><a href="#" data-vid="' + view.vid + '" class="view_view"><?php echo lang("edit"); ?></a> &bull; <a href="#" data-vid="' + view.vid + '" data-name="' + view.name + '" class="delete_view"><?php echo lang("delete"); ?></a></td></tr>';
                <?php } ?>
            });
        } else {
            table += '<tr><td colspan="5">No saved views currently exist.</td></tr>';
        }
        $('#table-body').html(table);
        load_assoc_list();
    }, 'json');
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('header_tab_views'); ?></h2>
            <p><?php echo lang('view_home_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 15px;">
        <div class="span6">
            <?php if ($is_admin) { ?>
            <button type="button" class="btn" id="delete_multi_views_btn" disabled><i class="icon-trash"></i> <?php echo lang('delete'); ?></button>
            <a href="#create_view" class="btn" role="button" data-toggle="modal"><i class="icon-file"></i> <?php echo lang('view_home_create'); ?></a>
            <?php } ?>
        </div>
        <div class="span6" style="text-align: right;">
            <div class="form-horizontal">
            <input type="text" id="view_search_input" placeholder="<?php echo lang('view_home_search_placeholder'); ?>"></input> <button id="view_search" class="btn"><i class="icon-search"></i></button>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <div>
                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th style="width: 16px; text-align: center;"><i class="icon-plus-sign select_all" style="cursor: pointer;" title="Select All" data-for-name="views"></i></th>
                            <th style="width: 30%;"><?php echo lang('view_home_th_name'); ?></th>
                            <th><?php echo lang('view_home_th_assoc'); ?></th>
                            <th style="Width: 120px;"><?php echo lang('view_home_th_lifetime'); ?></th>
                            <?php if ($is_admin) { ?>
                            <th style="width: 100px;"><?php echo lang('view_home_th_actions'); ?></th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($is_admin) { ?>
<!-- Create View -->
<div id="create_view" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang('create_view_modal_header'); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('create_view_modal_text1'); ?> (<a href="#" class="po_bind" data-toggle="popover" data-placement="bottom" data-content="<?php echo lang('create_view_modal_popup_text'); ?>" title="<?php echo lang('create_view_modal_popup_title'); ?>"><?php echo lang('create_view_modal_explain'); ?></a>) <?php echo lang('create_view_modal_text2'); ?></p>
        <div class="hide alert alert-error" id="create_view_error"></div>
        <table style="margin: 30px 0;">
            <tr>
                <td class="form-left" style="width: 120px;"><?php echo lang('create_view_modal_name'); ?>:</td>
                <td><input type="text" id="view_name" class="input-xlarge"></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('create_view_modal_limiter'); ?>:</td>
                <td><input type="text" id="limiter" placeholder="ip 192.168.0.1"> <i class="icon-question-sign tt_bind" title="<?php echo lang('create_view_modal_source'); ?>"></i></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('create_view_modal_lifetime'); ?>:</td>
                <td>
                    <div>
                        <input type="text" id="lifetime" style="margin: 0; width: 20px;" value="24">
                        <select id="lifetime_suffix" style="margin: 0; width: 90px;">
                            <option value="H"><?php echo lang('hours'); ?></option>
                            <option value="d"><?php echo lang('days'); ?></option>
                            <option value="w"><?php echo lang('weeks'); ?></option>
                        </select>
                    </div>
                </td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="create_view_btn" class="btn btn-primary"><?php echo lang('create_button'); ?></button>
    </div>
</div>

<!-- View a view modal -->
<div id="update_view" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang("view_update_title"); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang("view_update_desc"); ?></p>
        <div class="hide alert alert-error" id="create_view_error"></div>
        <table>
            <tr>
                <td class="form-left" style="width: 120px;"><?php echo lang('create_view_modal_name'); ?>:</td>
                <td><input type="text" id="update_view_name" class="input-xlarge"></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('create_view_modal_limiter'); ?>:</td>
                <td><input type="text" id="update_limiter" placeholder="ip 192.168.0.1"> <i class="icon-question-sign tt_bind" title="<?php echo lang('create_view_modal_source'); ?>"></i></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('create_view_modal_lifetime'); ?>:</td>
                <td>
                    <div>
                        <input type="text" id="update_lifetime" style="margin: 0; width: 20px;" value="0">
                        <select id="update_lifetime_suffix" style="margin: 0; width: 90px;">
                            <option value="H"><?php echo lang('hours'); ?></option>
                            <option value="d"><?php echo lang('days'); ?></option>
                            <option value="w"><?php echo lang('weeks'); ?></option>
                        </select>
                    </div>
                </td>
            </tr>
        </table>
        <input type="hidden" value="0" id="vid">
    </div>
    <div class="modal-footer">
        <button type="button" class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="update_view_btn" class="btn btn-primary"><?php echo lang('update_button'); ?></button>
    </div>
</div>

<!-- View Assoication Modal -->
<div id="assoc_view" class="modal hide fade" style="min-width: 650px;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang('view_home_modal_assoc_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('view_home_modal_assoc_desc'); ?></p>
        <div class="hide alert alert-error" id="assoc_view_error"></div>
        <div class="hide alert alert-success" id="assoc_view_message"></div>
        <table>
            <tr>
                <td class="form-left"><?php echo lang('view_home_modal_view'); ?>:</td>
                <td><input type="text" id="assoc_view_name" class="input-xlarge" disabled></td>
            </tr>
            <tr>
                <td class="form-left"> </td>
                <td>
                    <div style="float: left;">
                        <div style="font-weight:bold;"><?php echo lang('view_home_modal_unassoc'); ?></div>
                        <select size="8" multiple id="sourcelist">
                        </select>
                    </div>
                    <div style="float: left; padding: 20px 10px 10px 10px;">
                        <button type="button" class="btn btn-small" title="<?php echo lang('view_home_modal_assoc_btn_title'); ?>" style="display: block; margin-bottom: 10px;" id="add_assoc_button"><i class="icon-arrow-right"></i></button>
                        <button type="button" class="btn btn-small btn-danger" title="<?php echo lang('view_home_modal_unassoc_btn_title'); ?>" style="display: block;" id="remove_assoc_button"><i class="icon-arrow-left icon-white"></i></button>
                    </div>
                    <div style="float: left;">
                        <div style="font-weight:bold;"><?php echo lang('view_home_modal_assoc'); ?></div>
                        <select size="8" multiple id="assoc_sourcelist">
                        </select>
                    </div>
                    <div class="clear"></div>
                </td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="vid">
        <button type="button" class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="assoc_view_btn" class="btn btn-primary"><?php echo lang('save_button'); ?></button>
    </div>
</div>
<?php } ?>

<?php echo $footer; ?>