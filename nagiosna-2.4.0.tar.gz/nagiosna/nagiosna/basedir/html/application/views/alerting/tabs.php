    <div class="row-fluid">
        <div class="span8">
            <div style="padding: 10px 0 20px 0;">
                <div style="margin-right: 20px; font-size: 32px; font-weight: bold; line-height: 28px; float: left;"><?php echo lang('header_tab_alerting'); ?></div>
                <div style="clear: both;"></div>
            </div>
        </div>
        <div class="span4" style="text-align: right; line-height: 60px;">
            <div id="status">
                <!-- Dynamic source status area -->
            </div>
        </div>
    </div>
    <p><?php echo $lang['alert_tab_desc'] ?></p>
    <div class="row-fluid">
        <div class="span12">
            <ul class="nav nav-tabs" style="margin-bottom: 0;">
                <?php if ($tab == 'checks') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('alerting/'); ?>"><i class="icon-bell"></i> <?php echo lang('alert_tab_checks'); ?></a></li>
                <?php if ($tab == 'servers') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('alerting/servers'); ?>"><i class="icon-hdd"></i> <?php echo lang('alert_tab_nagios'); ?></a></li>
                <?php if ($tab == 'snmp') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('alerting/snmp'); ?>"><i class="icon-certificate"></i> <?php echo lang('alert_tab_snmp'); ?></a></li>
                <?php if ($tab == 'commands') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('alerting/commands'); ?>"><i class="icon-tasks"></i> <?php echo lang('alert_tab_commands'); ?></a></li>
            </ul>
        </div>
    </div>
