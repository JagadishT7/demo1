<?php echo $header; ?>

<script>

EDIT_MODE = false;
group = 0;

/***********************************************************************
 *
 * VALIDATION FUNCTIONS
 *
 **********************************************************************/

function validate_step_2()
{
    var valid = true;
    var nagios_api = site_url + 'api/system/validate_nagios_range'
    var metric_type = $('#metric-select').val();
    var warning = $('#warning').val();
    var critical = $('#critical').val();
    var cdone = false;
    var wdone = false;
    
    var range = /^@?(\d*|~):?\d*$/;
    
    $('#step2-error-p').html('');


    // If this specific abnormal behavior validation succeeds, the rest is irrelevant
    if (metric_type === "abnormal_behavior") {
        var source_or_group = $('input[name=sourcetype]:checked').val();
        var is_view = parseInt($('#view-select').val());

        if (source_or_group === 'sourcegroup' || is_view) {
            console.log('we\'re supposed to have a problem now');
            $('<p>', {"text": '<?php echo lang("alert_check_abnormal_behavior"); ?>'}).appendTo('#step2-error-p');
            valid = false;
            $('#step2-error-container').show();
            $('#metric-select').parent().parent().addClass('error');
        }
        return valid;
    }

    // Validate the warning range, do not raise if there is no warning
    if(warning) {
        if(!range.test(warning)) {
            $('<p>', {"text": '<?php echo lang("alert_check_valid_warning"); ?>'}).appendTo('#step2-error-p');
            valid = false;
            $('#step2-error-container').show();
            $('#warning').parent().parent().addClass('error');
        } else {
            $('#warning').parent().parent().removeClass('error');
        }
    } else {
        $('#warning').parent().parent().removeClass('error');
    }
    
    // Validate the critical range, do not raise if there is no critical
    if(critical) {
        if(!range.test(warning)) {
            $('<p>', {"text": '<?php echo lang("alert_check_valid_critical"); ?>'}).appendTo('#step2-error-p');
            valid = false;
            $('#step2-error-container').show();
            $('#critical').parent().parent().addClass('error');
        } else {
            $('#critical').parent().parent().removeClass('error');
        }
    } else {
        $('#critical').parent().parent().removeClass('error');
    }
    
    // Validate all input fields. There is currently no support for validating
    // IP address/ports.
    $('#form-checks-step2 input').each(function(i) {
        var node = $(this);
        
        if(node.attr('id') == 'warning' || node.attr('id') == 'critical') {
            return;
        }
        
        if(!node.val()) {
            //console.log("This was false...");
            valid = false;
            $('<p>', {"text": '<?php echo lang("alert_check_req_fields"); ?>'}).appendTo('#step2-error-p');
            $('#step2-error-container').show();
            node.parent().parent().addClass('error');
        } else {
            node.parent().parent().removeClass('error');
        }
    });
    
    return valid;
}

function validate_step_1()
{
    var valid = true;
    $('#form-checks-step1 input').each(function(i) {
        var node = $(this);
        
        if(!node.val()) {
            valid = false;
            $('#step1-error-p').text('<?php echo lang("alert_check_req_fields"); ?>');
            $('#step1-error-container').show();
            node.parent().parent().addClass('error');
        } else {
            node.parent().parent().removeClass('error');
        }
    });
    return valid;
}

function show_error(msg)
{
    $("#alert-success-container").hide();
    $("#alert-error-div").html(msg);
    $("#alert-error-container").show();
}

function show_info(msg)
{
    $("#alert-error-container").hide();
    $("#alert-success-div").html(msg);
    $("#alert-success-container").show();
}

/***********************************************************************
 *
 * SAVE AND EDIT FUNCTIONS
 *
 **********************************************************************/

function save_check()
{
    var check_url = site_url + 'api/checks/create';
    var check_read = site_url + 'api/checks/read';
    var check_obj = {};
    
    if(EDIT_MODE == true) {
        var prefix = 'u';
        check_obj['q[cid]'] = EDIT_CID;
        check_url = site_url + 'api/checks/update';
    } else {
        var prefix = 'q';
    }
    
    // Set up the values we are going to look for
    var type = $('input:radio[name=sourcetype]:checked').val();
    var name = $('#name').val();
    var sid = $('#source-select').val();
    var gid = $('#sourcegroup-select').val();
    var vid = $('#view-select').val();
    var metric = $('#metric-select').val();

    if (metric !== 'abnormal_behavior') {
        var rawquery = process_query();
        var warning = $('#warning').val();
        var critical = $('#critical').val();
    }

    // Association Information
    var users = $('#userlist').val();
    var nagios = $('#nagioslist').val();
    var snmp = $('#snmplist').val();
    var cmd = $('#cmdlist').val();
    
    // Make the check
    if(!EDIT_MODE) {
        check_obj[prefix + '[name]'] = name;
    }
    check_obj[prefix + '[rawquery]'] = rawquery;
    check_obj[prefix + '[metric]'] = metric;
    if(warning) {
        check_obj[prefix + '[warning]'] = warning;
    }
    if(critical) {
        check_obj[prefix + '[critical]'] = critical;
    }
    if(type == 'source') {
        check_obj[prefix + '[sid]'] = sid;
        if(vid != 0 && vid != '0') {
            check_obj[prefix + '[vid]'] = vid;
        }
    }
    if(type == 'sourcegroup') {
        check_obj[prefix + '[gid]'] = gid;
    }
    
    //console.log(check_obj);
    
    $.getJSON(check_url, check_obj, function(data) {
        if(data.error) {
            alert(data.error);
        }
        else {
            $.getJSON(check_read, {'q[name]': name}, function(check) {
                var c = check[0];
                associate_users(c.cid, users);
                associate_nagios(c.cid, nagios);
                associate_snmp(c.cid, snmp);
                associate_cmd(c.cid, cmd);
            });
            EDIT_MODE = false;
            EDIT_CID = 0;
            $('#checks-step3').modal('hide');
            refresh_check_table();
        }
    });
}

function delete_check(cid)
{
    var api_url = site_url + 'api/checks/delete';
    
    $.getJSON(api_url, {'q[cid]': cid}, function(data) {
        if(data.error) {
            show_error(data.error);
        } else {
            show_info('<?php echo lang("alert_check_deleted"); ?>');
        }
    });
}

function reset_tabs()
{
    $('#reset-notif').trigger('click');
}

function edit_check(cid)
{
    var api_url = site_url + 'api/checks/read';
    EDIT_MODE = true;
    EDIT_CID = cid;
    reset_tabs();
    
    $('.limiting-group').remove();
    group = 0;
    
    $.getJSON(api_url, {'q[cid]': cid}, function(data) {
        var c = data[0];
        
        load_available_sources(c.sid, c.vid);
        load_available_sourcegroups(c.gid);
        populate_user_list(cid);
        populate_server_list(cid);
        populate_snmp_list(cid);
        populate_cmd_list(cid);
        
        $('#name').attr('disabled', 'disabled');
        
        // Step 1
        $('#name').val(c.name);
        if(c.sid) {
            show_sources();
        } else {
            show_sourcegroups();
        }
        
        
        // Step 2
        $('#warning').val(c.warning);
        $('#critical').val(c.critical);
        $('#metric-select').val(c.metric);
        parse_query(c.rawquery);

        abnormal_behavior_changes(c.metric);

        $('#checks-step1').modal('show');
    });
}

function associate_users(cid, userlist)
{
    var assoc_users_url = site_url + 'api/checks/associate_with_user';
    var unassoc_users_url = site_url + 'api/checks/unassociate_with_user';
    
    var user_obj = {'q[cid]': cid};
    
    $.getJSON(unassoc_users_url, user_obj, function(data) {
        if(data.error) {
            alert(data.error);
        } else {
            if (userlist) {
                user_obj['q[uid]'] = userlist;
                $.getJSON(assoc_users_url, user_obj, function(data) {
                    if(data.error) {
                        alert(data.error);
                    }
                });
            }
        }
    });
}

function associate_nagios(cid, nagioslist)
{
    var assoc_nagios_url = site_url + 'api/checks/associate_with_hostservice';
    var unassoc_nagios_url = site_url + 'api/checks/unassociate_with_hostservice';
    
    var nagios_obj = {'q[cid]': cid};
    
    $.getJSON(unassoc_nagios_url, nagios_obj, function(data) {
        if(data.error) {
            alert(data.error);
        } else {
            if (nagioslist) {
                nagios_obj['q[aid]'] = nagioslist;
                $.getJSON(assoc_nagios_url, nagios_obj, function(data) {
                    if(data.error) {
                        alert(data.error);
                    }
                });
            }
        }
    });
}

function associate_snmp(cid, snmplist)
{
    var assoc_snmp_url = site_url + 'api/checks/associate_with_trapreceiver';
    var unassoc_snmp_url = site_url + 'api/checks/unassociate_with_trapreceiver';
    
    var snmp_obj = {'q[cid]': cid};
    
    $.getJSON(unassoc_snmp_url, snmp_obj, function(data) {
        if (data.error) {
            alert(data.error);
        } else {
            if (snmplist) {
                snmp_obj['q[tid]'] = snmplist;
                $.getJSON(assoc_snmp_url, snmp_obj, function(data) {
                    if(data.error) {
                        alert(data.error);
                    }
                });
            }
        }
    });
}

function associate_cmd(cid, cmdlist)
{
    var assoc_cmd_url = site_url + 'api/checks/associate_with_cmd';
    var unassoc_cmd_url = site_url + 'api/checks/unassociate_with_cmd';

    var cmd_obj = { 'q[cid]': cid };
    
    $.getJSON(unassoc_cmd_url, cmd_obj, function(data) {
        if (data.error) {
            alert(data.error);
        } else {
            if (cmdlist) {
                cmd_obj['q[cmdid]'] = cmdlist;
                $.getJSON(assoc_cmd_url, cmd_obj, function(data) {
                    if (data.error) {
                        alert(data.error);
                    }
                });
            }
        }
    });
}

function process_query()
{
    var query = $('#form-checks-step2').serializeArray();
    var target;
    var type;
    var negate;
    var limiter;
    var queryr = [];
    
    for(var i=0, l=query.length; i<l; i+=4) {
        var q = '';
        
        target = query[i].value;
        type = query[i+1].value;
        negate = query[i+2].value;
        limiter = query[i+3].value;
        
        if(negate == 'not') {
            q += 'not ';
        }
        
        if(target != 'either') {
            q += target + ' ';
        }
        q += type + ' ';
        q += limiter;
        
        queryr.push(q);
    }
    
    return queryr.join(' and ');
}

function parse_query(query)
{
    var qlat = query.split(' and ');
    for(var i=0, l=qlat.length; i<l; i++) {
        var slat = qlat[i].split(' ');
        var negate;
        var direction;
        var item;
        var limit;
        
        if(slat[0] == 'not') {
            negate = true;
            slat.shift();
        }
        
        if(slat.length == 3) {
            direction = slat[0];
            item = slat[1];
            limit = slat[2];
        } else {
            direction = 'either';
            item = slat[0];
            limit = slat[1];
        }
        
        add_limiting_group(direction, item, limit, negate);
    }
}

// Clear the values from the last check. Runs when the 'New Check' button
// is triggered on click.
function clear_check_input()
{
    reset_tabs();
    $('.limiting-group').remove();
    group = 0;
    add_limiting_group();
    $('#name').val('').attr('disabled', false);
    $('#warning').val('');
    $('#critical').val('');
    $('#metric-select').val('bytes');
    load_available_sources();
    load_available_sourcegroups();
    populate_view_select();

    // Reset abnormal behavior selection
    $('#warning').prop('disabled', false);
    $('#critical').prop('disabled', false);
    $('.limiting-group').removeClass('hide');
    $('#and').removeClass('hide');

    $('#make_source').trigger('click');
}



/***********************************************************************
 * 
 * POPULATION FUNCTIONS
 *
 * These populate lists via AJAX
 *
 **********************************************************************/

function populate_view_select(vid)
{
    var sid = $('#source-select').val();
    var api_url = site_url + 'api/views/get_views';
    var vselect = $('#view-select');
    vselect.html('');
    
    $('<option>', {"value": 0, "text": "<?php echo lang('no_view'); ?>", "selected": "selected"}).appendTo(vselect);
    
    $.getJSON(api_url, {'q[sid]': sid}, function(data) {
        $.each(data, function(i, d) {
            var vopt = $('<option>', {"value": d.vid, "text": d.name});
            
            if(vid && vid == d.vid) {
                vopt.attr('selected', 'selected');
            }
            
            vopt.appendTo(vselect)
        });
    });
}

function populate_snmp_list(cid)
{
    var api_url = site_url + 'api/trapreceivers/read';
    $('#snmplist').html('');
    
    $.getJSON(api_url, function(data) {
        $.each(data, function(i, d) {
            $('<option>', {"value": d.tid, "text": d.name}).appendTo('#snmplist');
        });

        // Select the SNMP traps
        var trap_url = site_url + 'api/checks/read_trapreceiver_associations';
        $.getJSON(trap_url, {'q[cid]': cid}, function(data) {
            if (!data.error) {
                var snmplist = data.map(function(o) { return parseInt(o.tid); });
                $.each(snmplist, function(i, e) {
                    $('#snmplist option[value="' + e + '"]').attr("selected", true);
                });
            }
        });
    });
}

function populate_cmd_list(cid)
{
    var api_url = site_url + 'api/system/get_commands';
    $('#cmdlist').html('');

    $.post(api_url, { <?php echo get_csrf_block(); ?> }, function(data) {
        $.each(data, function(v, k) {
            $('<option>', { "value": k.id, "text": k.name }).appendTo('#cmdlist');
        });

        // Select the commands
        var cmd_url = site_url + 'api/checks/read_cmd_associations';
        $.getJSON(cmd_url, { 'q[cid]': cid, <?php echo get_csrf_block(); ?> }, function(data) {
            if (!data.error) {
                var cmdlist = data.map(function(o) { return parseInt(o.cmdid); });
                $.each(cmdlist, function(i, e) {
                    $('#cmdlist option[value="' + e + '"]').attr("selected", true);
                });
            }
        });
    }, 'json');
}

function populate_user_list(cid)
{
    var api_url = site_url + 'api/system/get_users';
    $('#userlist').html('');
    
    $.getJSON(api_url, { }, function(data) {
        $.each(data, function(i, d) {
            $('<option>', {"value": d.id, "text": d.username}).appendTo('#userlist');
        });

        // Select the users
        var user_url = site_url + 'api/checks/read_user_associations';
        $.getJSON(user_url, { 'q[cid]': cid }, function(data) {
            if (!data.error) {
                var userlist = data.map(function(o) { return parseInt(o.uid); });
                $.each(userlist, function(i, e) {
                    $('#userlist option[value="' + e + '"]').attr("selected", true);
                });
            }
        });
    });
}

function populate_server_list(cid)
{
    var api_url = site_url + 'api/hostservices/read';
    var sev_url = site_url + 'api/nagiosservers/read';
    $('#nagioslist').html('');
    
    $.getJSON(api_url, function(data) {
        $.each(data, function(i, d) {
            $.ajax({
                url: sev_url,
                async: false,
                data: {'q[id]': d.serverid},
                success: function(info) {
                    var serverinfo = info[0];
                    var text = d.hostname + "/" + d.servicename + " on " + serverinfo.name;
                    $('<option>', {"value": d.id, "text": text}).appendTo('#nagioslist');
                }
            });
        });

        // Select the selected Nagios Servers
        var nagios_url = site_url + 'api/checks/read_hostservice_associations';
        $.getJSON(nagios_url, {'q[cid]': cid}, function(data) {
            if (!data.error) {
                var nagioslist = data.map(function(o) { return parseInt(o.aid); });
                $.each(nagioslist, function(i, e) {
                    $('#nagioslist option[value="' + e + '"]').attr("selected", true);
                });
            }
        });
    });
}

function load_available_sources(sid, vid)
{
    $.getJSON(site_url + 'api/sources/read', { 'o[col]':'name', 'o[sort]':'ASC' }, function(data) {
        $('#source-select').html('');
        $.each(data, function(index, d) {
            var option = $('<option>', {'value': d.sid, 'text': d.name });
            if(sid && d.sid == sid) {
                option.attr('selected', 'selected');
            }
            $('#source-select').append(option);
        });
        if(vid) {
            populate_view_select(vid);
        }
    });
}

function load_available_sourcegroups(gid)
{
    $.getJSON(site_url + 'api/groups/read', function(data) {
        var group_select = $('#sourcegroup-select');
        group_select.html('');
        $.each(data, function(index, d) {
            var option = $('<option>', {'value': d.gid, 'text': d.name});
            
            if(gid && gid == d.gid) {
                option.attr('selected', 'selected');
            }
            
            option.appendTo(group_select);
        });
    });
}

function refresh_check_table()
{
    $('#check-table-body').html('');
    
    $.getJSON(site_url + 'api/checks/read', { 'o[col]':'name', 'o[sort]':'ASC' }, function(data) {
        if(data.length == 0) {
            var empty = $('<tr><td colspan="6"><?php echo lang("alert_check_not_created"); ?></td></tr>');
            $('#check-table-body').html(empty);
        }
        else {
            $.each(data, function(index, d) {

                //console.log(d);

                var tr = $('<tr>');
                $('<td>', {"text": d.name}).appendTo(tr);
                
                // Display what the check is associated with
                $('<td>', {"text":d.assoc_with}).appendTo(tr);

                var status;
                var status_class;
                switch(d.lastcode) {
                    case "0":
                        status = "<?php echo lang('ok'); ?>";
                        status_class = 'OK';
                        break;
                    case "1":
                        status = "<?php echo lang('warning'); ?>";
                        status_class = 'WARNING';
                        break;
                    case "2":
                        status = "<?php echo lang('critical'); ?>";
                        status_class = 'CRITICAL';
                        break;
                    default:
                        if (d.lastrun == "0000-00-00 00:00:00") {
                            status = "<?php echo lang('pending'); ?>";
                            status_class = 'PENDING';
                        } else {
                            status = "<?php echo lang('unknown'); ?>";
                            status_class = 'UNKNOWN';
                        }
                        break;
                }

                $('<td>', {"text": status, "class": status_class, "style": 'width: 120px;'}).appendTo(tr);

                if (d.lastrun == "0000-00-00 00:00:00") {
                    $('<td>', {"text": "N/A"}).appendTo(tr);
                } else {
                    $('<td>', {"text": d.lastrun, "style": 'width: 120px;'}).appendTo(tr);
                }

                if (d.lastrun == "0000-00-00 00:00:00") {
                    $('<td>', {"text": ""}).appendTo(tr);
                } else {
                    $('<td>', {"text": d.laststdout}).appendTo(tr);
                }

                var actions = $('<td>');
                var vedit = $('<a>', {"text": "<?php echo lang('view_edit'); ?>"});
                var del = $('<a>', {"text": "<?php echo lang('delete'); ?>"});
                
                vedit.click(function() { edit_check(d.cid); });
                del.click(function() { delete_check(d.cid); refresh_check_table(); })
                
                vedit.appendTo(actions);
                $('<span>', {"text": ' • '}).appendTo(actions);
                del.appendTo(actions);
                actions.appendTo(tr);
                
                $('#check-table-body').append(tr);
            });
        }
    });
}

function add_limiting_group(direction, item, limit, negate)
{
    var group_div = $('<div>', {'class': 'well limiting-group'})
    
    if(group != 0) {
        var button = $('<button>', {'class': 'close'});
        button.html('&times;');
        group_div.append(button);
        button.click(function() { $(group_div).remove() });
        $('<p>', {'class': 'muted',  'text': '<?php echo lang("and"); ?>'}).appendTo(group_div)
    }
    
    var type_div = $('<div>', {'class': 'form-horizontal'});
    var type_cg = $('<div>', {'class': 'control-group'});
    var type_label = $('<label>', {  'class': 'control-label', 
                                        'for': 'target-select',
                                        'text': '<?php echo lang("where_the"); ?>:' })
    var type_ctl = $('<div>', {'class': 'controls'});
    var target_select = $('<select>', {'name': 'target-select[]'});
    var dtarg = $('<option>', {'value': 'dst', 'text': '<?php echo lang("destination"); ?>'})
    var starg = $('<option>', {'value': 'src', 'text': '<?php echo lang("source"); ?>'})
    var etarg = $('<option>', {'value': 'either', 'text': '<?php echo lang("either"); ?>'})
    
    switch(direction) {
        case 'dst':
            dtarg.attr('selected', 'selected');
            break;
        case 'src':
            starg.attr('selected', 'selected');
            break;
        case 'either':
            etarg.attr('selected', 'selected');
            break;
        default:
            break;
    }
    
    dtarg.appendTo(target_select);
    starg.appendTo(target_select);
    etarg.appendTo(target_select);
    
    var type_select = $('<select>', {'class': 'type-selector', 'name': 'type-select[]'});
    var ptype = $('<option>', {'value': 'port', 'text': '<?php echo lang("port"); ?>'});
    var itype = $('<option>', {'value': 'ip', 'text': '<?php echo lang("ip"); ?>'});
    var ntype = $('<option>', {'value': 'net', 'text': '<?php echo lang("network"); ?>'});
    
    switch(item) {
        case 'port':
            ptype.attr('selected', 'selected');
            break;
        case 'ip':
            itype.attr('selected', 'selected');
            break;
        case 'net':
            ntype.attr('selected', 'selected');
            break;
        default:
            break;
    }
    
    ptype.appendTo(type_select);
    itype.appendTo(type_select);
    ntype.appendTo(type_select);
    
    target_select.appendTo(type_ctl);
    type_select.appendTo(type_ctl);
    type_label.appendTo(type_cg);
    type_ctl.appendTo(type_cg);
    type_cg.appendTo(type_div);
    
    type_div.appendTo(group_div);
    
    var limit_div = $('<div>', {'class': 'form-horizontal'});
    
    var is_isnot_ctl_grp = $('<div>', {'class': 'control-group'});
    var is_ctl = $('<div>', {'class': 'controls'});
    var is_chk = $('<label>', {'class': 'radio', 'text': '<?php echo lang("is"); ?>'})
    if (negate == false || negate == undefined) {
        $('<input>', {  'type': 'radio', 
                        'name': 'negate-' + group + '[]', 
                        'value': '<?php echo lang("is"); ?>',
                        'checked': 'checked' }).appendTo(is_chk);
    } else {
        $('<input>', {  'type': 'radio', 
                        'name': 'negate-' + group + '[]', 
                        'value': '<?php echo lang("is"); ?>' }).appendTo(is_chk);
    }
    is_chk.appendTo(is_ctl);
    is_ctl.appendTo(is_isnot_ctl_grp);
    
    var not_ctl = $('<div>', {'class': 'controls'});
    var not_chk = $('<label>', {'class': 'radio', 'text': '<?php echo lang("is_not"); ?>'});
    if(negate == true) {
        $('<input>', {'type': 'radio', 'name': 'negate-' + group + '[]', 'value': 'not', 'checked': 'checked'}).appendTo(not_chk);
    } else {
        $('<input>', {'type': 'radio', 'name': 'negate-' + group + '[]', 'value': 'not'}).appendTo(not_chk);
    }
    not_chk.appendTo(not_ctl);
    not_ctl.appendTo(is_isnot_ctl_grp);

    is_isnot_ctl_grp.appendTo(limit_div);
    
    var limit_ctl_grp = $('<div>', { 'class': 'control-group end' });
    $('<label>', {'class': 'control-label', 'for': 'limiter-text[]', 'text': '(<?php echo lang("required"); ?>)'}).appendTo(limit_ctl_grp);
    var limit_ctl = $('<div>', {'class': 'controls'});
    if (limit) {
        var limit_input = $('<input>', {'type': 'text', 
                                        'class': 'input',                              
                                        'name': 'limiter-text[]',
                                        'required': 'required',
                                        'value': limit})
    } else {
        var limit_input = $('<input>', {'type': 'text', 
                                        'class': 'input',                              
                                        'name': 'limiter-text[]',
                                        'required': 'required',
                                        'placeholder': '5667' })
    }
    limit_input.appendTo(limit_ctl);
    limit_ctl.appendTo(limit_ctl_grp);
    limit_ctl_grp.appendTo(limit_div);
    
    limit_div.appendTo(group_div);
    
    $('#and-button').before(group_div);
    
    type_select.change(function() {
        var new_val = $(this).val();
        switch(new_val) {
            case 'port':
                limit_input.attr('placeholder', '80');
                break;
            case 'ip':
                limit_input.attr('placeholder', '192.168.1.1');
                break;
            case 'net':
                limit_input.attr('placeholder', '192.168.5.0/24');
                break;
            default:
                break;
        }
    });
    
    group++;
}
/* End the population functions */

$(document).ready(function() {
    
    // Load check table
    refresh_check_table();
    
    // Checks Transition functions
    $('.checks-goto1').click(function() {
        $('.modal').modal('hide');
        $('#checks-step1').modal('show');
    });
    
    $('.checks-goto2').click(function() {
        var valid;
        valid = validate_step_1();
        if(valid) {
            $('.modal').modal('hide');
            $('#checks-step2').modal('show');
            $('#step1-error-container').hide();
        }
    });
    
    $('.checks-goto3').click(function() {
        var valid;
        valid = validate_step_2();
        if(valid) {
            $('.modal').modal('hide');
            $('#checks-step3').modal('show');
            $('#step2-error-container').hide();
        }
    });
    
    $('#and').click(function() {
        add_limiting_group();
    });
    
    $('#new-check').click(function() {
        add_limiting_group();
        load_available_sources();
        load_available_sourcegroups();
        clear_check_input();
        populate_user_list();
        populate_server_list();
        populate_snmp_list();
        populate_cmd_list();
        $('#step2-error-container').hide();
        $('#step1-error-container').hide();
    });
    
    $('#checks-finishsave').click(function() {
        save_check();
    });
    
    $('#make_source').click(function() {
        show_sources();
    });
    
    $('#make_sourcegroup').click(function() {
        show_sourcegroups();
    });
    
    $('#source-select').change(function() {
        populate_view_select();
    });

    $('#metric-select').change(function() {
        abnormal_behavior_changes($(this).val());
    });

    $('#make_source').trigger('click');
    $('#source-select').trigger('change');

    setInterval(refresh_check_table, 300000);
});

function abnormal_behavior_changes(selected)
{
    $('#warning').prop('disabled', false);
    $('#critical').prop('disabled', false);
    $('.limiting-group').removeClass('hide');
    $('#and').removeClass('hide');

    if ($('#warning').val() === 'N/A') {
        $('#warning').val('');
    }
    if ($('#critical').val() === 'N/A') {
        $('#critical').val('');
    }

    if (selected === 'abnormal_behavior') {
        $('#warning').prop('disabled', true);
        $('#warning').val('N/A');
        $('#critical').prop('disabled', true);
        $('#critical').val('N/A');
        $('.limiting-group').addClass('hide');
        $('#and').addClass('hide');
    }

}

function show_sourcegroups()
{
    $('#source-selector-div').hide();
    $('#sourcegroup-selector-div').show();
}

function show_sources() 
{
    $('#sourcegroup-selector-div').hide();
    $('#source-selector-div').show();
}

</script>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('alerting'); ?>"><?php echo lang('header_tab_alerting'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_checks'); ?></li>
</ul>

<div class="container">
    <?php echo $tabs; ?>

    <div class="row-fluid" style="margin: 20px 0;">
        <div class="span6">
            <a href="#" id='new-check' data-target='#checks-step1' data-toggle='modal' class="btn"><i class="icon-plus"></i> <?php echo lang('alert_check_new_button'); ?></a>
        </div>
    </div>

    <div id="alert-error-container" class="alert alert-error hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-error-div"></div>
    </div>
    
    <div id="alert-success-container" class="alert alert-success hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-success-div"></div>
    </div>

    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th><?php echo lang('alert_check_th_name'); ?></th>
                <th><?php echo lang('alert_check_th_assoc'); ?></th>
                <th><?php echo lang('alert_check_th_status'); ?></th>
                <th><?php echo lang('alert_check_th_last'); ?></th>
                <th><?php echo lang('alert_check_th_stdout'); ?></th>
                <th><?php echo lang('alert_check_th_actions'); ?></th>
            </tr>
        </thead>
        <tbody id="check-table-body"></tbody>
    </table>

</div>

<!--
CHECK ADDITIONS
-->

<!--
STEP 1
-->
<form name="form-checks-step1" id="form-checks-step1">
    <div id='checks-step1' class="modal hide fade">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_check_step1_title'); ?></h3>
        </div>
        <div class='modal-body'>
            <div id='step1-error-container' class='alert alert-error' style='display:none;'>
                <button type='button' class='close' data-dismiss='alert'>&times;</button>
                <h4><?php echo lang('alert_check_validation_error'); ?></h4>
                <p id='step1-error-p'></p>
            </div>
            <div class="well" style="margin-bottom: 10px;">
                <div class="control-group end">
                    <label class="control-label" for="name">
                        <?php echo lang('alert_check_step1_name'); ?>
                    </label>
                    <div class="controls">
                        <input type="text" name="name" id="name" required="required" class="input" style="margin: 0;">
                    </div>
                </div>
            </div>
            <div class="control-group inline text-center">
                <label class="radio inline">
                    <input type="radio" name="sourcetype" value="source" id="make_source"><?php echo lang('alert_check_step1_source'); ?>
                </label>
                <label class="radio inline">
                    <input type="radio" name="sourcetype" value="sourcegroup" id="make_sourcegroup"><?php echo lang('alert_check_step1_sg'); ?>
                </label>
            </div>
            <div id="sourcegroup-selector-div" class="well" style="margin: 0;">
                <div class="control-group">
                    <label class="control-label" for="sourcegroup-select"><?php echo lang('alert_check_step1_sg'); ?></label>
                </div>
                <div class="controls">
                    <select id="sourcegroup-select" name="sourcegroup-select"></select>
                </div>
            </div>
            <div id="source-selector-div" class="well" style="margin: 0;">
                <div class="control-group">
                    <label class="control-label" for="source-select"><?php echo lang('alert_check_step1_source'); ?></label>
                </div>
                <div class="controls">
                    <select id="source-select" name="source-select"></select>
                </div>
                <div class="control-group">
                    <label class="control-label" for="view-select"><?php echo lang('alert_check_step1_view'); ?></label>
                </div>
                <div class="controls">
                    <select id="view-select" name="view-select"></select>
                </div>
            </div>
        </div>
        <div class='modal-footer'>
            <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
            <button type='button' class='btn btn-primary checks-goto2'><?php echo lang('alert_check_step1_continue'); ?> <i class="icon-chevron-right icon-white"></i></a>
        </div>
    </div>
</form>
<!--
STEP 2
-->
<form name="form-checks-step2" id="form-checks-step2">
    <div id='checks-step2' class="modal hide fade">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_check_step2_title'); ?></h3>
        </div>
        <div class='modal-body'>
            <div id='step2-error-container' class='alert alert-error' style='display:none;'>
                <button type='button' class='close' data-dismiss='alert'>&times;</button>
                <h4><?php echo lang('alert_check_validation_error'); ?></h4>
                <p id='step2-error-p'></p>
            </div>
            <div class='form-horizontal'>
                <div class='control-group'>
                    <label class="control-label" for="metric-select"><?php echo lang('alert_check_step2_analyze'); ?>:</label>
                    <div class="controls">
                        <select id="metric-select">
                            <option value="bytes"><?php echo lang('bytes'); ?></option>
                            <option value="flows"><?php echo lang('flows'); ?></option>
                            <option value="packets"><?php echo lang('packets'); ?></option>
                            <option value="bps"><?php echo lang('bits_sec'); ?></option>
                            <option value="abnormal_behavior"><?php echo lang('dashboard_aberrant'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            <div class='form-horizontal'>
                <div class='control-group'>
                    <label class="control-label" for="warning"><?php echo lang('alert_check_step2_warning'); ?>:</label>
                    <div class="controls">
                        <input type='text' id='warning'>
                    </div>
                </div>
            </div>
            <div class='form-horizontal'>
                <div class='control-group'>
                    <label class="control-label" for="critical"><?php echo lang('alert_check_step2_critical'); ?>:</label>
                    <div class="controls">
                        <input type='text' id='critical'>
                    </div>
                </div>
            </div>
            <div id="and-button" style="width:100%;">
                <div style="width:60px;margin:0 auto;">
                <a href='#' type="button" class='btn' id="and"><?php echo lang('and'); ?></a>
                </div>
            </div>
        </div>
        <div class='modal-footer'>
            <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
            <a href='#' class='btn checks-goto1'><i class="icon-chevron-left"></i> <?php echo lang('alert_check_step2_backward'); ?></a>
            <a href='#' class='btn btn-primary checks-goto3'><?php echo lang('alert_check_step2_forward'); ?> <i class="icon-chevron-right icon-white"></i></a>
        </div>
    </div>
</form>
<!--
STEP 3
-->
<form name="form-checks-step3" id="form-checks-step3">
    <div id='checks-step3' class="modal hide fade">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_check_step3_title'); ?></h3>
        </div>
        <div class='modal-body'>
            <p><?php echo lang('alert_check_step3_desc'); ?></p>
            <div class="tabbable">
                <ul class="nav nav-tabs" style="margin-bottom: 10px;">
                    <li class="active"><a href="#userdiv" id='reset-notif' data-toggle="tab" style="font-weight: bold;"><?php echo lang('alert_check_step3_tab_email'); ?></a></li>
                    <li><a href="#nagiosdiv" data-toggle="tab" style="font-weight: bold;"><?php echo lang('alert_check_step3_tab_nagios'); ?></a></li>
                    <li><a href="#snmpdiv" data-toggle="tab" style="font-weight: bold;"><?php echo lang('alert_check_step3_tab_trap'); ?></a></li>
                    <li><a href="#cmddiv" data-toggle="tab" style="font-weight: bold;"><?php echo lang('alert_check_step3_tab_cmd'); ?></a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="userdiv">
                        <p><?php echo lang('alert_check_step3_tab_email_desc'); ?></p>
                        <div class="well" style="margin-bottom: 0;">
                            <select style="width:100%; margin-bottom: 0;" id="userlist" name="userlist" multiple="multiple"></select>
                        </div>
                    </div>
                    <div class="tab-pane" id="nagiosdiv">
                        <p><?php echo lang('alert_check_step3_tab_nagios_desc'); ?></p>
                        <div class="well" style="margin-bottom: 0;">
                            <select style="width:100%; margin-bottom: 0;" id="nagioslist" name="nagioslist" multiple="multiple"></select>
                        </div>
                    </div>
                    <div class="tab-pane" id="snmpdiv">
                        <p><?php echo lang('alert_check_step3_tab_trap_desc'); ?></p>
                        <div class="well" style="margin-bottom: 0;">
                            <select style="width:100%; margin-bottom: 0;" id="snmplist" name="snmplist" multiple="multiple"></select>
                        </div>
                    </div>
                    <div class="tab-pane" id="cmddiv">
                        <p><?php echo lang('alert_check_step3_tab_cmd_desc'); ?></p>
                        <div class="well" style="margin-bottom: 0;">
                            <select style="width:100%; margin-bottom: 0;" id="cmdlist" name="cmdlist" multiple="multiple"></select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='modal-footer'>
            <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
            <a href='#' class='btn checks-goto2'><i class="icon-chevron-left"></i> <?php echo lang('alert_check_step3_backward'); ?></a>
            <a href='#' id='checks-finishsave' class='btn btn-primary'><?php echo lang('alert_check_step3_finish'); ?></a> 
        </div>
    </div>
</form>
<!--
END CHECK ADDING MODAL
-->

<?php echo $footer; ?>
