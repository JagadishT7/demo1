<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('alerting'); ?>"><?php echo lang('header_tab_alerting'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_commands'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    // Run the actual 'get commands' function
    update_command_list();

    // Open modal
    $('#new-command').click(function() {
        $('#command h3').html('<?php echo lang("alert_command_create_title"); ?>');
        $('#command-create-btn').show();
        $('#command-save-btn').hide();
        $('#command').modal('show');
    });

    // Create a new command via popup
    $('#command-create-btn').click(function() {
        var name = $('#name').val();
        var location = $('#location').val();
        var script = $('#script').val();
        var args = $('#args').val();

        var form = { 'name': name,
                     'location': location,
                     'script': script,
                     'args': args,
                     <?php echo get_csrf_block(); ?> }

        $.post(site_url+'api/system/create_command', form, function(data) {
            $('#command').modal('hide');
            clear_modal('#command');
            update_command_list();
        });
    });

    // Save/update a current command via popup
    $('#command-save-btn').click(function() {
        var name = $('#name').val();
        var location = $('#location').val();
        var script = $('#script').val();
        var args = $('#args').val();

        var form = { 'id': $('#edit-id').val(),
                     'name': name,
                     'location': location,
                     'script': script,
                     'args': args,
                     <?php echo get_csrf_block(); ?> }

        $.post(site_url+'api/system/update_command', form, function(data) {
            $('#command').modal('hide');
            clear_modal('#command');
            update_command_list();
        });
    });

    // Add linkage to delete and edit

    $('#commands-table-body').on('click', '.delete', function() {
        var id = $(this).parents('tr').data('id');
        $(this).parents('tr').remove();
        $.post(site_url+"api/system/delete_command", { 'id': id, <?php echo get_csrf_block(); ?> }, function(data) {
            update_command_list();
        });
    });

    $('#commands-table-body').on('click', '.edit', function() {
        var id = $(this).parents('tr').data('id');
        $.post(site_url+'api/system/get_commands', { 'id': id, <?php echo get_csrf_block(); ?> }, function(data) {
            var command = data[0];
            $('#name').val(command.name);
            $('#location').val(command.location);
            $('#script').val(command.script);
            $('#args').val(command.arguments);
            $('#edit-id').val(id);
            $('#command h3').html('<?php echo lang("alert_command_edit_title"); ?>');
            $('#command-create-btn').hide();
            $('#command-save-btn').show();
            $('#command').modal('show');
        }, 'json');
    });

    $('#command').on('click', '.command-close', function() {
        clear_modal('#command');
    });

});

function clear_modal(modal_id)
{
    $(modal_id+' input').val('');
}

function update_command_list()
{
    $.post(site_url+'api/system/get_commands', { <?php echo get_csrf_block(); ?> }, function(data) {
        var html = '';
        if (data.length > 0) {
            $.each(data, function(k, item) {
                html += '<tr data-id="'+item.id+'"><td>'+item.name+'</td><td>'+item.location+'</td><td>'+item.script+'</td><td>'+item.arguments+'</td><td><a class="edit"><?php echo lang("edit"); ?></a> &bull; <a class="delete"><?php echo lang("delete"); ?></a></td></tr>';
            });
        } else {
            html = '<tr><td colspan="5">No commands created.</td></tr>';
        }
        $('#commands-table-body').html(html);
    }, 'json');
}
</script>

<div class="container">
    <?php echo $tabs; ?>
    
    <div class="row-fluid" style="margin: 20px 0;">
        <div class="span12">
            <p style="margin-bottom: 20px;">
                <a href="#" id="new-command" class="btn"><i class="fa fa-terminal"></i> <?php echo lang('alert_command_new_button'); ?></a>
            </p>
            <div id="alerts"></div>
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <th><?php echo lang('alert_command_th_name'); ?></th>
                        <th><?php echo lang('alert_command_th_location'); ?></th>
                        <th><?php echo lang('alert_command_th_script'); ?></th>
                        <th><?php echo lang('alert_command_th_args'); ?></th>
                        <th><?php echo lang('actions'); ?></th>
                    </tr>
                </thead>
                <tbody id="commands-table-body"></tbody>
            </table>
        </div>
    </div>

    <div id="command" class="modal hide fade">
        <form id="command-form" style="margin: 0;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3><?php echo lang('alert_command_create_title'); ?></h3>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 20px;"><?php echo lang('alert_command_create_desc'); ?></p>
                <input type="hidden" id="edit-id" value="">
                <div class="form-horizontal">
                    <div class="control-group">
                        <label class="control-label" for="name"><?php echo lang('alert_command_th_name'); ?></label>
                        <div class="controls">
                            <input type='text' id='name' name='name'>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="location"><?php echo lang('alert_command_th_location'); ?></label>
                        <div class="controls">
                            <input type='text' id='location' name='location' style="width: 80%;" placeholder="/home/user/scripts">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="script"><?php echo lang('alert_command_th_script'); ?></label>
                        <div class="controls">
                            <input type='text' id='script' name='script' placeholder="run_something.sh">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="args"><?php echo lang('alert_command_th_args'); ?></label>
                        <div class="controls">
                            <input type='text' id='args' name='args' style="width: 80%;" placeholder="-s '%state%' -o '%output%'">
                        </div>
                    </div>
                    <p style="margin: 0;">
                        <div style="margin-bottom: 10px;"><?php echo lang('alert_command_create_desc2'); ?></div>
                        <ul>
                            <li><strong>%sourcename%</strong> - <?php echo lang('alert_command_create_macro1'); ?></li>
                            <li><strong>%state%</strong> - <?php echo lang('alert_command_create_macro3'); ?></li>
                            <li><strong>%returncode%</strong> - <?php echo lang('alert_command_create_macro4'); ?></li>
                            <li><strong>%output%</strong> - <?php echo lang('alert_command_create_macro5'); ?></li>
                        </ul>
                    </p>
                </div>
            </div>
        </form>
        <div class='modal-footer'>
            <button type='button' class='btn command-close' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
            <a href='#' id='command-create-btn' class='btn btn-primary'><?php echo lang('alert_command_create_btn'); ?></a>
            <a href='#' id='command-save-btn' class='btn btn-primary'><?php echo lang('alert_command_save_btn'); ?></a>
        </div>
    </div>

</div>

<?php echo $footer; ?>