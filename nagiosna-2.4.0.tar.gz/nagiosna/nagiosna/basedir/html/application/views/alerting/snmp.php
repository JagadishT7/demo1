<?php echo $header; ?>

<script>
var GLOBAL_TID = 0;
var edit = false;

function edit_tid(l_tid)
{
    $.getJSON(site_url + 'api/trapreceivers/read/', {'q[tid]': l_tid}, function(data) {
        $.each(data[0], function(key, value) {
            $('#' + key).val(value);
        });
    });
    
    GLOBAL_TID = l_tid;
    $('#snmp-step1').modal('show');
    edit = true;
}

function refresh_snmp_table()
{
    $.getJSON(site_url + 'api/trapreceivers/read', function(data) {
        if(data.length == 0) {
            var empty = $('<tr><td colspan="4"><?php echo lang("alert_snmp_none"); ?></td></tr>');
            $('#snmp-table-body').html(empty);
        }
        else {
            $('#snmp-table-body').html('')
            $.each(data, function(index, d) {
                var tr = $('<tr>');
                $('<td>', {"text": d.name}).appendTo(tr);
                $('<td>', {"text": d.ip}).appendTo(tr);
                $('<td>', {"text": d.version}).appendTo(tr);
                
                var action = $('<td>');
                
                var edit = $('<a>', {   "text": "<?php echo lang('view_edit'); ?>", 
                                        "style": "margin-right: 20px;",
                                        "role": "button" });
                var del = $('<a>', {"text": "<?php echo lang('delete'); ?>",
                                    "data-toggle": "modal",
                                    "role": "button",
                                    "href": "#delete-snmp-modal"});
                
                action.appendTo(tr);
                
                edit.click(function() { edit_tid(d.tid); });
                del.click(function() { GLOBAL_TID = d.tid; });
                
                edit.appendTo(action);
                del.appendTo(action);
                
                tr.appendTo($('#snmp-table-body'));
            });
        }
    });
}
    
$(document).ready(function() {
    
    // Load SNMP table
    refresh_snmp_table();
    
    $('#version').change(function() {
        var version = $(this).val();
        if(version == '2') {
            $('.v3').hide();
            $('.v2').show();
        } else {
            $('.v2').hide();
            $('.v3').show();
        }
    });
    
    $('#authlevel').change(function() {
        var level = $(this).val();
        $('.auth').hide();
        $('.priv').hide();
        if(level == 'authPriv') {
            $('.auth').show();
            $('.priv').show();
        }
        else if(level == 'authNoPriv') {
            $('.auth').show();
        }
    });
    
    $('#version').trigger('change');
    
    $('#new-snmp-receiver').click(function() {
        var inputs = $('#snmp-create :input').not('button');
        
        $.each(inputs, function(i, d) {
            var value = '';
            if(d.id == 'version') {
                value = '2';
            }
            if(d.id == 'authlevel') {
                value = 'authPriv';
            }
            $('#' + d.id).val(value);
        });
    });
    
    $('#delete-snmp-btn').click(function() {
        var del_url = site_url + 'api/trapreceivers/delete';
        var query = $.param({'q[tid]': GLOBAL_TID });
        
        $.getJSON(del_url, {'q[tid]': GLOBAL_TID}, function(data)  {
            $('.alert').hide();
            
            if(data.error) {
                $("#alert-error-div").html(data.error);
                $("#alert-error-container").show();
            } else {
                $("#alert-success-div").html("<?php echo lang('alert_snmp_delete_success'); ?>");
                $("#alert-success-container").show();
            }
            
            refresh_snmp_table();
        });
    });
    
    $('#snmp-finishsave').click(function() {
        var new_snmp = $('#snmp-create').serializeArray();
        var api_url;
        var mutate = /^q(.*)/;
        
        if(edit == false) {
            // We are creating a new one, so we just give it a URL
            api_url = site_url + 'api/trapreceivers/create';
        } else {
            // We are editing, so we need to move all the q's to u's
            // and set the tid.
            api_url = site_url + 'api/trapreceivers/update';
            var u_snmp = [];
            $.each(new_snmp, function(i, d) {
                var new_name = 'u' + mutate.exec(d.name)[1];
                u_snmp.push({ name: new_name, value: d.value})
            });
            
            u_snmp.push({name: 'q[tid]', value: GLOBAL_TID});
            new_snmp = u_snmp;
        }
        
        //console.log(new_snmp);
        $.getJSON(api_url, new_snmp, function(data) {
            $('.alert').hide();
            
            if(data.error) {
                alert(data.error);
            } else {
                edit = false;
                $("#alert-success-div").html("<?php echo lang('alert_snmp_saved_success'); ?>");
                $("#alert-success-container").show();
                $('#snmp-step1').modal('hide');
            }
            
            refresh_snmp_table();
        });
    });
});
</script>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('alerting'); ?>"><?php echo lang('header_tab_alerting'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_snmp'); ?></li>
</ul>

<div class="container">
    <?php echo $tabs; ?>
    
    <div class="row-fluid" style="margin: 20px 0;">
        <div class="span6">
            <a href="#" id='new-snmp-receiver' data-target='#snmp-step1' data-toggle='modal' class="btn"><i class="icon-screenshot"></i> <?php echo lang('alert_snmp_new_button'); ?></a>
        </div>
<!--
        <div class="span6" style="text-align: right;">
            <div class="form-horizontal" style="margin-right:30px;">
                <input type="text" id="snmp-search" placeholder="Search by device name"></input> <button id="snmp-search-btn" class="btn"><i class="icon-search"></i></button>
            </div>
        </div>
-->
    </div>
    
    <div id="alert-error-container" class="alert alert-error hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-error-div"></div>
    </div>
    
    <div id="alert-success-container" class="alert alert-success hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-success-div"></div>
    </div>
    
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th><?php echo lang('alert_snmp_th_name'); ?></th>
                <th><?php echo lang('alert_snmp_th_ip'); ?></th>
                <th><?php echo lang('alert_snmp_th_version'); ?></th>
                <th><?php echo lang('alert_snmp_th_actions'); ?></th>
            </tr>
        </thead>
        <tbody id="snmp-table-body"></tbody>
    </table>
    
</div>

<div id="snmp-step1" class="modal hide fade">
    <form id="snmp-create">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_snmp_step1_title'); ?></h3>
        </div>
        <div class="modal-body">
            <p><?php echo lang('alert_snmp_step1_desc'); ?></p>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[name]"><?php echo lang('alert_snmp_step1_name'); ?></label>
                    <div class="controls">
                        <input type='text' id='name' name='q[name]'>
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[ip]"><?php echo lang('alert_snmp_step1_ip'); ?></label>
                    <div class="controls">
                        <input type='text' id='ip' name='q[ip]'>
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[port]"><?php echo lang('alert_snmp_step1_port'); ?></label>
                    <div class="controls">
                        <input type='text' id='port' name='q[port]' value="162">
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="version"><?php echo lang('alert_snmp_step1_version'); ?></label>
                    <div class="controls">
                        <select id="version" name="q[version]">
                            <option value="2">2c</option>
                            <option value="3">3</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-horizontal v2">
                <div class="control-group">
                    <label class="control-label" for="q[community]"><?php echo lang('alert_snmp_step1_cstring'); ?></label>
                    <div class="controls">
                        <input type="text" id="community" name="q[community]">
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3">
                <div class="control-group">
                    <label class="control-label" for="q[username]"><?php echo lang('alert_snmp_step1_username'); ?></label>
                    <div class="controls">
                        <input type="text" id="username" name="q[username]">
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3">
                <div class="control-group">
                    <label class="control-label" for="q[authlevel]"><?php echo lang('alert_snmp_step1_auth_lvl'); ?></label>
                    <div class="controls">
                        <select id="authlevel" name="q[authlevel]">
                            <option value="authPriv" selected="selected">authPriv</option>
                            <option value="authNoPriv">authNoPriv</option>
                            <option value="noAuthnoPriv">noAuthnoPriv</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3 auth">
                <div class="control-group">
                    <label class="control-label" for="q[authprotocol]"><?php echo lang('alert_snmp_step1_auth_pro'); ?></label>
                    <div class="controls">
                        <select id="authprotocol" name="q[authprotocol]">
                            <option value="MD5">MD5</option>
                            <option value="SHA">SHA</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3 auth">
                <div class="control-group">
                    <label class="control-label" for="q[authpassword]"><?php echo lang('alert_snmp_step1_auth_pass'); ?></label>
                    <div class="controls">
                        <input type="text" id="authpassword" name="q[authpassword]">
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3 priv">
                <div class="control-group">
                    <label class="control-label" for="q[privprotocol]"><?php echo lang('alert_snmp_step1_priv_pro'); ?></label>
                    <div class="controls">
                        <select id="privprotocol" name="q[privprotocol]">
                            <option value="AES">AES</option>
                            <option value="DES">DES</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-horizontal v3 priv">
                <div class="control-group">
                    <label class="control-label" for="q[privpassword]"><?php echo lang('alert_snmp_step1_priv_pass'); ?></label>
                    <div class="controls">
                        <input type="text" id="privpassword" name="q[privpassword]">
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class='modal-footer'>
        <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
        <a href='#' id="snmp-finishsave" class='btn btn-primary'><?php echo lang('alert_snmp_step1_button'); ?></a>
    </div>
</div>

<div class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="Delete SNMP Receiver" aria-hidden="true" id="delete-snmp-modal">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang('alert_snmp_modal_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('alert_snmp_modal_desc'); ?></p>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss='modal'><?php echo lang('cancel_button'); ?></a>
        <a href="#" class="btn btn-danger" id="delete-snmp-btn" data-dismiss='modal'><?php echo lang('yes_button'); ?></a>
    </div>
</div>

<?php echo $footer; ?>