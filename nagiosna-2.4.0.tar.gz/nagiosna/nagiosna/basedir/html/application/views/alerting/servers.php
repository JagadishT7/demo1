<?php echo $header; ?>
<script>
// IDs for hostservices and nagiosservers
var GLOBAL_SHID;
var GLOBAL_SID;

// Determines if we are in edit mode for hostservices or nagiosservers
var GLOBAL_EDIT_SHID;
var GLOBAL_EDIT_SID;
    
function populate_serverid_select()
{
    var api_url = site_url + 'api/nagiosservers/read';
    $('#serverid').html('');
    
    $.getJSON(api_url, function(data) {
        $.each(data, function(i, d) {
            $('<option>', { "value": d.id,
                            "text": d.name }).appendTo('#serverid');
        });
    });
}

function show_error(msg)
{
    $("#alert-success-container").hide();
    $("#alert-error-div").html(msg);
    $("#alert-error-container").show();
}

function show_info(msg)
{
    $("#alert-error-container").hide();
    $("#alert-success-div").html(msg);
    $("#alert-success-container").show();
}

function edit_nagiosserver(id)
{
    GLOBAL_SID = id;
    GLOBAL_EDIT_SID = true;
    
    $.getJSON(site_url + 'api/nagiosservers/read/', {'q[id]': id}, function(data) {
        $.each(data[0], function(key, value) {
            $('#' + key).val(value);
        });
    });
    
    $('#create-nagios-server').modal('show');
}

function edit_servicenamehostname(id)
{
    GLOBAL_SHID = id;
    GLOBAL_EDIT_SHID = true;
    
    $.getJSON(site_url + 'api/hostservices/read/', {'q[id]': id}, function(data) {
        $.each(data[0], function(key, value) {
            $('#' + key).val(value);
        });
    });
    
    $('#create-servicename-hostname').modal('show');
}

function fill_servicename_hostname_table()
{
    var api_url = site_url + 'api/hostservices/read';
    var server_api = site_url + 'api/nagiosservers/read';
    
    $('#servicenamehostname-table-body').html('');
    
    $.getJSON(api_url, function(data) {
        if(data.length == 0) {
            $('#servicenamehostname-table-body').html('<tr><td colspan="4"><?php echo lang("alert_noservices"); ?></td></tr>');
        } else {
            $.each(data, function(i, d) {
                $.getJSON(server_api, {'q[id]': d.serverid}, function(info) {
                    var servername = info[0].name;
                    var tr = $('<tr>');
                    var edit = $('<a>', {"text": "<?php echo lang('view_edit'); ?>"});
                    var del = $('<a>', {"text": "<?php echo lang('delete'); ?>", 
                                        "style": "margin-left:20px;",
                                        "data-toggle": "modal",
                                        "role": "button",
                                        "href": "#delete-hostnameservicename-modal"});
                    var td = $('<td>');
                    
                    edit.click(function() { edit_servicenamehostname(d.id) });
                    del.click(function() { GLOBAL_SHID = d.id; });
                    
                    edit.appendTo(td);
                    del.appendTo(td);
                    
                    $('<td>', {"text": d.servicename}).appendTo(tr);
                    $('<td>', {"text": d.hostname}).appendTo(tr);
                    $('<td>', {"text": servername}).appendTo(tr);
                    td.appendTo(tr);
                    
                    
                    tr.appendTo('#servicenamehostname-table-body');
                });
            });
        }
    });
}

function fill_nagiosserver_table()
{
    var api_url = site_url + 'api/nagiosservers/read';
    
    $('#nagiosserver-table-body').html('');
    
    $.getJSON(api_url, function(data) {
        if(data.length == 0) {
            $('#nagiosserver-table-body').html('<tr><td colspan="4"><?php echo lang("alert_noservers"); ?></td></tr>');
        } else {
            $.each(data, function(i, d) {
                var tr = $('<tr>');
                var tr = $('<tr>');
                var edit = $('<a>', {"text": "<?php echo lang('view_edit'); ?>"});
                var del = $('<a>', {"text": "<?php echo lang('delete'); ?>", 
                                    "style": "margin-left:20px;",
                                    "data-toggle": "modal",
                                    "role": "button",
                                    "href": "#delete-nagios-server-modal"});
                var td = $('<td>');
                
                edit.click(function() { edit_nagiosserver(d.id) });
                del.click(function() { GLOBAL_SID = d.id; });
                    
                edit.appendTo(td);
                del.appendTo(td);
                
                $('<td>', {"text": d.name}).appendTo(tr);
                $('<td>', {"text": d.nrdp}).appendTo(tr);
                $('<td>', {"text": d.token}).appendTo(tr);
                td.appendTo(tr);
                
                tr.appendTo('#nagiosserver-table-body');
            });
        }
    });
}

$(document).ready(function() {
    
    fill_nagiosserver_table();
    fill_servicename_hostname_table();
    populate_serverid_select();
    $('#servicename-hostname-throbber').hide();
    
    $('#servicename-hostname-finishsave').click(function() {
        var form = $('#servicename-hostname-create').serializeArray();
        var api_url = site_url + 'api/hostservices/create';
        
        if(GLOBAL_EDIT_SHID != true) {
            // We are creating a new one, so we just give it a URL
            api_url = site_url + 'api/hostservices/create';
        } else {
            // We are editing, so we need to move all the q's to u's
            // and set the tid.
            api_url = site_url + 'api/hostservices/update';
            var u = [];
            var mutate = /^q(.*)/;
            
            $.each(form, function(i, d) {
                var new_name = 'u' + mutate.exec(d.name)[1];
                u.push({ name: new_name, value: d.value})
            });
            
            u.push({name: 'q[id]', value: GLOBAL_SHID});
            form = u;
            
            // Go out of edit mode
            GLOBAL_EDIT_SHID = false;
        }
        
        $('#servicename-hostname-throbber').show();
        
        $.getJSON(api_url, form, function(data) {
            $('#servicename-hostname-throbber').hide();
            if(data.error) {
                alert(data.error)
            } else {
                if(data.minor) {
                    show_info(data.minor + ' <?php echo lang("alert_server_save_host"); ?>');
                } else {
                    show_info("<?php echo lang('alert_success_service_create'); ?>");
                }
                $("#create-servicename-hostname").modal('hide');
                fill_servicename_hostname_table();
            }
        });
    });
    
    $('#nagios-server-finishsave').click(function() {
        var form = $('#nagios-server-create').serializeArray();
        var api_url = site_url + 'api/nagiosservers/create';
        
        if(GLOBAL_EDIT_SID != true) {
            // We are creating a new one, so we just give it a URL
            api_url = site_url + 'api/nagiosservers/create';
        } else {
            // We are editing, so we need to move all the q's to u's
            // and set the tid.
            api_url = site_url + 'api/nagiosservers/update';
            var u = [];
            var mutate = /^q(.*)/;
            
            $.each(form, function(i, d) {
                var new_name = 'u' + mutate.exec(d.name)[1];
                u.push({ name: new_name, value: d.value})
            });
            
            u.push({name: 'q[id]', value: GLOBAL_SID});
            form = u;
            
            // Go out of edit mode
            GLOBAL_EDIT_SID = false;
        }
        
        //console.log(form);
        
        $.getJSON(api_url, form, function(data) {
            if(data.error) {
                alert(data.error);
            } else {
                show_info("<?php echo lang('alert_success_server_create'); ?>");
                $("#create-nagios-server").modal('hide');
                fill_nagiosserver_table();
            }
        });
    });
    
    $('#delete-hostnameservicename-btn').click(function() {
        var api_url = site_url + 'api/hostservices/delete';
        
        $.getJSON(api_url, {'q[id]': GLOBAL_SHID}, function(data) {
            if(data.error) {
                show_error(data.error);
            } else {
                show_info("<?php echo lang('alert_success_service_delete'); ?>");
                $("#create-servicename-hostname").modal('hide');
                fill_servicename_hostname_table();
            }
        });
    });
    
    $('#delete-nagios-server-btn').click(function() {
        var api_url = site_url + 'api/nagiosservers/delete';
        
        $.getJSON(api_url, {'q[id]': GLOBAL_SID}, function(data) {
            if(data.error) {
                show_error(data.error);
            } else {
                show_info("<?php echo lang('alert_success_server_delete'); ?>");
                $("#create-nagios-server").modal('hide');
                fill_nagiosserver_table();
            }
        });
    });
    
    $('#new-servicename-hostname').click(function() {
        
        var api_url = site_url + 'api/nagiosservers/read';
        $.getJSON(api_url, function(data) {
            if(data.length < 1) {
                show_error("<?php echo lang('alert_error_noserver'); ?>");
            } else {
                $('#alert-error-container').hide();
                populate_serverid_select();
                $('#create-servicename-hostname').modal();
            }
        });
    });
});

</script>


<ul class="breadcrumb">
    <li><a href="<?php echo site_url('alerting'); ?>"><?php echo lang('header_tab_alerting'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_servers'); ?></li>
</ul>

<div class="container">
    <?php echo $tabs; ?>
    
    <div style="margin: 20px 0;"></div>
    
    <div id="alert-error-container" class="alert alert-error hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-error-div"></div>
    </div>
    
    <div id="alert-success-container" class="alert alert-success hide">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <div id="alert-success-div"></div>
    </div>
    
    <div class="row-fluid" style="margin: 20px 0;">
        <div class="span6">
            <a style="margin-bottom: 20px;" href="#" id='new-servicename-hostname' class="btn"><i class="icon-hdd"></i> <?php echo lang('alert_service_new'); ?></a>
            <div>
                <table class="table table-hover table-striped table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo lang('alert_service_th_name'); ?></th>
                            <th><?php echo lang('alert_service_th_hostname'); ?></th>
                            <th><?php echo lang('alert_service_th_server'); ?></th>
                            <th><?php echo lang('alert_service_th_actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="servicenamehostname-table-body"></tbody>
                </table>
            </div>
        </div>
        <div class="span6">
            <a style="margin-bottom: 20px;" href="#" id='new-nagios-server' data-target='#create-nagios-server' data-toggle='modal' class="btn"><i class="icon-hdd"></i> <?php echo lang('alert_server_new'); ?></a>
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <th><?php echo lang('alert_server_th_name'); ?></th>
                        <th><?php echo lang('alert_server_th_address'); ?></th>
                        <th><?php echo lang('alert_server_th_token'); ?></th>
                        <th><?php echo lang('alert_server_th_actions'); ?></th>
                    </tr>
                </thead>
                <tbody id="nagiosserver-table-body"></tbody>
            </table>
        </div>
    </div>
    

</div>

<div id="create-nagios-server" class="modal hide fade">
    <form id="nagios-server-create">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_modal_title'); ?></h3>
        </div>
        <div class="modal-body">
            <p><?php echo lang('alert_modal_server_desc'); ?></p>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[name]"><?php echo lang('alert_server_th_name'); ?></label>
                    <div class="controls">
                        <input type='text' id='name' name='q[name]'>
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[nrdp]"><?php echo lang('alert_server_th_address'); ?></label>
                    <div class="controls">
                        <input type='text' id='nrdp' name='q[nrdp]'>
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[token]"><?php echo lang('alert_server_th_token'); ?></label>
                    <div class="controls">
                        <input type='text' id='token' name='q[token]'>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class='modal-footer'>
        <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
        <a href='#' id="nagios-server-finishsave" class='btn btn-primary'><?php echo lang('alert_snmp_step1_button'); ?></a>
    </div>
</div>

<div id="create-servicename-hostname" class="modal hide fade">
    <form id="servicename-hostname-create">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?php echo lang('alert_modal_title'); ?></h3>
        </div>
        <div class="modal-body">
            <p><?php echo lang('alert_modal_service_desc'); ?></p>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[servicename]"><?php echo lang('alert_service_th_name'); ?></label>
                    <div class="controls">
                        <input type='text' id='servicename' name='q[servicename]'>
                    </div>
                </div>
            </div>
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[hostname]"><?php echo lang('alert_service_th_hostname'); ?></label>
                    <div class="controls">
                        <input type='text' id='hostname' name='q[hostname]'>
                    </div>
                </div>
            </div>
            <div style="text-align:center">on</div><br />
            <div class="form-horizontal">
                <div class="control-group">
                    <label class="control-label" for="q[serverid]">Server</label>
                    <div class="controls">
                        <select id='serverid' name='q[serverid]'></select>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class='modal-footer'>
        <span id='servicename-hostname-throbber' style="display:block-inline;margin-right:20px;"><img src='<?php echo base_url('media/images/ajax-loader.gif'); ?>'></span>
        <button type='button' class='btn' data-dismiss='modal'><?php echo lang('cancel_button'); ?></button>
        <a href='#' id="servicename-hostname-finishsave" class='btn btn-primary'><?php echo lang('alert_snmp_step1_button'); ?></a>
    </div>
</div>

<div class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="<?php echo lang('alert_server_label_delete_assoc'); ?>" aria-hidden="true" id="delete-hostnameservicename-modal">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang('alert_service_delete_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('alert_service_delete_desc'); ?></p>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss='modal'><?php echo lang('cancel_button'); ?></a>
        <a href="#" class="btn btn-danger" id="delete-hostnameservicename-btn" data-dismiss='modal'><?php echo lang('yes_button'); ?></a>
    </div>
</div>

<div class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="<?php echo lang('alert_server_label_delete'); ?>" aria-hidden="true" id="delete-nagios-server-modal">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3><?php echo lang('alert_server_delete_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('alert_server_delete_desc'); ?></p>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss='modal'><?php echo lang('cancel_button'); ?></a>
        <a href="#" class="btn btn-danger" id="delete-nagios-server-btn" data-dismiss='modal'><?php echo lang('yes_button'); ?></a>
    </div>
</div>

<?php echo $footer; ?>