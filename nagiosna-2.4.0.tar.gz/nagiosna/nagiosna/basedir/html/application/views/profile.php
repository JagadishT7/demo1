<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('profile_heading'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    $('#apikey').click(function() { this.select(); });

    $('#update_password_btn').click(function() {
        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        $('#change_password').modal('show');
        <?php } ?>
    });

    $('#update_pass_btn').click(function() {
        var vars = { old_pass: $('input[name="old_pass"]').val(),
                     new_pass: $('input[name="new_pass"]').val(), 
                     new_pass2: $('input[name="new_pass2"]').val(),
                     <?php echo get_csrf_block(); ?> }

        $('#update_pass_error').hide();
        $('#update_pass_msg').hide();

        $.post(site_url + 'auth/change_password', vars, function(data) {
            if (data.success == 1) { 
                $('#update_pass_msg').removeClass('alert-error').addClass('alert-success').html('<?php echo lang('change_password_msg_success'); ?>').show();
                $('input[type="password"]').val(''); // Clear fields
                $('#update_pass_msg').delay(2000).fadeOut(800);
            } else {
                $('#update_pass_msg').removeClass('alert-success').addClass('alert-error').html(data.errormsg).show();
            }
        }, 'json');
    });

    $('#update_profile_btn').click(function() {
        var vars = { first_name: $('input[name="first_name"]').val(),
                     last_name: $('input[name="last_name"]').val(),
                     company: $('input[name="company"]').val(),
                     email: $('input[name="email"]').val(),
                     phone: $('input[name="phone"]').val(),
                     <?php echo get_csrf_block(); ?> }

        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        $.post(site_url + 'auth/update_profile', vars, function(data) {
            if (data.success == 1) {
                $('#update_profile_msg').removeClass('alert-error').addClass('alert-success').html('<?php echo lang('update_profile_msg_success'); ?>').show();
                $('#update_profile_msg').delay(1000).fadeOut(800);
            } else {
                $('#update_profile_msg').removeClass('alert-success').addClass('alert-error').html(data.errormsg).show();
            }
        }, 'json');
        <?php } ?>
    });

    // Change language
    $('#language').change(function() {
        var language = $(this).val();
        $.post(site_url + 'dashboard/setlanguage', { language: language, <?php echo get_csrf_block(); ?> }, function(data) {
            window.location.reload();
        });
    });

});
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12" style="border-bottom: 1px solid #EEE; padding-bottom: 15px; margin-bottom: 10px;">
            <h2><?php echo lang('profile_heading'); ?></h2>
            <p><?php echo lang('profile_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span4">
            <h3><?php echo lang('profile_info_heading'); ?></h3>
            <p><?php echo lang('profile_info_desc'); ?></p>
            <div id="update_profile_msg" class="alert hide"></div>

            <table>
                <tr>
                    <td class="form-left"><?php echo lang('profile_username'); ?>:</td>
                    <td><input type="text" value="<?php echo $user->username; ?>" disabled="disabled" /></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('profile_full_name'); ?>:</td>
                    <td><input type="text" name="first_name" value="<?php echo $user->first_name; ?>" class="input-medium" /> <input type="text" name="last_name" value="<?php echo $user->last_name; ?>" class="input-medium" /></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('profile_company'); ?>:</td>
                    <td><input type="text" name="company" value="<?php echo $user->company; ?>" class="input-large" /></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('profile_email'); ?>:</td>
                    <td><input type="text" name="email" value="<?php echo $user->email; ?>" class="input-xlarge" /></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('profile_phone'); ?>:</td>
                    <td><input type="text" name="phone" value="<?php echo $user->phone; ?>" class="input-medium" /></td>
                </tr>
                <tr>
                    <td class="form-left"></td>
                    <td><button id="update_profile_btn" class="btn btn-primary"><?php echo lang('update_button'); ?></button></td>
                </tr>
            </table>

        </div>
        <div class="span4">
            <h3><?php echo lang('profile_actions_heading'); ?></h3>
            <p><?php echo lang('profile_actions_desc'); ?></p>

            <p class="input-prepend">
                <span class="add-on"><i class="icon-flag"></i> <?php echo lang('language'); ?></span>
                <select id="language" class="input-medium">
                    <option value="default" <?php if ($user_language == 'default') { echo 'selected'; } ?>><?php echo lang('default'); ?></option>
                    <?php foreach ($languages as $l) { ?>
                    <option value="<?php echo $l; ?>" <?php if ($user_language == $language && $language == $l) { echo 'selected'; } ?>>
                        <?php $output = lang('language_' . $l); if (empty($output)) { echo uppercase($l); } else { echo $output; } ?>
                    </option>
                    <?php } ?>
                </select>
            </p>
            <p><a href="#" role="button" class="btn" id="update_password_btn"><i class="icon-lock"></i> <?php echo lang('profile_change_password'); ?></a></p>
        </div>
        <div class="span4">
            <h3><?php echo lang('profile_api_heading'); ?></h3>
            <p><?php echo lang('profile_api_desc'); ?></p>
            <?php if ($user->apiaccess) { ?>
            <p><strong><?php echo lang('profile_api_access_level'); ?>:</strong> <?php if ($is_admin) { echo lang('profile_api_access_admin'); } else { echo lang('profile_api_access_user'); } ?></p>
            <div><input type="text" value="<?php echo $user->apikey; ?>" class="no-highlight" style="cursor: pointer; box-shadow: none; width: 320px;" id="apikey" maxlength="32" readonly></div>
            <div>
                <?php echo form_open('profile/newkey'); ?>
                <input type="hidden" value="<?php echo $user->id; ?>" name="user_id_verify" />
                <button type="submit" class="btn btn-primary"><i class="icon-refresh icon-white"></i> <?php echo lang('profile_api_newkey'); ?></button>
                <?php echo form_close(); ?>
            </div>
            <?php } else { ?>
            <p><strong><?php echo lang('profile_api_noaccess'); ?></strong></p>
            <?php } ?>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div id="change_password" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="change_password_header" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="change_password_header"><?php echo lang('profile_change_password'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('profile_change_password_desc'); ?></p>
        <div id="update_pass_msg" class="alert hide"></div>
        <table style="margin-top: 20px;">
            <tr>
                <td class="form-left"><?php echo lang('profile_change_password_old'); ?>:</td>
                <td><input type="password" name="old_pass" class="input-medium" /></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('profile_change_password_new'); ?>:</td>
                <td><input type="password" name="new_pass" class="input-medium" /></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('profile_change_password_new_conf'); ?>:</td>
                <td><input type="password" name="new_pass2" class="input-medium" /></td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
        <button id="update_pass_btn" class="btn btn-primary"><?php echo lang('update_button'); ?></button>
    </div>
</div>


<?php echo $footer; ?>