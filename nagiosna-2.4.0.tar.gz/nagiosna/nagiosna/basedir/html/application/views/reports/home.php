<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_reports'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {
    
    list_reports();
    load_run_modal();
    
    $('#report-search-button').click(function() {
        list_reports();
    });
    
    $('#report-search').keyup(function(e) {
        if (e.keyCode == 13) {
            $('#report-search-button').trigger('click');
        }
    });

    <?php if ($is_admin) { ?>
    // Create
    $('#create_report_popup_btn').click(function() {
        clear_modal();
        $('#hidden').val('create');
        $('#title').html('<?php echo lang('create_button'); ?>');
        $('#timerange').val('2h').trigger('change');
        $('#create_report').modal('show');
    });

    // Create new report
    $('#create_report_btn').click(function() {
        var rid = $('#rid').val();
        var name = $('#name').val();
        var top = $('#top').val();
        var rawquery = $('#limiter').val();
        dates = get_correct_datetimes();
        var toporder = $('select[name="toporder"]').val();
        var toptype = $('select[name="toptype"]').val();
        var url;
        if ($('#hidden').val() == 'create') {
            url = site_url + 'api/reports/create';
            var vars = { 'q[name]':         name,
                         'q[top]':          top,
                         'q[toporder]':     toporder,
                         'q[toptype]':      toptype,
                         'q[rawquery]':     rawquery, 
                         'q[begindate]':    dates.start,
                         'q[enddate]':      dates.end,
                         <?php echo get_csrf_block(); ?> }
        } else if ($('#hidden').val() == 'update') {
            url = site_url + 'api/reports/update';
            var vars = { 'q[rid]':          rid,
                         'u[name]':         name,
                         'u[top]':          top,
                         'u[toporder]':     toporder,
                         'u[toptype]':      toptype,
                         'u[rawquery]':     rawquery,
                         'u[begindate]':    dates.start,
                         'u[enddate]':      dates.end,
                         <?php echo get_csrf_block(); ?> }
        }
        $.post(url, vars, function(data) {
            if (data.status == 'success') {
                $('#create_report').modal('hide');
                list_reports();
            } else {
                $('#error').html(data.error).show();
            }
        });
    });

    $('#delete_multi_report').click(function() {
        var report_ids = $('input:checkbox[name=reports]:checked').map(function(_, el) {
            return $(el).val();
        }).get();
        var conf = confirm("<?php echo lang('report_home_delete_multi'); ?>");
        if (conf === true) {
            $.post(site_url + 'api/reports/delete', { 'q[rid]': report_ids, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                } else {
                    list_reports();
                }
            }, 'json');
        }
    });
    <?php } ?>

    // Select source/group
    $('input[name="type"]').change(function() {
        if ($(this).val() == 'source') {
            $('#sources').show();
            $('#groups').hide();
        } else if ($(this).val() == 'group') {
            $('#sources').hide();
            $('#groups').show();
        }
    });

    // Run report button
    $('#run_report_send').click(function() {
        var rid = $('#rid').val();
        var type = $('input[name="type"]:checked').val() + 's';
        var id = $('#' + type).val();
        var url = site_url + type + '/reports/' + id + '?rid=' + rid;
        window.location.href = url;
    });

});

function load_run_modal()
{
    // Get a list of sources
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(sources) {
        $.each(sources, function(key, source) {
            $('#sources').append('<option value="' + source.sid + '">' + source.name + '</option>');
        });
    });

    // Get a list of source groups
    $.post(site_url + 'api/groups/read', { <?php echo get_csrf_block(); ?> }, function(groups) {
        $.each(groups, function(key, group) {
            $('#groups').append('<option value="' + group.gid + '">' + group.name + '</option>');
        });
    });
}

function bind_buttons()
{
    <?php if ($is_admin) { ?>
    // View/Update
    $('.view_report').unbind();
    $('.view_report').click(function() {
        clear_modal();
        var rid = $(this).data('rid');
        $('#hidden').val('update');
        $('#title').html('<?php echo lang('update_button'); ?>');
        $('#rid').val(rid);
        $.post(site_url + 'api/reports/read', { 'q[rid]': rid, <?php echo get_csrf_block(); ?> }, function(data) {
            var report = data[0];
            // Load create report modal
            $('#name').val(report.name);
            $('#top').val(report.top);
            $('select[name="toptype"]').val(report.toptype);
            $('select[name="toporder"]').val(report.toporder);
            set_time_range(report.begindate, report.enddate);
            $('#create_report').modal('show');
            $('#limiter').val(report.rawquery);
        });
    });

    // Delete
    $('.delete_report_btn').unbind();
    $('.delete_report_btn').click(function() {
        var rid = $(this).data('rid');
        var name = $(this).data('name');
        var conf = confirm('<?php echo lang('report_home_delete'); ?>: ' + name + '?');
        if (conf === true) {
            $.post(site_url + 'api/reports/delete', { 'q[rid]': rid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status == 'success') {
                    list_reports();
                } else {
                    alert(data.error);
                }
            });
        }
    });
    <?php } ?>

    // Run report
    $('.run_report_btn').unbind();
    $('.run_report_btn').click(function() {
        var rid = $(this).data('rid');
        $('#rid').val(rid);
        $('#run_report').modal('show');
    });

    $('.tbl-chk-input').unbind();
    $('.tbl-chk-input').change(function() {
        var report_ids = $('input:checkbox[name=reports]:checked').map(function(_, el) {
            return $(el).val();
        }).get();

        if (report_ids.length >= 1) {
            $('#delete_multi_report').attr('disabled', false);
        } else {
            $('#delete_multi_report').attr('disabled', true);
        }
    });
}

function clear_modal()
{
    $('#name').val('');
    $('#top').val('');
    $('#limiter').val('');
}

function list_reports()
{
    var value = $("#report-search").val();
    var rurl = site_url + 'api/reports/read';
    
    if (value) {
        search = { 's[name]': value, <?php echo get_csrf_block(); ?> };
    } else {
        search = { <?php echo get_csrf_block(); ?> };
    }
    
    $.post(rurl, search, function(reports) { 
        var table_inside = '<tr><td colspan="6"><?php echo lang("report_home_none"); ?></td></tr>';
        if (reports.length > 0) {
            table_inside = '';
            $.each(reports, function(key, report) {

                var actions = '';
                actions += '<a href="#" class="run_report_btn" data-rid="' + report.rid + '"><?php echo lang("run"); ?></a>';
                if (report.editable == '1') {
                    editable = "";
                    checkbox = '<label class="checkbox tbl-checkbox"><input type="checkbox" name="reports" class="tbl-chk-input" value="' + report.rid + '"></label>';
                    
                    <?php if ($is_admin) { ?>
                    actions += ' &bull; <a href="#" class="view_report" data-rid="' + report.rid + '"><?php echo lang("edit"); ?></a> &bull; <a href="#" data-rid="' + report.rid + '" data-name="' + report.name + '" class="delete_report_btn"><?php echo lang("delete"); ?></a>';
                    <?php } ?>
                } else {
                    editable = "(<?php echo lang('report_home_static'); ?>) ";
                    checkbox = '';
                }

                table_inside += '<tr>';
                table_inside += '<td>' + checkbox + '</td>';
                table_inside += '<td>' + editable + ' ' + report.name + '</td>';
                table_inside += '<td>' + actions + '</td>';

            });
        }
        $('#table-body').html(table_inside);
        bind_buttons();
    });
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('header_tab_reports'); ?></h2>
            <p><?php echo lang('report_home_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 15px;">
        <div class="span6">
            <?php if ($is_admin) { ?>
            <button type="button" class="btn" id="delete_multi_report" disabled><i class="icon-trash"></i> <?php echo lang('delete'); ?></button>
            <a href="#" class="btn" id="create_report_popup_btn"><i class="icon-file"></i> <?php echo lang('report_home_create'); ?></a>
            <?php } ?>
        </div>
        <div class="form-horizontal" style="text-align:right;">
            <input id="report-search" type="text" placeholder="<?php echo lang('report_home_search'); ?>"></input> <a href='javascript:void(0);' id="report-search-button" class="btn"><i class="icon-search"></i></a>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <div>
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th style="width: 16px; text-align: center;"><i class="icon-plus-sign select_all" style="cursor: pointer;" title="<?php echo lang('select_all'); ?>" data-for-name="reports"></i></th>
                            <th><?php echo lang('report_home_th_name'); ?></th>
                            <th style="width: 150px;"><?php echo lang('report_home_th_actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($is_admin) { ?>
<!-- Create Custom Report Modal -->
<div id="create_report" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><span id="title"></span> <?php echo lang('report_home_modal_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('report_home_modal_desc'); ?></p>
        <div id="error" class="alert alert-error hide"></div>
            <table style="margin-top: 20px;">
                <tr>
                    <td class="form-left" style="width: 150px;"><?php echo lang('report_home_modal_name'); ?>:</td>
                    <td><input type="text" class="input-xlarge" id="name"></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_top'); ?> #:</td>
                    <td><input type="text" style="width: 25px;" id="top" data-toggle="tooltip" title="<?php echo lang('report_home_tooltip'); ?>"></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_range'); ?>:</td>
                    <td>
                        <div>
                            <select id="timerange" style="width: 185px;">
								<option value="2h"><?php echo lang('timerange_2hrs'); ?></option>
                                <option value="4h"><?php echo lang('timerange_4hrs'); ?></option>
                                <option value="6h"><?php echo lang('timerange_6hrs'); ?></option>
                                <option value="12h"><?php echo lang('timerange_12hrs'); ?></option>
                                <option value="24h"><?php echo lang('timerange_24hrs'); ?></option>
                                <option value="2d"><?php echo lang('timerange_2days'); ?></option>
                                <option value="1w"><?php echo lang('timerange_week'); ?></option>
                                <option value="1m"><?php echo lang('timerange_month'); ?></option>
                                <option value="range"><?php echo lang('timerange_custom_range'); ?></option>
                                <option value="elapsed"><?php echo lang('timerange_custom_elapsed'); ?></option>
                            </select>
                        </div>
                        <div>
                           <span id="range_inputs" class="hide">
                                <input type="text" class="input-datetime" id="range_start">
                                <?php echo lang('to'); ?>
                                <input type="text" class="input-datetime" id="range_end">
                            </span>
                            <span id="elapsed_inputs" class="hide">
                                <input type="text" value="24 hours" title="<?php echo lang('timerange_elsapsed_desc'); ?>" class="input-small tt_bind" id="elapsed_start">
                                <?php echo lang('ago'); ?>
                                <input type="hidden" value="1 second" class="input-small" id="elapsed_end">
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_group'); ?>:</td>
                    <td>
                        <select name="toptype" class="input-medium">
                            <option value="srcip"><?php echo lang('source_ip'); ?></option>
                            <option value="dstip"><?php echo lang('destination_ip'); ?></option>
                            <!--<option value="ip">Any IP</option>-->
                            <option value="srcport"><?php echo lang('source_port'); ?></option>
                            <option value="dstport"><?php echo lang('destination_port'); ?></option>
                            <!--<option value="port">Any Port</option>-->
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_order'); ?>:</td>
                    <td>
                        <select name="toporder" class="input-medium">
                            <option value="flows"><?php echo lang('flows'); ?></option>
                            <option value="packets"><?php echo lang('packets'); ?></option>
                            <option value="bytes"><?php echo lang('bytes'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_limiter'); ?>:</td>
                    <td><input type="text" id="limiter" placeholder="ip 192.168.0.1"> <i class="icon-question-sign tt_bind" title="<?php echo lang('report_home_modal_limiter_desc'); ?>"></i></td>
                </tr>
            </table>     
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="rid">
        <input type="hidden" value="0" id="hidden">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
        <a href="#" id="create_report_btn" class="btn btn-primary"><?php echo lang('save_button'); ?></a>
    </div>
</div>
<?php } ?>

<!-- Run Report Modal -->
<div id="run_report" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang('report_home_run_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('report_home_run_desc'); ?></p>
        <table>
            <tr>
                <td class="form-left"></td>
                <td><label class="radio" style="display: inline-block; margin: 0 10px 10px 0;"><input type="radio" name="type" value="source" checked><?php echo lang('breadcrumb_source'); ?></label> <label class="radio" style="display: inline-block;"><input type="radio" name="type" value="group"><?php echo lang('breadcrumb_sourcegroup'); ?></label></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('report_home_run_on'); ?>:</td>
                <td>
                    <select id="sources" class="input-large">
                    </select>
                    <select id="groups" class="input-large hide">
                    </select>
                </td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="rid">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
        <a href="#" id="run_report_send" class="btn btn-primary"><?php echo lang('report_home_run_button'); ?> <i class="icon-chevron-right icon-white"></i></a>
    </div>
</div>

<?php echo $footer; ?>
