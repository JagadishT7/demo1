<?php echo $header; ?>

<ul class="breadcrumb <?php if (!empty($download)) { echo 'hide'; } ?>">
    <?php if ($type == 'sid') { ?>
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('sources/' . $source->sid); ?>"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></a> <span class="divider">/</span></li>
    <?php } else if ($type == 'gid') { ?>
    <li><a href="<?php echo site_url('groups'); ?>"><?php echo lang('header_tab_sourcegroups'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('groups/' . $group->gid); ?>"><?php echo lang('breadcrumb_sourcegroup'); ?> - <?php echo $group->name; ?></a> <span class="divider">/</span></li>
    <?php } ?>
    <li class="active"><?php echo lang('breadcrumb_percentile'); ?></li>
</ul>

<script>
var start_epoch;
var end_epoch;
var cquery = <?php print json_encode($cquery); ?>;
var download = '<?php echo $download; ?>';

$(document).ready(function() {

    // Someone is running a calculation!
    $('#calculate').click(function() {
        $('.loader').show();
        $('#empty-error').hide();

        // Get the form...
        var type = $('select[name="type"] option:selected').val();
        var start = $('#range_start').val();
        var end = $('#range_end').val();
        var percentile = $('input[name="percentile"]').val();

        var pdf_url_base = "q[start]="+start+"&q[end]="+end+"&q[type]="+type+"&q[percentile]="+percentile;

        if (type == "" || start == "" || end == "" || percentile == "") {
            $('#empty-error').show();
            $('.loader').hide();
            return;
        }

        // Set start/end times
        $('.from').html(start);
        $('.to').html(end);

        // Convert time stings to timestamps to create the graph
        var d = new Date(start);
        start_epoch = d.getTime() / 1000;
        var d = new Date(end);
        end_epoch = d.getTime() / 1000;

        var data = { begindate: start_epoch,
                     enddate: end_epoch,
                     <?php echo get_csrf_block(); ?> }

        // Convert mbps to bps
        if (type == "Mbps") {
            data['q[bps]'] = 'bps';
        } else {
            data['q['+type.toLowerCase()+']'] = type.toLowerCase();
        }
        
        if (view_id) {
            data['vid'] = view_id;
            pdf_url_base += '&q[vid]='+view_id;
        }

        var stype = '';
        var oid = 0;

        if (typeof source_id != 'undefined' && source_id > 0) {
            data['sid'] = source_id;
            stype = "source";
            oid = source_id;
        } else {
            data['gid'] = group_id;
            stype = "sourcegroup";
            oid = group_id;
        }

        // Create a link to download PDF version...
        var download_pdf_url = site_url + 'download/percentile/'+stype+'/'+oid+'/'+ window.btoa(pdf_url_base);
        $('#download-pdf').attr('href', download_pdf_url);
        if (download == '1') { $('#download-pdf').hide(); } else { $('#download-pdf').show(); }

        $('.percentile-box').hide();

        // Get the data for a graph...
        $.post(site_url + 'api/graphs/samples', data, function(d) {
            var samples = d[0].data;
            var num_samples = samples.length;

            var fulltime = end_epoch - start_epoch;
            var sample_size = fulltime / num_samples;

            $('.sample-size').html(hr_data_sample_size(sample_size));
            $('.number-samples').html(num_samples);

            samples.sort(function(a, b) { return a-b; });
            var highest = Math.ceil(samples[samples.length-1]);

            // Do a quick 95% calculation
            var throw_out = Math.ceil(num_samples * ((100-percentile)/100));
            
            var index = num_samples - throw_out - 1;
            var perc = samples[index];

            draw_chart(samples, highest, perc, index, type);

            if (type == "Mbps") {
                var perc = perc / 1048576;
            }

            // Update the page to show the percentile
            $('.percentile').html(perc.toFixed(3) + " " + type);
            $('.percentile-suffix').html(ordinal_suffix_of(percentile));
            $('.loader').hide();
            $('.percentile-box').show();

            if (view_id > 0) {
                if (download == '1') {
                    $.post(site_url + 'api/views/get_views', { 'q[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
                        var view_name = 'Unknown';
                        $.each(views, function(k, v) {
                            if (v.vid == view_id) {
                                view_name = v.name;
                            }
                        });
                        var view_html = "<?php echo lang('running_on_view'); ?>: <strong>"+view_name+"</strong>";
                        $('#view-desc').html(view_html);
                    });
                }
            }

        });

    });

    $('.how').click(function() {
        if ($('.how-description').is(':visible')) {
            $('.how-description').hide();
            $('.how-icon').removeClass('fa-chevron-down');
            $('.how-icon').addClass('fa-chevron-up');
        } else {
            $('.how-description').show();
            $('.how-icon').removeClass('fa-chevron-up');
            $('.how-icon').addClass('fa-chevron-down');
        }
    });

    // If we have a cquery... let's put the information in and run the query
    if (cquery != null) {
        $('#range_start').val(cquery['start']);
        $('#range_end').val(cquery['end']);
        if (cquery['type']) {
            $('select[name="type"]').val(cquery['type']);
        }
        if (cquery['percentile']) {
            $('input[name="percentile"]').val(cquery['percentile']);
        }
        $('#calculate').trigger('click');
    }

});

function ordinal_suffix_of(i) {
    var j = i % 10,
        k = i % 100;
    if (j == 1 && k != 11) {
        return i + "st";
    }
    if (j == 2 && k != 12) {
        return i + "nd";
    }
    if (j == 3 && k != 13) {
        return i + "rd";
    }
    return i + "th";
}

function hr_data_sample_size(sample_size) {
    if (sample_size > 0 && sample_size <= 320) {
        return "5 minutes";
    } else if (sample_size > 320 && sample_size <= 620) {
        return "10 minutes";
    } else if (sample_size > 620 && sample_size <= 660) {
        return "1 hour";
    } else {
        return "24 hours";
    }
}

function draw_chart(samples, highest, yaxis_line, xaxis_start, type) {
    $('#graph-container').highcharts({
        chart: {
            type: 'column',
            animation: false,
            spacing: [25, 25, 25, 25]
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        title: {
            text: ''
        },
        yAxis: {
            min: 0,
            title: {
                text: type
            },
            max: highest,
            minTickInterval: 1,
            tickInterval: (highest / 6),
            plotLines: [{
                color: '#000000',
                width: 1,
                value: yaxis_line,
                zIndex: 99
            }],
            units: '',
            labels: {
                formatter: function() {
                    if (type == "Mbps") {
                        var value = this.value / 1048576;
                    } else {
                        var value = this.value;
                    }
                    return value.toFixed(2);
                }
            },
            gridLineColor: '#E0E0E0',
            lineColor: '#E0E0E0',
            lineWidth: 1
        },
        xAxis: {
            min: 0,
            max: samples.length,
            title: {
                text: 'Samples'
            },
            plotBands: [{
                color: '#EFEFEF',
                from: xaxis_start,
                to: samples.length
            }],
            labels: {
                format: '{value}',
                enabled: false
            },
            tickColor: '#FFFFFF',
            gridLineColor: '#E0E0E0',
            lineColor: '#E0E0E0',
            lineWidth: 1
        },
        plotOptions: {
            column: {
                pointPadding: 0,
                borderWidth: 0
            }
        },
        legend: {
            enabled: false
        },
        tooltip: {
            enabled: false
        },
        series: [{
            name: 'Mbps',
            data: samples,
            animation: false
        }]
    });
}
</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="percentile-calc-container">
        <div class="row-fluid percentile-calc-form <?php if (!empty($download)) { echo 'hide'; } ?>">
            <div class="span12">
                <p><?php echo lang('percentile_title1'); ?><br/><?php echo lang('percentile_title2'); ?> <i class="fa how-icon fa-chevron-up"></i> <a href="#" class="how"><?php echo lang('percentile_how_button'); ?></a></p>
                <p class="how-description"><?php echo lang('percentile_desc'); ?></p>
                <div class="inline-input">
                    <div class="well" style="margin: 10px 0;">
                        <?php echo lang('percentile_timeframe'); ?>:
                        <span id="range_inputs">
                            <input type="text" class="input-datetime custom-field" id="range_start">
                            <?php echo lang('to'); ?>
                            <input type="text" class="input-datetime custom-field" id="range_end">
                        </span>
                        <span style="margin: 0 0 0 20px;">
                            <?php echo lang('percentile_data_type'); ?>:
                            <select name="type" style="width: 100px; margin: 0;">
                                <option value="Mbps">Mbps</option>
                                <option value="Bytes">Bytes</option>
                                <option value="Flows">Flows</option>
                                <option value="Packets">Packets</option>
                                <option value="Bps">Bps</option>
                            </select>
                        </span>
                        <span style="margin: 0 20px;">
                            <?php echo lang('percentile'); ?>:
                            <input name="percentile" type="text" style="width: 20px;" value="95">
                        </span>
                        <button id="calculate" class="btn btn-primary"><?php echo lang('percentile_calc'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row-fluid">
            <div class="span12">
                <div id="empty-error" class="hide">
                    <div class="alert alert-error">
                        <strong><?php echo lang('error'); ?>!</strong> <?php echo lang('percentile_error'); ?>
                    </div>
                </div>
                <div class="loader"><div class="fa fa-spinner fa-spin"></div></div>
                <div class="percentile-box">
                    <h4>
                        <span class="percentile-suffix"></span> <?php echo lang('percentile_title'); ?>
                        <a href="javascript:window.print()" class="btn btn-mini <?php if (!empty($download)) { echo 'hide'; } ?>" style="margin-left: 10px;"><i class="fa fa-print"></i> Print</a>
                        <a href="" target="_blank" id="download-pdf" class="btn btn-mini <?php if (!empty($download)) { echo 'hide'; } ?>" style="float: none; margin: 0;"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </h4>
                    <p id="view-desc"></p>
                    <p><?php echo lang('percentile_from'); ?> <strong><span class="from"></span></strong> <?php echo lang('to'); ?> <strong><span class="to"></span></strong></p>
                    <div>
                        <div id="graph-container" style="width: 400px; height: 200px; float: left; margin-right: 10px;">
                        </div>
                        <table style="float: left;" cellpadding="4">
                            <tr>
                                <td><?php echo lang('percentile_sample_size'); ?>:</td>
                                <td class="sample-size"></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('percentile_num_samples'); ?>:</td>
                                <td class="number-samples"></td>
                            </tr>
                            <tr>
                                <td><span class="percentile-suffix"></span> <?php echo lang('percentile'); ?>:</td>
                                <td class="percentile"></td>
                            </tr>
                        </table>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (empty($download)) { echo $footer; } ?>