<div width='100%'>
    <ul class='thumbnails' style='width: 1200px; margin: 0px auto;'>
        <li class='span3 thumbspan'>
            <div class='thumbnail'>
                <div id='pie' class='chartrender'></div>
                <h5><a class='btn btn-small fullscreen-button' title="<?php echo lang('fullscreen_pie'); ?>" data='#pie'><i class='icon-resize-full'></i></a><?php echo lang('pie_chart'); ?></h5>
            </div>
        </li>
        <?php foreach($datasets as $dataset => $description): ?>
        <li class='span3 thumbspan'>
            <div class='thumbnail'>
                <div id='<?php echo $dataset; ?>' class='chartrender'>
                    <div class='reportviz-throbber'>
                        <div class='valign-throbber centerme'>
                            <img src='/nagiosna/media/images/ajax-loader.gif'>
                        </div>
                    </div>
                </div>
                <h5><a class='btn btn-small fullscreen-button' title="<?php echo lang('fullscreen_chord'); ?>" data='#<?php echo $dataset; ?>'><i class='icon-resize-full'></i></a><?php echo $description; ?></h5>
            </div>
        </li>
        <?php endforeach ?>
    </ul>
</div>
<div id="bg-full"></div>

<script>
var aggs = <?php echo json_encode(array_keys($datasets)); ?>;
var aggt = <?php echo json_encode(array_values($datasets)); ?>;
var g_title = '<?php echo $title; ?>';
var OPEN_POPUP = '';

if(g_title.match(/^[0-9a-f]+$/i) != null) {
    g_title = '<?php echo lang("custom_report"); ?>';
}

$(document).ready(function() {
    make_pie();
    
    $.each(aggs, function(i,d) {
        make_chord(d, 600, 900, aggt[i]);
    });
    
    $('.fullscreen-button').click(function() {
        resize_to_fullscreen(this);
    });

    $(window).resize(function() {
        resize_bg_full();
        resize_open_popup();
    });

    $('#bg-full').click(function() {
        close_popup(OPEN_POPUP);
    });

    $('body').on('click', '.close-popup', function() {
        close_popup(OPEN_POPUP);
    });

});

function resize_open_popup()
{
    if (OPEN_POPUP == '') { return; }
    var div_id = OPEN_POPUP;
    var width = $(window).width();
    var height = $(window).height();

    // Calculate the size of the popup window
    popup_width = (width - 100) * 0.8;
    popup_height = (height - 120) * 0.75;
    var left = (width - popup_width - 100) / 2;
    var top = (height - popup_height - 120) / 2;

    $(div_id).css('top', top)
             .css('left', left)
             .css('width', popup_width)
             .css('height', popup_height);

    switch (div_id) {
        case '#pie':
            var chart = $(div_id).highcharts();
            chart.reflow();
            break;
        <?php foreach($datasets as $dataset => $garbage): ?>
        case '#<?php echo $dataset; ?>':
            break;
        <?php endforeach ?>
        default:
            break;
    }
}

function resize_to_fullscreen(node)
{    
    var div_id = $(node).attr('data');
    var width = $(window).width();
    var height = $(window).height();

    // Set open popup
    OPEN_POPUP = div_id;

    resize_bg_full();
    $('#bg-full').show();

    // Calculate the size of the popup window
    popup_width = (width - 100) * 0.8;
    popup_height = (height - 120) * 0.75;
    var left = (width - popup_width - 100) / 2;
    var top = (height - popup_height - 120) / 2;

    $(div_id).addClass('graph-popup')
             .css('top', top)
             .css('left', left)
             .css('width', popup_width)
             .css('height', popup_height)
             .css('z-index', 2000);
    
    switch (div_id) {
        case '#pie':
            var chart = $(div_id).highcharts();
            chart.setTitle({ text: g_title});
            chart.reflow();
            var opt = chart.series[0].options;
            opt.dataLabels.enabled = true;
            chart.series[0].update(opt);
            var title = '<?php echo lang("pie_chart"); ?>';
            break;
        <?php foreach($datasets as $dataset => $desc): ?>
        case '#<?php echo $dataset; ?>':
            var title = '<?php echo lang("chord_diagram"); ?> (<?php echo $desc; ?>)';
            break;
        <?php endforeach ?>
        default:
            break;
    }
    
    // Add close button to popup
    $(div_id).prepend('<i class="close-popup fa fa-close dl" title="<?php echo lang("close"); ?>"></i>');
    $(div_id).prepend('<span class="title-popup dl">'+title+'</span>');
}

function close_popup(div_id)
{
    var chart = $(div_id).highcharts();
    var w = $('.thumbnail').width();
    var h = 150;

    OPEN_POPUP = '';

    $(div_id).removeClass('graph-popup')
             .css('top', 0)
             .css('left', 0)
             .css('width', w)
             .css('height', h)
             .css('z-index', 999)
             .children('.dl').each(function(i,d) { $(d).remove(); });
    
    $('#bg-full').hide();

    switch(div_id) {
        case '#pie':
            chart.setTitle({text: ' '});
            chart.reflow();
            var opt = chart.series[0].options;
            opt.dataLabels.enabled = false;
            chart.series[0].update(opt);
            break;
        <?php foreach($datasets as $dataset => $garbage): ?>
        case '#<?php echo $dataset; ?>':
            
            break;
        <?php endforeach ?>
        default:
            break;
    }
}

function make_pie()
{
    var json = <?php echo $json; ?>;
    
    $(function () {
        
        $('#pie').highcharts({
            chart: {
                backgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                animation: false
            },
            credits: {
                enabled: false
            },
            title: {
                text: ' '
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    animation: false,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false,
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        },
                        connectorColor: 'silver',
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    }
                }
            },
            series: json
        });
    });
    
    if(json[0].data[0].name == null) {
        $('#highcharts-0').html('<div class="text-center"><?php echo lang("no_data"); ?></div>');
    }
}

function make_chord(agg2, h, w, title)
{

    var r1 = h / 2,
        r0 = r1 - 80;
    
    var fill = d3.scale.category20c();
    
    var chord = d3.layout.chord()
        .padding(.04)
        .sortSubgroups(d3.descending)
        .sortChords(d3.descending);

    var arc = d3.svg.arc()
        .innerRadius(r0)
        .outerRadius(r0 + 20);
    
    var svg = d3.select("#" + agg2).append("svg:svg")
        .attr("viewBox", "0 0 " + w + " " + h)
        .attr("width", "100%")
        .attr("height", "100%")
        .append("svg:g")
        .attr("transform", "translate(" + w / 2 + "," + (h / 2) + ")");
    window[agg2] = svg;
    
    d3.json('<?php echo site_url("{$apiurl}?{$chordquery}"); ?>' + "&agg2=" + agg2, function(imports) {
        
        var indexByName = {},
            nameByIndex = {},
            matrix = imports.matrix,
            labels = imports.names,
            diff = imports.diff,
            warning = imports.warning,
            n = 0;

        self.names = [];

        // Compute a unique index for each package name.
        labels.forEach(function(d) {
            if (!(d in indexByName)) {
                nameByIndex[n] = d;
                indexByName[d] = n++;
                names.push(d);
            }
        });

        chord.matrix(matrix);

        var g = svg.selectAll("g.group")
            .data(chord.groups)
            .enter().append("svg:g")
            .attr("class", "group")
            .on("mouseover", fade(.02))
            .on("mouseout", fade(.80));

        g.append("svg:path")
            .style("stroke", function(d) { return fill(d.index); })
            .style("fill", function(d) { return fill(d.index); })
            .attr("d", arc);

        g.append("svg:text")
            .each(function(d) { d.angle = (d.startAngle + d.endAngle) / 2; })
            .attr("dy", ".35em")
            .attr("text-anchor", function(d) { return d.angle > Math.PI ? "end" : null; })
            .attr("transform", function(d) {
                return "rotate(" + (d.angle * 180 / Math.PI - 90) + ")"
                    + "translate(" + (r0 + 26) + ")"
                    + (d.angle > Math.PI ? "rotate(180)" : "");
            })
            .attr("class", function(d) {
                return ((diff[d.index]) ? 'black' : 'gray') + " cursor-default"; })
            .text(function(d) { return nameByIndex[d.index]; });

        g.append("title").text(function(d) { return nameByIndex[d.index]; });

        svg.selectAll("path.chord")
            .data(chord.chords)
            .enter().append("svg:path")
            .attr("class", "chord")
            .style("stroke", function(d) { return d3.rgb(fill(d.source.index)).darker(); })
            .style("fill", function(d) { return fill(d.source.index); })
            .attr("d", d3.svg.chord().radius(r0));

        $('#' + agg2).children('.reportviz-throbber').hide();
        
        if (warning) {
            svg.append('text')
                .attr('x', width/2)
                .attr('y', 0 - (margin.top/2))
                .attr('text-anchor', 'middle')
                .style('font-size', '10px')
                .text('Dataset was truncated due to size.');
        }

    });

    // Returns an event handler for fading a given chord group.
    function fade(opacity) {
        return function(d, i) {
            svg.selectAll("path.chord")
                .filter(function(d) { return d.source.index != i && d.target.index != i; })
                .transition()
                .style("stroke-opacity", opacity)
                .style("fill-opacity", opacity);
        };
    }
}
</script>
