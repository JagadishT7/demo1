<?php echo $header; ?>

<ul class="breadcrumb <?php if (!empty($download)) { echo 'hide'; } ?>">
    <?php if ($type == 'sid') { ?>
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('sources/' . $source->sid); ?>"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></a> <span class="divider">/</span></li>
    <?php } else if ($type == 'gid') { ?>
    <li><a href="<?php echo site_url('groups'); ?>"><?php echo lang('header_tab_sourcegroups'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('groups/' . $group->gid); ?>"><?php echo lang('breadcrumb_sourcegroup'); ?> - <?php echo $group->name; ?></a> <span class="divider">/</span></li>
    <?php } ?>
    <li class="active"><?php echo lang('header_tab_reports'); ?></li>
</ul>

<script type='text/javascript'>
var crid = <?php echo $crid; ?>;
var cquery = <?php print json_encode($cquery); ?>;
var dates = {};
var resolve_hosts = <?php print $resolve_hosts; ?>;
var download = '<?php echo $download; ?>';

$(document).ready(function() {

    // Hide our divs
    $('#report_content').hide();
    $('#report_error').hide();
    $('#report_throbber').hide();

    var name = $('#custom_name');
    var top = $('input[name="top"]');
    var toptype = $('select[name="toptype"]');
    var toporder = $('select[name="toporder"]');
    var is_editable;
    var run_change = true;

    // Custom/Saved buttons
    $('#create_custom').click(function() {
        $('#report_list').hide();
        $(this).addClass('active');
        $('#saved_reports').removeClass('active');
        $('#create_custom_form').show();
        $('#edit_btn').hide();
        $('#delete_btn').hide();
        $('#timerange_span').appendTo($('#timerange_container'));
    });

    $('#saved_reports').click(function() {
        $('#create_custom_form').hide();
        $('#report_list').show();
        $(this).addClass('active');
        $('#create_custom').removeClass('active');
        $('#run_report_btn').trigger('click');
        if (is_editable == '1') { $('#delete_btn').show(); $('#edit_btn').show(); }
    });

    // Click save button
    $('#save_report_btn').click(function() {
        // If it needs to create a new one...
        if (!top.val()) {
                alert('<?php echo lang("report_modal_fill_out"); ?>');
        } else {
            // Name the report
            var save_name = prompt("<?php echo lang('report_modal_name'); ?>");
            if (save_name != '' && save_name != null) {
                dates = get_correct_datetimes();
                var vars = { 'q[name]':         save_name, 
                             'q[top]':          top.val(),
                             'q[toporder]':     toporder.val(),
                             'q[toptype]':      toptype.val(),
                             'q[begindate]':    dates.start,
                             'q[enddate]':      dates.end,
                             <?php echo get_csrf_block(); ?> }
                $.post(site_url + 'api/reports/create', vars, function(data) {
                    if (data.status == 'success') {
                        $('input[name="loaded_id"]').val(data.rid);
                        load_report_list();
                        $('#saved_reports').trigger('click');
                    } else {
                        alert(data.error);
                    }
                });
            } else {
                alert('<?php echo lang("report_modal_name_none"); ?>');
            }
        }
    });

    // Click edit button
    $('#edit_btn').click(function() {
        $('#edit_report').modal('show');
        $('#timerange_span').appendTo($('#edit_timerange_container'));
    });

    // Click save/update button
    $('#edit_report_btn').click(function() {
        var dates = get_correct_datetimes();
        var vars = { 'q[rid]': $('#rid').val(),
                     'u[name]': $('#edit_name').val(),
                     'u[top]': $('#edit_top').val(),
                     'u[toporder]': $('#edit_toporder').val(),
                     'u[toptype]': $('#edit_toptype').val(),
                     'u[begindate]': dates.start,
                     'u[enddate]': dates.end,
                     'u[rawquery]': $('#llimiter').val(),
                     <?php echo get_csrf_block(); ?> }
        $.post(site_url + 'api/reports/update', vars, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                $('#edit_report').modal('hide');
                $('#report_list').trigger('change');
            }
        });
    });

    // Delete button pressed
    $('#delete_btn').click(function() {
        // Check to make sure the person wants to delete
        var conf = confirm("<?php echo lang('report_delete_question'); ?>:\n" + $('input[name="loaded_name"]').val());
        // Do actual delete
        if (conf == true) {
            $.post(site_url + 'api/reports/delete', { 'q[rid]': $('input[name="loaded_id"]').val(), <?php echo get_csrf_block(); ?> }, function(data) {
                load_report_list();
                reset_all();
            });
        }
    });

    // Report changing
    $('#report_list').change(function() {
        // Load report information
        $.post(site_url + 'api/reports/read', { 'q[rid]': $('#report_list').val(), <?php echo get_csrf_block(); ?> }, function(data) {
            var report = data[0];
            $('input[name="loaded_id"]').val(report.rid);
            $('input[name="loaded_name"]').val(report.name);

            // Update edit area
            $('#rid').val(report.rid);
            $('#edit_name').val(report.name);
            $('#edit_top').val(report.top);
            $('#edit_toptype').val(report.toptype);
            $('#edit_toporder').val(report.toporder);
            $('#llimiter').val(report.rawquery);
            set_time_range(report.begindate, report.enddate);

            // If the report is able to be edited...
            is_editable = report.editable;
            if (is_editable == '1') {
                $('#delete_btn').show();
                $('#edit_btn').show();
            } else {
                $('#delete_btn').hide();
                $('#edit_btn').hide();
            }
            if(run_change == true) {
                $('#run_report_btn').trigger('click'); // Run the report
            }
            run_change = true;
        });
    });

    // Run report button
    $('#run_report_btn').click(function() {

        // Run the actual report
        loaded_id = $('input[name="loaded_id"]').val();
        var url = site_url;
        if ($('#create_custom').hasClass('active')) {
            var orderby = $('select[name="toporder"]').val();
            loaded_id = 0;
            $('#report-name').html('<?php echo lang("report_custom_title"); ?>');
            url += 'api/reports/execute_anonymous';
            dates = get_correct_datetimes();
            var vars = { 'q[top]':          $('input[name="top"]').val(),
                         'q[toporder]':     $('select[name="toporder"]').val(),
                         'q[toptype]':      $('select[name="toptype"]').val(),
                         'q[begindate]':    dates.start,
                         'q[enddate]':      dates.end,
                         <?php echo get_csrf_block(); ?> }

            // Create the description
            var desc = '<?php echo lang("report_custom_desc1"); ?> <strong>' + $('input[name="top"]').val() + '</strong> <?php echo lang("report_custom_desc2"); ?> <strong>' + human_readable_timerange(dates.start, dates.end) + '</strong> <?php echo lang("report_custom_desc3"); ?> <strong>' + human_readable_toptype($('select[name="toptype"]').val()) + '</strong> <?php echo lang("report_custom_desc4"); ?> <strong>' + $('select[name="toporder"]').val() + '</strong>.';
            $('#report-desc').html(desc);
        } else {
            $('#report-name').html($('input[name="loaded_name"]').val());
            url += 'api/reports/execute';
            var vars = { 'q[rid]': loaded_id, <?php echo get_csrf_block(); ?> };

            // Create the description
            $.post(site_url + 'api/reports/read', vars, function(data) {
                var report = data[0];
                var desc = '<?php echo lang("report_custom_desc1"); ?> <strong>' + report.top + '</strong> <?php echo lang("report_custom_desc2"); ?> <strong>' + human_readable_timerange(report.begindate, report.enddate) + '</strong> <?php echo lang("report_custom_desc3"); ?> <strong>' + human_readable_toptype(report.toptype) + '</strong> <?php echo lang("report_custom_desc4"); ?> <strong>' + report.toporder + '</strong>.';

                if (report.rawquery) {
                    desc += ' Limiting by "' + report.rawquery + '"';
                }
                
                $('#report-desc').html(desc);
            });
        }

        var oid = 0;
        var stype = "";
        if (type == 'sid') {
            vars['q[sid]'] = source_id;
            oid = source_id;
            stype = "source";
        } else if (type == 'gid') {
            vars['q[gid]'] = group_id;
            oid = group_id;
            stype = "sourcegroup";
        }
        
        if (view_id > 0) {
            vars['q[vid]'] = view_id;
        }
        
        // Create a link to download PDF version...
        var pdf_url = '';
        var i = 0;
        $.each(vars, function(k, v) {
            if (i != 0) { pdf_url += '&'; }
            pdf_url += k+'='+v;
            i++;
        });

        var download_pdf_url = site_url + 'download/report/'+stype+'/'+oid+'/'+ window.btoa(pdf_url);
        $('#download-pdf').attr('href', download_pdf_url);

        $.post(url, vars, function(data) {
            $('#report_warning').hide();

            if (!orderby) {
                orderby = data.toporder;
            }
            
            if(data.error) {
                clear_report();
                $('#errortext').html(data.error);
                $('#report_error').show();
            } else {

                // Display warning if it happens
                if (data.warning) {
                    $('#warningtext').html(data.warning);
                    $('#report_warning').show();
                }

                $('#report_error').hide();
                var actualvalues = ['srcip', 'dstip', 'dstport', 'srcport'];

                // Fill in data somehow
                var records = data.records;
                var summary = data.summary;
                var table = '';
                var head_table = '';

                // Check if there is any data displayed
                var empty_table = '';
                if (records.length <= 1) {
                    // Sorry! There's no data for this time period
                    empty_table += '<tr><td colspan="14"><?php echo lang("report_no_records"); ?></td></tr>';
                }

                $.each(records, function(k, record) {
                    if (k == 0) {
                        head_table = '<tr>';
                        $.each(record, function(key, value) {
                            var highlight = '';
                            if (key == orderby) {
                                highlight = ' class="highlight"';
                            } else {
                                highlight = ' class="h-'+key+'"';
                            }
                            head_table += '<th' + highlight + '>' + human_readable_headers(key) + '</th>';
                        });
                        head_table += '</tr>';
                    } else {
                        table += '<tr>';
                        $.each(record, function(key, value) {

                            if (key == 'srcdn' || key == 'dstdn') {
                                return;
                            }

                            var bar = '';
                            if (key == 'bytes' || key == 'flows' || key == 'packets') {
                                
                                // create the bottom bar
                                var percent = (parseFloat(value) / parseFloat(summary[key])) * 100.0;
                                bar = '<div class="line-bar-container"><div class="line-bar" style="width: ' +  percent + '%;"></div></div>';

                                if (key == 'bytes') { value = human_readable_size(value); }

                            } else if (key == 'duration') {
                                value = parseInt(value);
                            } else if (actualvalues.indexOf(key) != -1) {
                                var complement = get_complement(key);
                                var queryurl = get_tt_query_url(key, complement, value);

                                title = "";
                                if (resolve_hosts) {
                                    title = value;
                                    if (key == 'srcip') {
                                        value = record['srcdn'];
                                    } else if (key == 'dstip') {
                                        value = record['dstdn'];
                                    }
                                }

                                value = '<a href="' + queryurl + '" title="' + title + '">' + value + '</a>';
                            }

                            var highlight = '';
                            if (key == orderby) {
                                highlight = ' class="highlight"'
                            }

                            table += '<td' + highlight + '>' + value + bar + '</td>';
                        });
                        table += '</tr>';
                    }
                });
                table += empty_table; // if nothing was returned

                if (apiaccess)
                {
                    // Get ids in url
                    var idurl;
                    if (type == 'sid') {
                        idurl = '&q[sid]=' + source_id;
                    } else if (type == 'gid') {
                        idurl = '&q[gid]=' + group_id;
                    }

                    if (view_id) { idurl += '&q[vid]=' + view_id; }

                    var uhtml = '';
                    var command = '';
                    if (loaded_id > 0) {
                        // Create report id api button
                        uhtml += 'q[rid]=' + loaded_id + idurl;
                        command = 'execute';
                    } else {
                        // Create annonymous report button
                        command = 'execute_anonymous';
                        uhtml += 'q[top]=' + $('input[name="top"]').val();
                        uhtml += '&q[toporder]=' + $('select[name="toporder"]').val();
                        uhtml += '&q[toptype]=' + $('select[name="toptype"]').val();
                        uhtml += '&q[begindate]=' + dates.start + '&q[enddate]=' + dates.end;
                        uhtml += idurl;
                    }

                    var api_btn_url = site_url + 'api/reports/' + command + '?' + uhtml + '&token=' + apikey;
                    var api_run_button = '<a href="' + api_btn_url + '" target="_blank" class="btn"><i class="icon-share-alt"></i> <?php echo lang("external_api"); ?></a>';
                    var api_show_button = '<a href="#" class="show_api btn" style="margin-left: 8px;"><i class="icon-info-sign"></i> <?php echo lang("api_show"); ?></a>';
                    $('#external-link').html(api_run_button + api_show_button);

                    // Set api data examples
                    $('#api_example_url').html(api_btn_url);
                    $('#api_example_curl').html("$ curl --data '" + uhtml + "&token=" + apikey + "' " + site_url + 'api/reports/' + command);

                    // Show api button
                    $('.show_api').click(function() {
                        $('#show_api_mode').modal('show');
                    });
                }

                $('#report-table-head').html(head_table);
                $('#report-table').html(table);

                var vizurl = site_url + 'reports/reportviz';
                var vizargs = { token: apikey, <?php echo get_csrf_block(); ?> };
                
                /* If this is a custom report, just send all the args */
                if($('#create_custom').hasClass('active')) {
                    vizargs['q[top]'] = $('input[name="top"]').val();
                    vizargs['q[toporder]'] = $('select[name="toporder"]').val();
                    vizargs['q[toptype]'] = $('select[name="toptype"]').val();
                    vizargs['q[begindate]'] = dates.start;
                    vizargs['q[enddate]'] = dates.end;
                } else {
                    vizargs.rid = loaded_id;
                }

                if (type == 'sid') {
                    vizargs.sid = source_id;
                } else if (type == 'gid') {
                    vizargs.gid = group_id;
                }

                // Add view id if it exists
                if (view_id) {
                    vizargs.vid = view_id;
                }
                $('#reportviz').load(vizurl, vizargs);
            }
        })
        .complete(function() {
            $('#report_content').show();
            $('#report_throbber').hide();

            if (view_id > 0) {
                if (download == '1') {
                    $.post(site_url + 'api/views/get_views', { 'q[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
                        var view_name = 'Unknown';
                        $.each(views, function(k, v) {
                            if (v.vid == view_id) {
                                view_name = v.name;
                            }
                        });
                        var view_html = "<?php echo lang('running_on_view'); ?>: <strong>"+view_name+"</strong>";
                        $('#view-desc').html(view_html);
                    });
                }
            }
        });

    });

    // Do initial stuff
    if (cquery == null && crid == null) {
        load_report_list();
    } else if (crid != null) {
        run_change = false;
        load_report_list();
        $.post(site_url + 'api/reports/read', { 'q[rid]': crid, <?php echo get_csrf_block(); ?> }, function(data) {
            var report = data[0];
            $('input[name="loaded_id"]').val(report.rid);
            $('input[name="loaded_name"]').val(report.name);
            $('#report_list').val(crid);
            $('#run_report_btn').trigger('click');
        });
    } else {
        if (cquery.rid) {
            run_change = false;
            load_report_list();
            $.post(site_url + 'api/reports/read', { 'q[rid]': cquery.rid, <?php echo get_csrf_block(); ?> }, function(data) {
                var report = data[0];
                $('input[name="loaded_id"]').val(report.rid);
                $('input[name="loaded_name"]').val(report.name);
                $('#report_list').val(cquery.rid);
                $('#run_report_btn').trigger('click');
            });
        } else {
            run_change = false;
            load_report_list();
            $('#create_custom').trigger('click');
            $('select[name="toptype"]').val(cquery.toptype);
            $('input[name="top"]').val(cquery.top);
            $('select[name="toporder"]').val(cquery.toporder);
            set_time_range(cquery.begindate, cquery.enddate);
            $('#run_report_btn').trigger('click');
        }
    }
});

function report_highlight(name) {
    $('.h-'+name).addClass('highlight');
}

function clear_report()
{
    $('#report-table-head').html('');
    $('#report-table').html('<tr><td><?php echo lang("no_data"); ?></td></tr>');
    $('#report-name').html('');
    $('#report-desc').html('');
    $('#external-link').html('');
    $('#reportviz').html('');
}
</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="row-fluid <?php if (!empty($download)) { echo 'hide'; } ?>">
        <div class="span12">
            <div style="margin-bottom: 20px; border-bottom: 1px solid #DDD; padding: 10px 0;">
                <div class="form-horizontal" style="line-height: 50px;">
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary" id="create_custom"><?php echo lang('report_generic_custom'); ?></button>
                        <button type="button" class="btn btn-primary active" id="saved_reports"><?php echo lang('report_generic_saved'); ?></button>
                    </div>
                    <select class="input-xxlarge" id="report_list"></select>
                    <input type="hidden" name="loaded_id" value="0">
                    <input type="hidden" name="loaded_name" value="">
                    <span id="create_custom_form" style="display: none;">
                        <?php echo lang('report_custom_desc1'); ?>
                        <input type="text" style="width: 25px;" name="top" class="tt_bind" title="<?php echo lang('report_generic_piechart'); ?>">
                        <?php echo lang('report_custom_desc2'); ?>
                        <span id="timerange_container">
                            <span id="timerange_span">
                                <select id="timerange" style="width: 185px;">
									<option value="2h"><?php echo lang('timerange_2hrs'); ?></option>
                                    <option value="4h"><?php echo lang('timerange_4hrs'); ?></option>
                                    <option value="6h"><?php echo lang('timerange_6hrs'); ?></option>
                                    <option value="12h"><?php echo lang('timerange_12hrs'); ?></option>
                                    <option value="24h"><?php echo lang('timerange_24hrs'); ?></option>
                                    <option value="2d"><?php echo lang('timerange_2days'); ?></option>
                                    <option value="1w"><?php echo lang('timerange_week'); ?></option>
                                    <option value="1m"><?php echo lang('timerange_month'); ?></option>
                                    <option value="range"><?php echo lang('timerange_custom_range'); ?></option>
                                    <option value="elapsed"><?php echo lang('timerange_custom_elapsed'); ?></option>
                                </select>
                                <span id="range_inputs" class="hide">
                                    <input type="text" class="input-datetime" id="range_start">
                                    to
                                    <input type="text" class="input-datetime" id="range_end">
                                </span>
                                <span id="elapsed_inputs" class="hide">
                                    <input type="text" value="2 hours" title="<?php echo lang('timerange_elsapsed_desc'); ?>" class="input-small tt_bind" id="elapsed_start">
                                    ago,
                                    <input type="hidden" value="1 second" class="input-small" id="elapsed_end">
                                </span>
                            </span>
                        </span>
                        <?php echo lang('report_custom_desc3'); ?>
                        <select name="toptype" class="input-medium">
                            <option value="srcip"><?php echo lang('source_ip'); ?></option>
                            <option value="dstip"><?php echo lang('destination_ip'); ?></option>
                            <!--<option value="ip">Any IP</option>-->
                            <option value="srcport"><?php echo lang('source_port'); ?></option>
                            <option value="dstport"><?php echo lang('destination_port'); ?></option>
                            <!--<option value="port">Any Port</option>-->
                        </select>
                        <?php echo lang('report_custom_desc4'); ?>
                        <select name="toporder" class="input-medium">
                            <option value="flows"><?php echo lang('flows'); ?></option>
                            <option value="packets"><?php echo lang('packets'); ?></option>
                            <option value="bytes"><?php echo lang('bytes'); ?></option>
                            <!--<option value="pps">Packets/Sec</option>
                            <option value="bps">Bits/Sec</option>
                            <option value="bpp">Bits/Packet</option>-->
                        </select>
                        <?php if ($is_admin) { ?>
                            <button type="button" class="btn" id="save_report_btn"><i class="icon-download-alt"></i> <?php echo lang('save_button'); ?></button>
                        <?php } ?>
                    </span>
                    <?php if ($is_admin) { ?>
                    <button type="button" class="btn hide" id="edit_btn"><i class="icon-edit"></i> <?php echo lang('edit'); ?></button>
                    <button type="button" class="btn hide" id="delete_btn"><i class="icon-trash"></i> <?php echo lang('delete'); ?></button>
                    <?php } ?>
                    <button type="button" class="btn btn-primary" id="run_report_btn"><?php echo lang('report_generic_run'); ?> <i class="icon-chevron-right icon-white"></i></button>
                    <a href="" id="download-pdf" class="btn btn-default" target="_blank" title="<?php echo lang('download_pdf'); ?>"><i class="fa fa-file-pdf-o"></i> PDF</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row-fluid" id="report_throbber">
        <div class="span12 centerme" style="margin-top:20px;">
            <img src='/nagiosna/media/images/ajax-loader.gif'>
        </div>
    </div>
    <div class="row-fluid" id="report_error">
        <div class="span8 offset2" style="margin-top:20px;">
            <div class="alert alert-error alert-block" id="errortext">
            </div>
        </div>
    </div>
    <div class="row-fluid hide" id="report_warning">
        <div class="span12">
            <div class="alert alert-warning alert-block" id="warningtext" style="text-align: center;"></div>
        </div>
    </div>
    <div class="report_content">
        <div id='reportviz'></div>
        <div id='reportresultstable'>
            <div class="row-fluid">
                <div class="span12">
                    <h3 id="report-name" style="margin: 0;"></h3>
                </div>
            </div>
            <div class="row-fluid">
                <div class="span8">
                    <p id="view-desc"></p>
                    <p id="report-desc" <?php if (empty($download)) { echo 'style="line-height: 30px;"'; } ?>></p>
                </div>
                <div class="span4 <?php if (!empty($download)) { echo 'hide'; } ?>" style="text-align: right;">
                    <p id="external-link"></p>
                </div>
            </div>
            <div class="row-fluid">
                <div class="span12">
                    <table class="table table-bordered table-striped" style="margin-bottom: 0;">
                        <thead id="report-table-head">
                        </thead>
                        <tbody id="report-table">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Custom Report Modal -->
<div id="edit_report" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang('report_generic_modal_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('report_generic_modal_desc'); ?></p>
        <div id="error" class="alert alert-error hide"></div>
            <table>
                <tr>
                    <td class="form-left" style="width: 150px;"><?php echo lang('report_generic_modal_name'); ?>:</td>
                    <td><input type="text" class="input-xlarge" id="edit_name" disabled></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_generic_modal_top'); ?> #:</td>
                    <td><input type="text" style="width: 25px;" id="edit_top" data-toggle="tooltip" title="<?php echo lang('report_generic_piechart'); ?>"></td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_generic_modal_range'); ?>:</td>
                    <td id="edit_timerange_container">
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_generic_modal_group'); ?>:</td>
                    <td>
                        <select id="edit_toptype" class="input-medium">
                            <option value="srcip"><?php echo lang('source_ip'); ?></option>
                            <option value="dstip"><?php echo lang('destination_ip'); ?></option>
                            <!--<option value="ip">Any IP</option>-->
                            <option value="srcport"><?php echo lang('source_port'); ?></option>
                            <option value="dstport"><?php echo lang('destination_port'); ?></option>
                            <!--<option value="port">Any Port</option>-->
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_generic_modal_order'); ?>:</td>
                    <td>
                        <select id="edit_toporder" class="input-medium">
                            <option value="flows"><?php echo lang('flows'); ?></option>
                            <option value="packets"><?php echo lang('packets'); ?></option>
                            <option value="bytes"><?php echo lang('bytes'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="form-left"><?php echo lang('report_home_modal_limiter'); ?>:</td>
                    <td><input type="text" id="llimiter" placeholder="ip 192.168.0.1"> <i class="icon-question-sign tt_bind" title="<?php echo lang('report_home_modal_limiter_desc'); ?>"></i></td>
                </tr>
            </table>     
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="rid">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
        <a href="#" id="edit_report_btn" class="btn btn-primary"><?php echo lang('update_button'); ?></a>
    </div>
</div>

<!-- Show run from API modal -->
<div id="show_api_mode" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang("show_api_header"); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('show_api_body'); ?></p>
        <h5>GET Example:</h5>
        <pre id="api_example_url"></pre>
        <h5>POST Example:</h5>
        <pre id="api_example_curl"></pre>
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="rid">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('close'); ?></a>
    </div>
</div>

<?php if (empty($download)) { echo $footer; } ?>