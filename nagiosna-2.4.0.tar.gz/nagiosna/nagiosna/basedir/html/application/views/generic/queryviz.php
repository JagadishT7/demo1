<div width='100%'>
    <ul class='thumbnails'>
        <li>
            <div class='thumbnail' style='width:300px;'>
                <div id='relationaltarget' class="chartrender">
                    <div class='reportviz-throbber'>
                        <div class='valign-throbber centerme'>
                            <img src='/nagiosna/media/images/ajax-loader.gif'>
                        </div>
                    </div>
                </div>
                <div style="margin-bottom: 10px;">
                    <a class='btn btn-small fullscreen-button' id='queryvizfullscreener' data='#relationaltarget'><i class='icon-resize-full'></i></a>
                    <strong><?php echo lang('chord_diagram'); ?></strong>
                </div>
            </div>
        </li>
    </ul>
</div>
<div id="bg-full"></div>

<script>
var OPEN_POPUP = '';

$(document).ready(function() {
    
    make_chord(600, 900, '<?php echo lang("chord_diagram"); ?>');
    
    $('.fullscreen-button').click(function() {
        resize_to_fullscreen(this);
    });

    $(window).resize(function() {
        resize_bg_full();
        resize_open_popup();
    });

    $('#bg-full').click(function() {
        close_popup(OPEN_POPUP);
    });

    $('body').on('click', '.close-popup', function() {
        close_popup(OPEN_POPUP);
    });

});

function resize_open_popup()
{
    if (OPEN_POPUP == '') { return; }
    var div_id = OPEN_POPUP;
    var width = $(window).width();
    var height = $(window).height();

    // Calculate the size of the popup window
    popup_width = (width - 100) * 0.8;
    popup_height = (height - 120) * 0.75;
    var left = (width - popup_width - 100) / 2;
    var top = (height - popup_height - 120) / 2;

    $(div_id).css('top', top)
             .css('left', left)
             .css('width', popup_width)
             .css('height', popup_height);
}

function resize_to_fullscreen(node)
{    
    var div_id = $(node).attr('data');
    var width = $(window).width();
    var height = $(window).height();

    // Set open popup
    OPEN_POPUP = div_id;

    resize_bg_full();
    $('#bg-full').show();

    // Calculate the size of the popup window
    popup_width = (width - 100) * 0.8;
    popup_height = (height - 120) * 0.75;
    var left = (width - popup_width - 100) / 2;
    var top = (height - popup_height - 120) / 2;

    $(div_id).addClass('graph-popup')
             .css('top', top)
             .css('left', left)
             .css('width', popup_width)
             .css('height', popup_height)
             .css('z-index', 2000);
    
    // Add close button to popup
    $(div_id).prepend('<i class="close-popup fa fa-close dl" title="<?php echo lang("close"); ?>"></i>');
    $(div_id).prepend('<span class="title-popup dl"><?php echo lang("chord_diagram"); ?></span>');
}

function close_popup(div_id)
{
    var chart = $(div_id).highcharts();
    var w = $('.thumbnail').width();
    var h = 150;

    OPEN_POPUP = '';

    $(div_id).removeClass('graph-popup')
             .css('top', 0)
             .css('left', 0)
             .css('width', w)
             .css('height', h)
             .css('z-index', 999)
             .children('.dl').each(function(i,d) { $(d).remove(); });
    
    $('#bg-full').hide();
}

function make_chord(h, w, title)
{
    var r1 = h / 2,
        r0 = r1 - 80;
    
    var fill = d3.scale.category20c();
    
    var chord = d3.layout.chord()
        .padding(.04)
        .sortSubgroups(d3.descending)
        .sortChords(d3.descending);

    var arc = d3.svg.arc()
        .innerRadius(r0)
        .outerRadius(r0 + 20);
    
    var svg = d3.select("#relationaltarget").append("svg:svg")
        .attr("viewBox", "0 0 " + w + " " + h)
        .attr("width", "100%")
        .attr("height", "100%")
        .append("svg:g")
        .attr("transform", "translate(" + w / 2 + "," + (h / 2) + ")");
    
    d3.json('<?php echo site_url("{$apiurl}?{$apiquery}"); ?>', function(imports) {
    
        if (imports.names.length == 1 && imports.names[0] == 'Other') {
            $('#relationaltarget').children('.reportviz-throbber').hide();
            $('#relationaltarget').html('<p style="margin-top:40px;" class="text-center"><?php echo lang("no_data"); ?></p>');
            return;
        }
        
        var indexByName = {},
            nameByIndex = {},
            matrix = imports.matrix,
            labels = imports.names,
            denote = imports.denote,
            n = 0;

        self.names = [];

        // Returns the Flare package name for the given class name.
        function name(name) {
            return name.substring(0, name.lastIndexOf(".")).substring(6);
        }

        // Compute a unique index for each package name.
        labels.forEach(function(d) {
            if (!(d in indexByName)) {
                nameByIndex[n] = d;
                indexByName[d] = n++;
                names.push(d);
            }
        });

        chord.matrix(matrix);

        var g = svg.selectAll("g.group")
            .data(chord.groups)
            .enter().append("svg:g")
            .attr("class", "group")
            .on("mouseover", fade(.02))
            .on("mouseout", fade(.80));

        g.append("svg:path")
            .style("stroke", function(d) { return fill(d.index); })
            .style("fill", function(d) { return fill(d.index); })
            .attr("d", arc);

        g.append("svg:text")
            .each(function(d) { d.angle = (d.startAngle + d.endAngle) / 2; })
            .attr("dy", ".35em")
            .attr("text-anchor", function(d) { return d.angle > Math.PI ? "end" : null; })
            .attr("transform", function(d) {
                return "rotate(" + (d.angle * 180 / Math.PI - 90) + ")"
                    + "translate(" + (r0 + 26) + ")"
                    + (d.angle > Math.PI ? "rotate(180)" : "");
            })
            .text(function(d) { return nameByIndex[d.index]; })
            .style(function(d) { return "color", "red" });

        g.append("title").text(function(d) { return nameByIndex[d.index]; });

        svg.selectAll("path.chord")
            .data(chord.chords)
            .enter().append("svg:path")
            .attr("class", "chord")
            .style("stroke", function(d) { return d3.rgb(fill(d.source.index)).darker(); })
            .style("fill", function(d) { return fill(d.source.index); })
            .attr("d", d3.svg.chord().radius(r0));
          
        $('#relationaltarget').children('.reportviz-throbber').hide();

    });

    // Returns an event handler for fading a given chord group.
    function fade(opacity) {
        return function(d, i) {
            svg.selectAll("path.chord")
                .filter(function(d) { return d.source.index != i && d.target.index != i; })
                .transition()
                .style("stroke-opacity", opacity)
                .style("fill-opacity", opacity);
        };
    }
}
</script>