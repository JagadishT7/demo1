<div class='summaryvizcontainer' id='src-summary-<?php echo $sid; ?>-inner'></div>

<script>
var sid = '<?php echo $sid; ?>';
draw_summary('#src-summary-' + sid + '-inner', sid);
</script>
