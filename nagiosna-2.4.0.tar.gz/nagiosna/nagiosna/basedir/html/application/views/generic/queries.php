<?php echo $header; ?>

<ul class="breadcrumb <?php if (!empty($download)) { echo 'hide'; } ?>">
    <?php if ($type == 'sid') { ?>
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('sources/' . $source->sid); ?>"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></a> <span class="divider">/</span></li>
    <?php } else if ($type == 'gid') { ?>
    <li><a href="<?php echo site_url('groups'); ?>"><?php echo lang('header_tab_sourcegroups'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('groups/' . $group->gid); ?>"><?php echo lang('breadcrumb_sourcegroup'); ?> - <?php echo $group->name; ?></a> <span class="divider">/</span></li>
    <?php } ?>
    <li class="active"><?php echo lang('header_tab_queries'); ?></li>
</ul>

<script type="text/javascript">

var qid = <?php if ($cqid != 'null') { echo intval($cqid); } else if (!empty($cquery['qid'])) { echo intval($cquery['qid']); } else { echo 'null'; } ?>;
var loaded_name = '';
var LATEST_QUERY_GLOBAL;
var ag = '<?php echo $cquery['aggregate_csv']; ?>';
var begindate = '<?php echo $cquery['begindate']; ?>';
var enddate = '<?php echo $cquery['enddate']; ?>';
var rawquery = '<?php echo $cquery['rawquery']; ?>';
var PERPAGE = <?php if (empty($download)) { echo '20'; } else { echo '9999999'; } ?>;
var PAGINATION_LOOKAHEAD = 10;
var PAGINATION_LOOKBEHIND = 10;
var PAGINATION_TOTAL = 15;
var SORTING;
var SORTCLASS;
var PAGES;
var CURRENT_PAGE;
var QUERY_LIST;
var resolve_hosts = <?php print $resolve_hosts; ?>;
var download = '<?php echo $download; ?>';

$(document).ready(function() {
    
    $('#query_error').hide();
    $('#query_throbber').hide();
    $('#query_content').hide();

    if (qid != null) {
        load_query_using_qid();
    }

    $('#load_query_button').click(function() {
        load_queries_list();
        $('#load-modal').modal('show');
    });

    $('#load-modal-yes').click(function() {
        qid = $('#query_list').val();
        load_query_using_qid();
    });

    $('#clear_button').click(function() {
        clear_all();
    });
    
    $('.addtoquery').click(function() {
        var agp = $(this).attr('alt');
        var ag = $('#ag').val();
        
        if(ag.indexOf(agp) == -1) {
            $('#ag').val(ag + ',' + agp);
        }
        
        $('#run_query').trigger('click');
    });
    
    $('.queryclickable').click(function() {
        var agp = $(this).attr('alt');
        var data = $(this).attr('data');
        alert(data);
    });

    $('#query_list').change(function() {
        $('#query_desc_row').hide();
        var query = QUERY_LIST[$(this).val() - 1];
        try {
            if (query.description != '') {
                $('#query_desc_row').show();
                $('#query_desc').html(query.description);
            }
        } catch (err) {
            // Do nothing
        }
    });

    $('#save_query_button').click(function() {

        // If query is new or not
        if (qid == '' || qid < 1) {
            // Create a new query and save it
            $('#save-modal').modal('show');
        } else {
            // Update query
            var url = site_url + 'api/queries/update';
            dates = get_correct_datetimes();
            loaded_name = $('#query_title').val();
            var vars = { 'q[qid]': qid,
                         'u[name]': loaded_name,
                         'u[begindate]': dates.start,
                         'u[enddate]': dates.end,
                         'u[aggregate_csv]': $('#ag').val(),
                         'u[rawquery]': $('#rawquery').val(),
                         <?php echo get_csrf_block(); ?> }
            $.post(url, vars, function(data) {
                if (data.status == "success") {
                    alert('<?php echo lang("query_generic_save"); ?>');
                } else {
                    alert(data.error);
                }
            });
        }
    });

    // Save query modal button save function
    $('#save-modal-yes').click(function() {
        var name = $('#save_name').val();
        var desc = $('#save_desc').val();
        if (name != null && name != "") {
            dates = get_correct_datetimes();
            var vars = { 'q[name]':          name,
                         'q[description]':   desc, 
                         'q[begindate]':     dates.start,
                         'q[enddate]':       dates.end,
                         'q[aggregate_csv]': $('#ag').val(),
                         'q[rawquery]':      $('#rawquery').val(),
                         <?php echo get_csrf_block(); ?> }
            var url = site_url + 'api/queries/create';
            $.post(url, vars, function(data) {
                // Return success?
                if (data.status == "success") {
                    qid = data.qid;
                    $('#save-modal').modal('hide');
                    load_query_using_qid();
                } else {
                    alert(data.error);
                }
            });
        }
    });
    
    $('#delete_query_button').click(function() {
        var conf = confirm("<?php echo lang('query_generic_delete'); ?>:\n\n" + loaded_name + "\n\n<?php echo lang('query_generic_delete_end'); ?>");
        if (conf === true) {
            // Do delete
            $.post(site_url + 'api/queries/delete', { 'q[qid]': qid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status == "success") {
                    clear_all();
                } else {
                    alert(data.error);
                }
            })
        }
    });

    $('#run_query').click(function() {
        
        $('#query_content').hide();
        $('#query_error').hide();
        $('#query_warning').hide();

        var rq = $('#rawquery').val();
        var ag = $('#ag').val();

        // Get dates
        dates = get_correct_datetimes();

        // Make sure the query has all the pieces
        if (dates.start == '' || dates.end == '') {
            alert('<?php echo lang("query_generic_no_timerange"); ?>');
            return;
        } else if (ag == '') { 
            alert('<?php echo lang("query_generic_no_ag"); ?>');
            return;
        }
        
        $('#query_throbber').show();

        // Run the actual query
        var url = site_url;
        //console.log(qid);
        if (qid < 1 || $('#custom_query').hasClass('active')) {
            url += 'api/queries/execute_anonymous';
            var vars = { 'q[begindate]':     dates.start,
                         'q[enddate]':       dates.end,
                         'q[aggregate_csv]': ag,
                         'q[rawquery]':      rq,
                         <?php echo get_csrf_block(); ?> }
            var title = 'Custom Query';
        } else {
            url += 'api/queries/execute';
            var vars = { 'q[qid]': qid, <?php echo get_csrf_block(); ?> };
            var title = loaded_name
        }

        var oid = 0;
        var stype = "";
        if (type == 'sid') {
            vars['q[sid]'] = source_id;
            oid = source_id;
            stype = "source";
        } else if (type == 'gid') {
            vars['q[gid]'] = group_id;
            oid = group_id;
            stype = "sourcegroup";
        }

        // Add in the view
        if (view_id) {
            vars['q[vid]'] = view_id;
        }

        // Create a link to download PDF version...
        var pdf_url = '';
        var i = 0;
        $.each(vars, function(k, v) {
            if (i != 0) { pdf_url += '&'; }
            pdf_url += k+'='+v;
            i++;
        });

        var download_pdf_url = site_url + 'download/query/'+stype+'/'+oid+'/'+ window.btoa(pdf_url);
        $('#download-pdf').attr('href', download_pdf_url);
        $('#download-pdf').show();

        $.post(url, vars, function(data) {
            
            if(data.error) {
                $('#errortext').html(data.error);
                $('#query_error').show();
            } else {

                // Display warning if it happens
                if (data.warning) {
                    $('#warningtext').html(data.warning);
                    $('#query_warning').show();
                }

                // Set the query to a global
                LATEST_QUERY_GLOBAL = data;
                
                // Render the summary
                render_summary('#query_summary', data.summary, title);

                // Render the actual data
                initialize_flowdata_div('#query_flowdata', data.records);
            }
        })
        .done(function() {
            $('#query_throbber').hide();
            if(!$('#query_error').is(':visible'))  {
                $('#query_content').show();
            }

            // Create an external api url
            if (apiaccess)
            {
                // Get ids in url
                var idurl;
                if (type == 'sid') {
                    idurl = '&q[sid]=' + source_id;
                } else if (type == 'gid') {
                    idurl = '&q[gid]=' + group_id;
                }

                if (view_id) { idurl += '&q[vid]=' + view_id; }

                var uhtml = '';
                var command = '';
                if (qid > 0) {
                     // Create report id api button
                    uhtml += 'q[qid]=' + qid + idurl;
                    command = 'execute';
                } else {
                    // Create annonymous report button
                    command = 'execute_anonymous';
                    uhtml += 'q[aggregate_csv]=' + $('#ag').val();
                    uhtml += '&q[rawquery]=' + $('#rawquery').val();
                    uhtml += '&q[begindate]=' + dates.start + '&q[enddate]=' + dates.end;
                    uhtml += idurl;
                }

                var api_btn_url = site_url + 'api/queries/' + command + '?' + uhtml + '&token=' + apikey;
                var api_run_button = '<a href="' + api_btn_url + '" target="_blank" class="btn"><i class="icon-share-alt"></i> <?php echo lang("external_api"); ?></a>';
                var api_show_button = '<a href="#" class="show_api btn" style="margin-left: 8px;"><i class="icon-info-sign"></i> <?php echo lang("api_show"); ?></a>';
                $('#external-link').html(api_run_button + api_show_button);

                // Set api data examples
                $('#api_example_url').html(api_btn_url);
                $('#api_example_curl').html("$ curl --data '" + uhtml + "&token=" + apikey + "' " + site_url + 'api/queries/' + command);

                // Show api button
                $('.show_api').click(function() {
                    $('#show_api_mode').modal('show');
                });

                // Create the description
                var desc = '<?php echo lang("showing"); ?> <strong>' + human_readable_timerange(dates.start, dates.end) + '</strong> <?php echo lang("for_query"); ?> "<strong>' + $('#rawquery').val() + '</strong>" <?php echo lang("aggregated_by"); ?> <strong>' + $('#ag').val() + '</strong>.';
                $('#query-desc').html(desc);
            }

            if (view_id > 0) {
                if (download == '1') {
                    $.post(site_url + 'api/views/get_views', { 'q[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
                        var view_name = 'Unknown';
                        $.each(views, function(k, v) {
                            if (v.vid == view_id) {
                                view_name = v.name;
                            }
                        });
                        var view_html = "<?php echo lang('running_on_view'); ?>: <strong>"+view_name+"</strong>";
                        $('#view-desc').html(view_html);
                    });
                }
            }

        }) /* Closes the post function */
        
        var vizurl = site_url + 'queries/queryviz';
        vars['qid'] = vars['q[qid]'];
        vars['sid'] = vars['q[sid]'];
        vars['gid'] = vars['q[gid]'];
        delete vars['q[sid]'];
        delete vars['q[gid]'];
        delete vars['q[qid]'];
        $('#visualization').load(vizurl, vars);
        
    })
    
    // If we were passed a cquery, it will go here, populating the proper
    // fields and settting off the click on run_query.
    <?php if(empty($cquery) === FALSE): ?>
    
    // Fill in all the passed values
    set_time_range(begindate, enddate);
    $('#ag').val(ag);
    $('#rawquery').val(rawquery);
    
    // Set the sentinel value, to allow a custom query to be run
    qid = 0;
    // Set the title to 'Custom Query'
    loaded_name = '<?php echo lang("query_generic_default_name"); ?>';
    
    // Run the query
    $('#run_query').trigger('click');
    <?php endif; ?>
    
    $('.custom-field').change(function() {
        qid = 0;
        $('#loaded_query_container').hide();
    });
    
    $('.sortby').click(function() {
        
        // Toggleable up and down sorting
        var sorting = $(this).attr('alt');
        SORTCLASS = $(this).attr('data');
        if(SORTING == undefined || SORTING.by != sorting) {
            $('.sortindicator').each(function(i, d) {
                $(d).removeClass('icon-chevron-down');
                $(d).removeClass('icon-chevron-up');
            });
            SORTING = {}
            SORTING.by = sorting;
            SORTING.order = 'descending';
            method = function(a,b) {return b[sorting] - a[sorting]};
            $(this).children('.sortindicator').each(function(i, d) {
                $(d).addClass('icon-chevron-down');
            });
        } else if(SORTING.by == sorting) {
            if(SORTING.order == 'ascending') {
                SORTING.order = 'descending';
                method = function(a,b) {return b[sorting] - a[sorting]};
                $(this).children('.sortindicator').each(function(i, d) {
                    $(d).removeClass('icon-chevron-up');
                    $(d).addClass('icon-chevron-down');
                });
            } else {
                SORTING.order = 'ascending';
                method = function(a,b) {return a[sorting] - b[sorting]};
                $(this).children('.sortindicator').each(function(i, d) {
                    $(d).removeClass('icon-chevron-down');
                    $(d).addClass('icon-chevron-up');
                });
            }
        }
        
        LATEST_QUERY_GLOBAL.sort(method);
        fill_flowdata_proper(0);
    });

});

</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="row-fluid pretty-bottom <?php if (!empty($download)) { echo 'hide'; } ?>">
        <div class="span12">
            <div class="form-holder-query">
                <div class="form-horizontal">
                    <table>
                        <tr>
                            <td colspan="3" style="padding-bottom: 6px;">
                                <div class="hide" id="loaded_query_container" style="padding-bottom: 8px;">
                                    <?php echo lang('query_generic_loaded'); ?>: <input type="text" class="input-xlarge" id="query_title">
                                    <button type="button" class="btn" id="clear_button"><i class="icon-file"></i> <?php echo lang('clear'); ?></button>
                                    <?php if ($is_admin) { ?>
                                    <button type="button" class="btn btn-danger" id="delete_query_button" style="margin-right: 15px;"><i class="icon-trash icon-white"></i> <?php echo lang('delete'); ?></button>
                                    <?php } ?>
                                </div>
                                <?php echo lang('query_generic_ag'); ?>: <input type="text" id="ag" class="field tt_bind custom-field" title="<?php echo lang('query_generic_ag_desc'); ?>">
                                <?php echo lang('query_generic_tf'); ?>:
                                <select id="timerange" class="custom-field" style="width: 185px;">
									<option value="2h"><?php echo lang('timerange_2hrs'); ?></option>
                                    <option value="4h"><?php echo lang('timerange_4hrs'); ?></option>
                                    <option value="6h"><?php echo lang('timerange_6hrs'); ?></option>
                                    <option value="12h"><?php echo lang('timerange_12hrs'); ?></option>
                                    <option value="24h"><?php echo lang('timerange_24hrs'); ?></option>
                                    <option value="2d"><?php echo lang('timerange_2days'); ?></option>
                                    <option value="1w"><?php echo lang('timerange_week'); ?></option>
                                    <option value="1m"><?php echo lang('timerange_month'); ?></option>
                                    <option value="range"><?php echo lang('timerange_custom_range'); ?></option>
                                    <option value="elapsed"><?php echo lang('timerange_custom_elapsed'); ?></option>
                                </select>
                                <span id="range_inputs" class="hide">
                                    <input type="text" class="input-datetime custom-field" id="range_start">
                                    <?php echo lang('to'); ?>
                                    <input type="text" class="input-datetime custom-field" id="range_end">
                                </span>
                                <span id="elapsed_inputs" class="hide">
                                    <input type="text" value="2 hours" title="<?php echo lang('timerange_elsapsed_desc'); ?>" class="input-small tt_bind custom-field" id="elapsed_start">
                                    <?php echo lang('ago'); ?>
                                    <input type="hidden" value="1 second" class="input-small custom-field" id="elapsed_end">
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 700px;"><textarea id="rawquery" class="input-xxlarge field custom-field" style="height: 55px; width: 700px;" placeholder="Raw Query"></textarea></td>
                            <td style="vertical-align: top; padding: 0 5px; width: 60px;">
                                <button type="button" id="load_query_button" class="btn" style="width: 78px; margin-bottom: 6px;"><i class="icon-folder-open"></i> <?php echo lang('load'); ?></button><br/>
                                <?php if ($is_admin) { ?>
                                <button type="button" id="save_query_button" class="btn" style="width: 78px;"><i class="icon-download-alt"></i> <?php echo lang('save_button'); ?></button>
                                <?php } ?>
                            </td>
                            <td style="vertical-align: top;">
                                <button type="submit" class="btn btn-primary" id="run_query"><?php echo lang('query_generic_run'); ?> <i class="icon-chevron-right icon-white"></i></button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class='viz-holder-query space-padding'>
                <div id='visualization'></div>
            </div>
            <a href="" id="download-pdf" class="btn btn-default hide" target="_blank" title="<?php echo lang('download_pdf'); ?>"><i class="fa fa-file-pdf-o"></i> PDF</a>
            <div style="clear:both"></div>
        </div>
    </div>
    <div class="row-fluid" id="query_throbber">
        <div class="span12 centerme" style="margin-top:20px;">
            <img src='/nagiosna/media/images/ajax-loader.gif'>
        </div>
    </div>
    <div class="row-fluid" id="query_error">
        <div class="span8 offset2" style="margin-top:20px;">
            <div class="alert alert-error alert-block">
                <h4><?php echo lang('query_generic_error'); ?></h4>
                <p id="errortext"></p>
            </div>
        </div>
    </div>
    <div class="row-fluid hide" id="query_warning">
        <div class="span12" style="margin-top:20px;">
            <div class="alert alert-warning alert-block" id="warningtext" style="text-align: center;"></div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span6">
            <h3 id="title" style="margin-bottom: 0;"></h3>
        </div>
        <div class="span6 <?php if (!empty($download)) { echo 'hide'; } ?>" id="external-link" style="text-align: right; padding-top: 20px;">
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <p id="view-desc"></p>
            <p id="query-desc"></p>
        </div>
    </div>
    <div class="row-fluid" id="query_content">
        <div class="span12">
            <div id="flowdata-tables" class="tab-pane active">
                <div id="query_flowdata">
                    <div id='flowdata-pagination' class='pagination pagination-centered <?php if (!empty($download)) { echo 'hide'; } ?>'>
                        <ul id='flowdata-pagination-list'>
                            <li id="flowdata-pagination-first">
                                <a href="javascript:void(0);" onclick="fill_flowdata_proper(0);" class="paginated-a-link"><?php echo lang('query_generic_page_first'); ?></a>
                            </li>
                            <li id="flowdata-pagination-prev">
                                <a href="javascript:void(0);" onclick="goto_prev();" class="paginated-a-link">&laquo;</a>
                            </li>
                            <li id="flowdata-pagination-next">
                                <a href="javascript:void(0);" onclick="goto_next();" class="paginated-a-link">&raquo;</a>
                            </li>
                            <li id="flowdata-pagination-last">
                                <a href="javascript:void(0);" onclick="goto_last();" class="paginated-a-link"><?php echo lang('query_generic_page_last'); ?></a>
                            </li>
                            <li class="disabled" >
                                <a id="flowdata-pagination-of" href="javascript:void(0);"></a>
                            </li>
                        </ul>
                    </div>
                    <div id='flowdata-proper'>
                        <table id='flowdata-proper-table' class='table table-bordered table-striped table-hover'>
                            <thead>
                                <tr>
                                    <th><?php echo lang('flow_start'); ?></th>
                                    <th><?php echo lang('flow_end'); ?></th>
                                    <th><?php echo lang('duration'); ?></th>
                                    <th><a href='javascript:void(0);' class='addtoquery' title="Add source ip to aggregation list." alt='srcip'><?php if ($resolve_hosts) { echo lang('source_host'); } else { echo lang('source_ip'); } ?></a></th>
                                    <th><a href='javascript:void(0);' class='addtoquery' title="Add destination ip to aggregation list." alt='dstip'><?php if ($resolve_hosts) { echo lang('destination_host'); } else { echo lang('destination_ip'); } ?></a></th>
                                    <th><a href='javascript:void(0);' class='addtoquery' title="Add source port to aggregation list." alt='srcport'><?php echo lang('source_port'); ?></a></th>
                                    <th><a href='javascript:void(0);' class='addtoquery' title="Add destination port to aggregation list." alt='dstport'><?php echo lang('destination_port'); ?></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='packets' data="packetssorter"><?php echo lang('packets'); ?><i class='sortindicator'></i></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='bytes' data="bytessorter"><?php echo lang('bytes'); ?><i class='sortindicator'></i></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='flows' data="flowssorter"><?php echo lang('flows'); ?><i class='sortindicator'></i></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='bps' data="bpssorter"><?php echo lang('bits_sec'); ?><i class='sortindicator'></i></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='pps' data="ppssorter"><?php echo lang('packets_sec'); ?><i class='sortindicator'></i></a></th>
                                    <th><a href='javascript:void(0);' class='sortby' alt='Bpp' data="bppsorter"><?php echo lang('bytes_packet'); ?><i class='sortindicator'></i></a></th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
                <div id="query_summary">
                    <!-- Place where the actual flow summary is rendered into -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Load Query Modal -->
<div id="load-modal" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang('query_generic_load_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('query_generic_load_desc'); ?></p>
        <table>
            <tr>
                <td class="form-left" style="width: 100px;"><?php echo lang('query_generic_load_name'); ?>:</td>
                <td><select id="query_list"></select></td>
            </tr>
            <tr class="hide" id="query_desc_row">
                <td class="form-left" style="padding-top: 0;"><?php echo lang('query_generic_load_desc_input'); ?>:</td>
                <td id="query_desc"></td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="load-modal-yes" class="btn btn-primary"><?php echo lang('query_generic_load_button'); ?></button>
    </div>
</div>

<!-- Save Query Modal -->
<div id="save-modal" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang('query_generic_save_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('query_generic_save_desc'); ?></p>
        <table>
            <tr>
                <td class="form-left"><?php echo lang('query_generic_load_name'); ?>:</td>
                <td><input type="text" class="input-large" id="save_name"> *</td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_generic_load_desc_input'); ?>:</td>
                <td><textarea id="save_desc" class="input-xlarge" style="height: 60px;"></textarea></td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="save-modal-yes" class="btn btn-primary"><?php echo lang('query_generic_save_button'); ?></button>
    </div>
</div>

<!-- Show run from API modal -->
<div id="show_api_mode" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang("show_api_header"); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang("show_api_body"); ?></p>
        <h5><?php echo lang("show_api_get"); ?>:</h5>
        <pre id="api_example_url"></pre>
        <h5><?php echo lang("show_api_post"); ?>:</h5>
        <pre id="api_example_curl"></pre>
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="rid">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('close'); ?></a>
    </div>
</div>

<?php if (empty($download)) { echo $footer; } ?>