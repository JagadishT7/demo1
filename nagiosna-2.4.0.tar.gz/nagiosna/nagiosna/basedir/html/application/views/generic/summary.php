<?php echo $header; ?>

<ul class="breadcrumb">
    <?php if ($type == 'sid') { ?>
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></li>
    <?php } else if ($type == 'gid') { ?>
    <li><a href="<?php echo site_url('groups'); ?>"><?php echo lang('header_tab_sourcegroups'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_sourcegroup'); ?> - <?php echo $group->name; ?></li>
    <?php } ?>
</ul>

<script type="text/javascript">
// Create semi globals
var begindate = '<?php echo $bw_start; ?>';
var enddate = '<?php echo $bw_end; ?>';
var begindate_epoch = <?php if ($bw_start_epoch) { echo $bw_start_epoch; } else { echo 0; } ?>;
var enddate_epoch = <?php if ($bw_end_epoch) { echo $bw_end_epoch; } else { echo 0; } ?>;
var GRAPH;
var yAxis_type = 'logarithmic';
var selected_bw = <?php echo $selected_bw; ?>;
var resolve_hosts = <?php print $resolve_hosts; ?>;

$(document).ready(function() {

    $('#source-graph-tp').change(function() {
        reload_visuals();
    });

    $('input[name="graphalg"]').change(function() {
        if ($(this).val() == 'linear') {
            yAxis_type = 'linear';
        } else {
            yAxis_type = 'logarithmic';
        }
        reload_visuals();
    });

    reload_visuals(); // Load graphs on page load

    // Have the graph  & top talkers load fresh every 5 minutes
    //setInterval(function() { reload_visuals(); }, 300000);
    // SLB 2017-06-09 - changed to reload every 10 minutes - large installation issue.
    setInterval(function() { reload_visuals(); }, 600000);
});

function reload_visuals()
{
    if (selected_bw) {
        var range_start = Highcharts.dateFormat('%m/%d/%Y %H:%M', begindate_epoch * 1000);
        var range_end = Highcharts.dateFormat('%m/%d/%Y %H:%M', enddate_epoch * 1000);
        var dates = begindate + "|" + enddate + "|" + begindate_epoch + "|" + enddate_epoch;
        $('#source-graph-tp').append('<option id="source-custom-option" value="' + dates + '"><?php echo lang("date_range"); ?></option>');
        $('#range_start').val(range_start);
        $('#range_end').val(range_end);
        $('#range-inputs').show();
        $("#source-graph-tp").val(dates);
        selected_bw = 0;
    } else {
        $('#range-inputs').hide();
    }

    var modified = $('#source-graph-tp').val().split('|');
    begindate = modified[0];
    enddate = modified[1];
        
    if(modified[2] == undefined) {
        begindate_epoch = begindate;
        enddate_epoch = enddate;
    } else {
        begindate_epoch = modified[2];
        enddate_epoch = modified[3];
        $('#range-inputs').show();
    }
        
    load_graph(begindate_epoch, enddate_epoch, hc_date_selector); // Load the graph
    load_tts(begindate, enddate); // Load the top talkers
}

</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="row-fluid">
        <div class="span4">
            <div class="form-horizontal" style="margin-top: 25px;">
                <?php echo lang('summary_graph_using'); ?> <label class="radio" style="display: inline-block; margin: 0 0 0 5px; font-weight: bold;"><input type="radio" name="graphalg" value="log" checked><?php echo lang('summary_graph_log'); ?></label> <label class="radio" style="display: inline-block; margin: 0 0 0 5px; font-weight: bold;"><input type="radio" name="graphalg" value="linear"><?php echo lang('summary_graph_linear'); ?></label>
            </div>
        </div>
        <div class="span8">
            <div class="form-horizontal" style="margin-top: 20px; margin-bottom: 10px; text-align: right;">
                <?php echo lang('summary_graph_timeframe'); ?>
                <select id='source-graph-tp' class="input-medium">
                    <option value="-2 hours|-1 second"><?php echo lang('timerange_2hrs'); ?></option>
                    <option value="-4 hours|-1 second"><?php echo lang('timerange_4hrs'); ?></option>
                    <option value="-6 hours|-1 second"><?php echo lang('timerange_6hrs'); ?></option>
                    <option value="-12 hours|-1 second"><?php echo lang('timerange_12hrs'); ?></option>
                    <option value="-24 hours|-1 second"><?php echo lang('timerange_24hrs'); ?></option>
                    <option value="-2 days|-1 second"><?php echo lang('timerange_2days'); ?></option>
                    <option value="-1 week|-1 second"><?php echo lang('timerange_week'); ?></option>
                    <option value="-1 month|-1 second"><?php echo lang('timerange_month'); ?></option>
                </select>
                <span id="range-inputs" class="hide">
                    <input type="text" class="input-datetime" id="range_start" disabled>
                    -
                    <input type="text" class="input-datetime" id="range_end" disabled>
                </span>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <div id="source-graph" style="height: 300px; padding: 10px; border-radius: 10px; border: 1px solid #DDD; margin: 10px 0; text-align: center;">
                <!-- Main graph goes here -->
            </div>
        </div>
    </div>
    <div id="toptalkercontainer" style="margin-top: 10px; border-top: 1px solid #EEE; padding-top: 20px;">
        <div class="row-fluid warningbox hide">
            <div class="span12">
                <div class="alert alert-warning alert-block warningtext" style="text-align: center;"></div>
            </div>
        </div>
        <div class="row-fluid">
            <div class="span1 toptalkers-title-box">
                <span class="toptalkers-title"><?php echo lang('summary_talkers_title'); ?></span>
            </div>
            <div class="span10">
                <div class="well well-summary">
                    <div class="row-fluid">
                        <div class="span4">
                            <table class='table table-condensed table-striped table-bordered table-white'>
                                <thead>
                                    <tr>
                                        <th><?php if ($resolve_hosts) { echo lang('summary_talkers1_alt'); } else { echo lang('summary_talkers1'); } ?></th>
                                        <th class='valueindicator'>% <?php echo lang('summary_bytes'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="ttdstip">
                                </tbody>
                            </table>
                        </div>
                        <div class="span4">
                            <table class='table table-condensed table-striped table-bordered table-white'>
                                <thead>
                                    <tr>
                                        <th><?php if ($resolve_hosts) { echo lang('summary_talkers2_alt'); } else { echo lang('summary_talkers2'); } ?></th>
                                        <th class='valueindicator'>% <?php echo lang('summary_bytes'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="ttsrcip">
                                </tbody>
                            </table>
                        </div>
                        <div class="span2">
                            <table class='table table-condensed table-striped table-bordered table-white'>
                                <thead>
                                    <tr>
                                        <th><?php echo lang('summary_talkers3'); ?></th>
                                        <th class='valueindicator'>% <?php echo lang('summary_bytes'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="ttdstport">
                                </tbody>
                            </table>
                        </div>
                        <div class="span2">
                            <table class='table table-condensed table-striped table-bordered table-white'>
                                <thead>
                                    <tr>
                                        <th><?php echo lang('summary_talkers4'); ?></th>
                                        <th class='valueindicator'>% <?php echo lang('summary_bytes'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="ttsrcport">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>
