<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_dashboard'); ?></li>
</ul>

<script>
function any_are_true(lat)
{
    for(var i=0, l=lat.length;i<l;i++) {
        if(lat[i] == true) {
            return true;
        }
    }
    return false;
}

function make_popover_content(begindate, enddate, state, sid)
{
    var popover = '';
    var queryurl = site_url + "sources/queries/" + sid;
    var queryarg = {    'q[rawquery]': '',
                        'q[aggregate_csv]': 'dstip,srcip',
                        'q[begindate]': begindate,
                        'q[enddate]': enddate };
    var rurl;
    var reporturl = site_url + "sources/reports/" + sid;
    var reportarg = {   'q[begindate]': begindate,
                        'q[enddate]': enddate,
                        'q[top]': 10,
                        'q[toporder]': 'bytes'}
    
    var full_queryurl = queryurl + '?' + $.param(queryarg);

    if(state == false) {
        popover += '<p><?php echo lang("dashboard_aberrant_popover_normal"); ?></p>';
    } else {
        popover += '<p><?php echo lang("dashboard_aberrant_popover_abnormal"); ?></p>';

        // Generate a 'View Problem' url
        var problem_args = { 'p[begindate]': begindate, 'p[enddate]': enddate }
        var view_problem_url = site_url + "sources/" + sid + '?' + $.param(problem_args);
        popover += '<a href="' + view_problem_url + '"><?php echo lang("dashboard_aberrant_view_problem"); ?></a>';
    }
    
    popover += '<hr /><p><strong><?php echo lang("dashboard_aberrant_timeframe_title"); ?></strong></p>';
    
    popover += "<ul>";
    popover += "<li><a href=\"" + full_queryurl + "\"><?php echo lang('query'); ?></a></li>";
    var spargs = $.extend({}, reportarg);
    spargs['q[toptype]'] = 'srcport';
    rurl = reporturl + '?' + $.param(spargs);
    popover += "<li><a href=\"" + rurl + "\"><?php echo lang('dashboard_aberrant_timeframe_tt1'); ?></a></li>";
    var siargs = $.extend({}, reportarg);
    siargs['q[toptype]'] = 'srcip';
    rurl = reporturl + '?' + $.param(siargs);
    popover += "<li><a href=\"" + rurl + "\"><?php echo lang('dashboard_aberrant_timeframe_tt2'); ?></a></li>";
    var dpargs = $.extend({}, reportarg);
    dpargs['q[toptype]'] = 'dstport';
    rurl = reporturl + '?' + $.param(dpargs);
    popover += "<li><a href=\"" + rurl + "\"><?php echo lang('dashboard_aberrant_timeframe_tt3'); ?></a></li>";
    var diargs = $.extend({}, reportarg);
    diargs['q[toptype]'] = 'dstip';
    rurl = reporturl + '?' + $.param(diargs);
    popover += "<li><a href=\"" + rurl + "\"><?php echo lang('dashboard_aberrant_timeframe_tt4'); ?></a></li>";
    popover += "</ul>";
    

        
    var queryurl = begindate + " -> " + enddate;
    return popover;
}

function get_nfdump_datestring(dateobj)
{
    var year = dateobj.getFullYear();
    
    // Javascript's month's are ZERO INDEXED, WTF !@#!@#
    var month = dateobj.getMonth() + 1;
    if(month < 10) {
        month = '0' + month;
    }
    
    var day = dateobj.getDate();
    if(day < 10) {
        day = '0' + day;
    }
    
    var hour = dateobj.getHours();
    if(hour < 10) {
        hour = '0' + hour;
    }
    
    var minute = dateobj.getMinutes();
    if(minute < 10) {
        minute = '0' + minute;
    }
    
    var nf = year + '/' + month + '/' + day + '.' + hour + ':' + minute;
    return nf;
}

function close_pop(node)
{
    $('.abb').popover('hide');
}


function sort_alphabetically(a,b)
{
    return b.name.toLowerCase() < a.name.toLowerCase();
}

function load_check_tables()
{
    load_checks(0, 'ok');
    load_checks(1, 'warning');
    load_checks(2, 'critical');
    load_checks(undefined, 'all');
}

function load_checks(status, target)
{
    var api_url = site_url + 'api/checks/read';
    var tbody = '#tbody-' + target;
    var count = '#count-' + target;
    
    $(tbody).empty();
    
    if(status != undefined) {
        var api_arg = { 'q[lastcode]': status }
    } else {
        var api_arg = {};
    }

    api_arg['o[col]'] = 'name';
    api_arg['o[sort]'] = 'ASC';
    
    $.getJSON(api_url, api_arg, function(data) {
        if(data.error || data.length == 0) {
            $(tbody).append('<tr><td colspan="999"><?php echo lang("dashboard_checks_none_found"); ?></td></tr>');
            $(count).html('0');
        } else {
        
            $.each(data, function(i, d) {
                var tr = $('<tr>');
                var state;
                
                switch(parseInt(d.lastcode)) {
                    case 0:
                        state = 'OK';
                        break;
                    case 1:
                        state = 'WARNING';
                        break;
                    case 2:
                        state = 'CRITICAL';
                        break;
                    case 3:
                    default:
                        state = 'UNKNOWN';
                        break;
                }
                
                $('<td>', {'text': d.name}).appendTo(tr);
                $('<td>', {'text': state, 'class': state}).appendTo(tr);
                if (d.laststdout) { t = d.laststdout.split('|')[0]; } else { t = ''; }
                $('<td>', {'text': t }).appendTo(tr);
                $('<td>', { 'html': '<a href="<?php echo site_url('alerting'); ?>"><?php echo lang("dashboard_manage_link"); ?></a>' }).appendTo(tr);
                
                tr.appendTo(tbody);
                $(count).html(data.length);
            });
        }
    });
}

function draw_aberrancy_dashboard_titles(meta, len)
{
    var t = $('thead.aberrancy');
    var start = meta.start
    var tr = $('<tr>');
    $('<th>', {'text': '<?php echo lang("dashboard_aberrant_title"); ?>'}).appendTo(tr);
    
    var i = 0;
    for(var i=0; i<len; i++) {
        var tmp_start = new Date(start * 1000);
        var hours = tmp_start.getHours();
        if(hours < 10) {
            hours = '0' + hours;
        }
        
        var minutes = tmp_start.getMinutes();
        if(minutes < 10) {
            minutes = '0' + minutes;
        }
        
        $('<th>', { 'text': hours + ':' + minutes,
                    'style': 'margin:0 auto;' }).appendTo(tr);
        start += meta.step;
    }
    
    $.each(t, function(i, d) {
        $(d).html(tr.clone(true));
    });
}

function draw_aberrancy_viz()
{
    var ok_target = '#tbody-aberrant-ok';
    var bad_target = '#tbody-aberrant-critical';
    var all_target = '#tbody-aberrant-all';
    var ok_seen = false;
    var crit_seen = false;
    
    $(ok_target).html('<td colspan="999">No entries</td>');
    $(bad_target).html('<td colspan="999">No entries</td>');
    $(all_target).html('<td colspan="999">No entries</td>');
    
    $('#aberrant-count-ok').html('0');
    $('#aberrant-count-critical').html('0');
    $('#aberrant-count-all').html('0');
    
    $('thead.aberrancy').empty();
    var first = true;
    
    $.getJSON(site_url + 'api/sources/read', { 'o[col]':'name', 'o[sort]':'ASC' },  function(data) {
        
        $.each(data, function(i, d) {

            if (d.disable_abnormal == "1") {
                return;
            }

            $.getJSON(site_url + 'api/graphs/failures', {sid: d.sid, begindate: '-60 minutes', enddate: '-5 minutes'}, function(dz) {
                
                if(first == true) {
                    $(all_target).html(''); // Clear no entries for abnormal behavior chart
                    draw_aberrancy_dashboard_titles(dz.meta, dz.data.length);
                    first = false;
                }
                
                var tr = $('<tr>');
                var status = undefined;
                var current = dz.meta.start
                $('<td>', {'text': d.name, 'class': 'aberr-title'}).appendTo(tr);
                
                $.each(dz.data, function(i, dy) {
                    
                    begindate = new Date(current * 1000);
                    enddate = new Date((current + dz.meta.step) * 1000);
                    
                    begindate = get_nfdump_datestring(begindate);
                    enddate = get_nfdump_datestring(enddate);
                    
                    var popover_content = make_popover_content(begindate, enddate, dy, d.sid);
                    
                    var klass = dy ? 'CRITICAL' : 'OK';
                    status = (status || dy);
                    var new_td = $('<td>', {'class': 'abb ' + klass,
                                            'data-title': '<?php echo lang('dashboard_aberrant_popover_title'); ?><button onclick=\'close_pop(this);\' class=\'close close-popover\'>&times;</button>',
                                            'data-html': 'true',
                                            'data-placement': 'left',
                                            'data-content': popover_content,
                                            'begindate': begindate,
                                            'enddate': enddate,
                                            'data-container': 'body'});
                    new_td.mouseover(function() { 
                        $(this).removeClass(klass); 
                        $(this).addClass(klass + '-mouseover'); 
                    });
                    new_td.mouseout(function() { 
                        $(this).removeClass(klass + '-mouseover'); 
                        $(this).addClass(klass); 
                    });
                    new_td.appendTo(tr);
                    
                    current += dz.meta.step;
                });
                
                if(status) {
                    var ntr = tr.clone(true);
                    if(crit_seen == true) {
                        ntr.appendTo(bad_target);
                    } else {
                        $(bad_target).html(ntr);
                        crit_seen = true;
                    }
                    var critical = parseInt($('#aberrant-count-critical').html());
                    $('#aberrant-count-critical').html(++critical);
                } else {
                    var ntr = tr.clone(true);
                    if(ok_seen == true) {
                        ntr.appendTo(ok_target);
                    } else {
                        $(ok_target).html(ntr);
                        ok_seen = true;
                    }
                    var ok = parseInt($('#aberrant-count-ok').html());
                    $('#aberrant-count-ok').html(++ok);
                }
                var total = parseInt($('#aberrant-count-all').html());
                $('#aberrant-count-all').html(++total);
                if(crit_seen || ok_seen) {
                    tr.clone(true).appendTo(all_target);
                } else {
                    $(all_target).html(tr.clone(true));
                }
                $('.abb').popover();
                $('.abb').on('shown.bs.popover', function() { $('.abb').not(this).popover('hide'); });
            });
        });
    });
}

function build_source_tr_html(source, pinned)
{
    table_inside = '<tr>';
    table_inside += '<td class="source_icon" id="src-status-' + source.sid + '"></td>';
    table_inside += '<td><a href="' + site_url + 'sources/' + source.sid + '">' + source.name + '</a>';

    // Add pinning feature
    // Check if the source is pinned or not
    if (pinned) {
        table_inside += '<span class="unpin" data-sid="' + source.sid + '"><img src="<?php echo base_url('media/icons/bullet_delete.png'); ?>" title="<?php echo lang("sources_unpin"); ?>"></span>';
    } else {
        table_inside += '<span class="pin" data-sid="' + source.sid + '"><img src="<?php echo base_url('media/icons/bullet_add.png'); ?>" title="<?php echo lang("sources_pin"); ?>"></span>';
    }

    table_inside += '</td>';
    table_inside += '<td id="src-summary-' + source.sid + '" class="nopaddingnomargin summarygraph"></td>';
    table_inside += '<td id="src-disk-' + source.sid + '" class="disk-usage"></td>';
    table_inside += '<td class="lifetime">' + human_readable_lifetime(source.lifetime) + '</td>';
    table_inside += '<td>' + flowtype(source.flowtype) + '</td>';

    return table_inside;
}

function in_array(needle, haystack) {
    var length = haystack.length;
    for (var i = 0; i < length; i++) {
        if (haystack[i] == needle) {
            return true;
        }
    }
    return false;
}

function load_sources_table()
{
    // Get the sources info
    // Get a list of sources
    $.post(site_url + 'api/sources/read', { 'o[col]':'name', 'o[sort]':'ASC', <?php echo get_csrf_block(); ?> }, function(sources) {
        $.post(site_url + 'api/sources/get_pinned_sources', { <?php echo get_csrf_block(); ?> }, function(data) {
            pinned = data.pinned;

            var table_inside = '';
            var sc = 0;
            var unpinned = [];

            if (sources.length > 0) {

                // Get a list of the pinned sources first
                $.each(pinned, function(key, pin) {
                    // Check if pinned in sources
                    $.each(sources, function(key, source) {
                        if (pin == source.sid) {
                            table_inside += build_source_tr_html(source, true);
                            sc = sc + 1;
                        }
                    });
                });

                // If the list is less than 5 long, append some extra sources
                if (sc < 5 && sources.length > 0) {
                    $.each(sources, function(key, source) {
                        if (sc < 5) {
                            if (!in_array(source.sid, pinned)) {
                                table_inside += build_source_tr_html(source, false);
                                sc = sc + 1;
                            }
                        }
                    });
                }
            } else {
                table_inside = '<tr><td colspan="999"><?php echo lang("sources_home_none"); ?></td></tr>';
            }
            $('#tbody-sources').html(table_inside);

            check_source();
            load_summaries();
            bind_buttons();
        });
    });
}

function bind_buttons()
{
    // Pin a source to the top
    $('.pin').unbind();
    $('.pin').click(function() {
        $.post(site_url + 'api/sources/pin_source', { sid: $(this).data('sid'), <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                alert('<?php echo lang("dashboard_sources_pin"); ?>');
                load_sources_table();
            }
        });
    });

    // Unpin a source
    $('.unpin').unbind();
    $('.unpin').click(function() {
        $.post(site_url + 'api/sources/unpin_source', { sid: $(this).data('sid'), <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                alert('<?php echo lang("dashboard_sources_unpin"); ?>');
                load_sources_table();
            }
        });
    });
}

function check_source() {
    $.post(site_url + 'api/system/source_status', { <?php echo get_csrf_block(); ?> }, function(status) {
        $.each(status, function(key, status) {
            $('#src-status-' + status.sid).html(status.icon);
            $('#src-disk-' + status.sid).html(status.diskusage);

            <?php if ($is_admin) { ?>
                if (status.status == 'Running' && status.pid != 'n/a') {
                    actions = '<a href="#" class="stop_link" data-sid="' + status.sid + '"><?php echo lang("stop"); ?></a>'; // stop
                } else {
                    actions = '<a href="#" class="start_link" data-sid="' + status.sid + '"><?php echo lang("start"); ?></a>'; // start
                }
                $('#src-actions-' + status.sid).html(actions);
            <?php } ?>
        });
    });
}

function load_summaries() {
    $.post(site_url + 'api/sources/read', { 'o[col]':'name', 'o[sort]':'ASC', <?php echo get_csrf_block(); ?> }, function(sources) {
        $.each(sources, function(key, source) {
            $('#src-summary-' + source.sid)
                .load(site_url + 'sources/summaryviz/' + source.sid)
                .error(function() { $('#src-summary-' + source.sid).html("<?php echo lang('source_home_error_loading'); ?>"); });
        });
    });
}

$(document).ready(function() {
    
    // Do immediate calls
    draw_aberrancy_viz();
    load_check_tables()
    load_sources_table();

    // Schedule for later

    setInterval(function() {
        load_check_tables();
    }, 300000);
    
    setInterval(function() {
        draw_aberrancy_viz();
    }, 300000);

    // Automate source checking
    setInterval("check_source()", 30000);
    setInterval("load_summaries()", 600000);

    // Add ability to open/close the dashboard items
    // 0 - display the dashlet
    // 1 - don't display the dashlet (hide it)
    $('.container').on('click', '.dash-close', function() {
        var dashlet_name = $(this).data('dashlet');
        var dashlet = $('.dashlet-'+dashlet_name);

        if (dashlet.is(":visible")) {
            dashlet.hide();
            dashlet.parents('.span12.well').addClass('dash-closed');
            $(this).html('<i class="fa fa-chevron-up"></i> <?php echo lang("dashboard_open"); ?>');
        } else {
            dashlet.show();
            dashlet.parents('.span12.well').removeClass('dash-closed');
            $(this).html('<i class="fa fa-chevron-down"></i> <?php echo lang("dashboard_close"); ?>');
        }

        // Update the session information...
        if ($('.dashlet-sources').is(':visible')) { dashlet_sources = 0; } else { dashlet_sources = 1; }
        if ($('.dashlet-checks').is(':visible')) { dashlet_checks = 0; } else { dashlet_checks = 1; }
        if ($('.dashlet-abnormal').is(':visible')) { dashlet_abnormal = 0; } else { dashlet_abnormal = 1; }

        var args = { 'sources': dashlet_sources, 'checks': dashlet_checks, 'abnormal': dashlet_abnormal, <?php echo get_csrf_block(); ?> }
        $.post(site_url + 'dashboard/save_dashboard_settings', args, function(data) { });
    });

});

</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 well <?php if ($hide_dashlet['sources']) { echo 'dash-closed'; } ?>" style="margin-bottom: 10px;">
            <div class="row-fluid">
                <div class="span12 dash-header">
                    <div class="dash-title fl">
                        <?php echo lang('dashboard_sources'); ?> (<a href="<?php echo site_url('sources'); ?>"><?php echo lang('dashboard_sources_link'); ?></a>)
                    </div>
                    <div class="dash-close fr" data-dashlet="sources"><i class="fa <?php if (!$hide_dashlet['sources']) { echo 'fa-chevron-down'; } else { echo 'fa-chevron-up'; } ?>"></i> <?php if (!$hide_dashlet['sources']) { echo lang('dashboard_close'); } else { echo lang('dashboard_open'); } ?></div>
                </div>
            </div>
            <div class="row-fluid dashlet-sources" <?php if ($hide_dashlet['sources']) { echo 'style="display: none;"'; } ?>>
                <div class="span12">
                    <table class="table table-striped table-hover table-bordered table-sources" style="margin: 0; padding: 0;">
                        <thead>
                            <tr>
                                <th style="width: 40px;"><?php echo lang('sources_home_th_status'); ?></th>
                                <th><?php echo lang('sources_home_th_name'); ?></th>
                                <th><?php echo lang('sources_home_th_30m_avg'); ?></th>
                                <th><?php echo lang('sources_home_th_disk'); ?></th>
                                <th><?php echo lang('sources_home_th_lifetime'); ?></th>
                                <th style="width: 100px;"><?php echo lang('sources_home_th_flow_type'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="tbody-sources">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12 well <?php if ($hide_dashlet['checks']) { echo 'dash-closed'; } ?>" style="margin-bottom: 10px;">
            <div class="tabbable">
                <div class="row-fluid">
                    <div class="span12 dash-header">
                        <div class="dash-title check fl">
                            <?php echo lang('dashboard_checks'); ?>
                        </div>
                        <ul style="margin: 0; border: 0; <?php if ($hide_dashlet['checks']) { echo 'display: none;'; } ?>" class="nav nav-tabs fl dashlet-checks">
                            <li class="active"><a href="#all" data-toggle="tab"><span class="ALL">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_all'); ?>&nbsp;(<span id='count-all'></span>)</a></li>
                            <li><a href="#ok" data-toggle="tab"><span class="OK">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_ok'); ?>&nbsp;(<span id='count-ok'></span>)</a></li>
                            <li><a href="#warning" data-toggle="tab"><span class="WARNING">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_warning'); ?>&nbsp;(<span id='count-warning'></span>)</a></li>
                            <li><a href="#critical" data-toggle="tab"><span class="CRITICAL">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_critical'); ?>&nbsp;(<span id='count-critical'></span>)</a></li>
                        </ul>
                        <div class="dash-close check fr" data-dashlet="checks"><i class="fa <?php if (!$hide_dashlet['checks']) { echo 'fa-chevron-down'; } else { echo 'fa-chevron-up'; } ?>"></i> <?php if (!$hide_dashlet['checks']) { echo lang('dashboard_close'); } else { echo lang('dashboard_open'); } ?></div>
                    </div>
                </div>
                <div class="tab-content white-back dashlet-checks" <?php if ($hide_dashlet['checks']) { echo 'style="display: none;"'; } ?>>
                    <div class="tab-pane active make-me-scroll extra-padding" id="all">
                        <table class="table table-striped table-hover ">
                            <thead>
                                <th><?php echo lang('dashboard_checks_table_name'); ?></th>
                                <th><?php echo lang('dashboard_checks_table_status'); ?></th>
                                <th width="*"><?php echo lang('dashboard_checks_table_message'); ?></th>
                                <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                            </thead>
                            <tbody id="tbody-all"></tbody>
                        </table>
                    </div>
                    <div class="tab-pane make-me-scroll extra-padding" id="ok">
                        <table class="table table-striped table-hover">
                            <thead>
                                <th><?php echo lang('dashboard_checks_table_name'); ?></th>
                                <th><?php echo lang('dashboard_checks_table_status'); ?></th>
                                <th width="*"><?php echo lang('dashboard_checks_table_message'); ?></th>
                                <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                            </thead>
                            <tbody id="tbody-ok"></tbody>
                        </table>
                    </div>
                    <div class="tab-pane make-me-scroll extra-padding" id="warning">
                        <table class="table table-striped table-hover ">
                            <thead>
                                <th><?php echo lang('dashboard_checks_table_name'); ?></th>
                                <th><?php echo lang('dashboard_checks_table_status'); ?></th>
                                <th width="*"><?php echo lang('dashboard_checks_table_message'); ?></th>
                                <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                            </thead>
                            <tbody id="tbody-warning"></tbody>
                        </table>
                    </div>
                    <div class="tab-pane make-me-scroll extra-padding" id="critical">
                        <table class="table table-striped table-hover ">
                            <thead>
                                <th><?php echo lang('dashboard_checks_table_name'); ?></th>
                                <th><?php echo lang('dashboard_checks_table_status'); ?></th>
                                <th width="*"><?php echo lang('dashboard_checks_table_message'); ?></th>
                                <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                            </thead>
                            <tbody id="tbody-critical"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12 well <?php if ($hide_dashlet['abnormal']) { echo 'dash-closed'; } ?>" style="margin-bottom: 0;">
            <div class="tabbable">
                <div class="row-fluid">
                    <div class="span12 dash-header">
                        <div class="dash-title check fl">
                            <?php echo lang('dashboard_aberrant'); ?>
                        </div>
                        <ul style="margin: 0; border: 0; <?php if ($hide_dashlet['abnormal']) { echo 'display: none;'; } ?>" class="nav nav-tabs fl dashlet-abnormal">
                            <li class="active"><a href="#aberrant-all" data-toggle="tab"><span class="ALL">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_all'); ?>&nbsp;(<span id='aberrant-count-all'></span>)</a></li>
                            <li><a href="#aberrant-ok" data-toggle="tab"><span class="OK">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_ok'); ?>&nbsp;(<span id='aberrant-count-ok'></span>)</a></li>
                            <li><a href="#aberrant-critical" data-toggle="tab"><span class="CRITICAL">&#9830;</span>&nbsp;<?php echo lang('dashboard_checks_critical'); ?>&nbsp;(<span id='aberrant-count-critical'></span>)</a></li>
                        </ul>
                        <div class="dash-close check fr" data-dashlet="abnormal"><i class="fa <?php if (!$hide_dashlet['abnormal']) { echo 'fa-chevron-down'; } else { echo 'fa-chevron-up'; } ?>"></i> <?php if (!$hide_dashlet['abnormal']) { echo lang('dashboard_close'); } else { echo lang('dashboard_open'); } ?></div>
                    </div>
                </div>
                <div class="tab-content white-back dashlet-abnormal" <?php if ($hide_dashlet['abnormal']) { echo 'style="display: none;"'; } ?>>
                    <div class="tab-pane active make-me-scroll extra-padding" id="aberrant-all">
                        <table class="table table-striped table-hover">
                            <thead class="aberrancy"></thead>
                            <tbody id="tbody-aberrant-all"></tbody>
                        </table>
                    </div>
                    <div class="tab-pane make-me-scroll extra-padding" id="aberrant-ok">
                        <table class="table table-striped table-hover">
                            <thead class="aberrancy"></thead>
                            <tbody id="tbody-aberrant-ok"></tbody>
                        </table>
                    </div>
                    <div class="tab-pane make-me-scroll extra-padding" id="aberrant-critical">
                        <table class="table table-striped table-hover">
                            <thead class="aberrancy"></thead>
                            <tbody id="tbody-aberrant-critical"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>
