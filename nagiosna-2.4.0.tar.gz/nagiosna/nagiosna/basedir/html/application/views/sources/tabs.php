<script type="text/javascript">
<?php
echo 'var type = "' . $type . '";';
echo 'var source_id = "' . $source->sid . '";';
echo 'var apikey = "' . $apikey . '";';
echo 'var apiaccess = ' . $apiaccess . ';';
echo 'var view_id = ' . $view_id . ';';
?>

// Do view stuff
$(document).ready(function() {

    load_view_list();

    if (view_id > 0) {
        $('#delete_view_btn').show();
        $('#clear_view_btn').show();
    }

    // Set up remove source button
    $('#remove').click(function() {
        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        $('#remove-modal').modal('show');
        <?php } ?>
    });

    $('#clear_view_btn').click(function() {
        $.post(site_url + 'api/system/set_view_id', { view_id: 0, <?php echo get_csrf_block(); ?> }, function(data) {
            location.reload();
        });
    });

    // When view selection changes
    $('#view').change(function() {
        var vid = $(this).val();

        // Load view and save it in the session
        $.post(site_url + 'api/system/set_view_id', { view_id: vid, <?php echo get_csrf_block(); ?> }, function(data) {
            location.reload(); // Just doing this for now...
        });
    });

    // When create button is clicked
    $('#create_view_btn').click(function() {

        var vars = { 'q[name]': $('#view_name').val(),
                     'q[limiter]': $('#limiter').val(),
                     'q[lifetime]': $('#lifetime').val() + $('#lifetime_suffix').val(),
                     'q[sid]': source_id,
                     <?php echo get_csrf_block(); ?> }

        $.post(site_url + 'api/views/create', vars, function(data) {
            if (data.status == "success") {
                load_view_list();
                $('#create_view').modal('hide');
            } else {
                $('#create_view_error').html(data.error).show();
            }

            load_view_list();
            load_assoc_list();
            load_unassoc_list();
        });

    });

});

function load_view_list()
{
    $.post(site_url + 'api/views/get_views', { 'q[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
        var list = '<option value="0"><?php echo lang("tabs_source_default_view"); ?></option>';
        if (views.length > 0) {
            $('#view').attr('disabled', false);
            $.each(views, function(key, value) {
                var selected = '';
                if (value.vid == view_id) { selected = ' selected'; }
                list += '<option value="' + value.vid + '"' + selected + '>' + value.name + '</option>';
            });
            $('#view').html(list);
        } else {
            $('#view').html(list);
            $('#view').attr('disabled', true);
            $('#view').val(0);
        }
    });
}

function load_view(vid)
{  
    view_id = vid;
    //alert('VID has been set to: ' + view_id);
}

// Load source status
function load_status()
{
    $.post(site_url + 'api/system/source_status', { sid: source_id, <?php echo get_csrf_block(); ?> }, function(status) {

        var status_view;
        if (status.status == "Running") {
            status_view = "<?php echo lang('running'); ?>";
        } else {
            status_view = "<?php echo lang('stopped'); ?>";
        }

        var html = status.icon + ' ' + status_view;

        if (status.status == "Running") {
            html += ' (PID: ' + status.pid + ')';
            <?php if ($is_admin) { ?>
            html += '&nbsp; <button id="stop_source" class="btn btn-mini"><?php echo lang("stop"); ?></button> <button id="restart_source" class="btn btn-mini"><?php echo lang("restart"); ?></button>';
            <?php } ?>
        } else {
            <?php if ($is_admin) { ?>
            html += '&nbsp; <button id="start_source" class="btn btn-mini"><?php echo lang("start"); ?></button>';
            <?php } ?>
        }

        $('#status').html(html);

        create_status_button_links();
    });
}

function create_status_button_links()
{
    // Start the service
    $('#start_source').click(function() {
        loading_small($('#status'));
        $.post(site_url + 'api/system/start', { sid: source_id, <?php echo get_csrf_block(); ?> }, function(data) {
            window.setTimeout(load_status, 1000);
        });
    });

    // Restart the service
    $('#restart_source').click(function() {
        loading_small($('#status'));
        $.post(site_url + 'api/system/restart', { sid: source_id, <?php echo get_csrf_block(); ?> }, function(data) {
            window.setTimeout(load_status, 1000);
        });
    });

    // Stop the service
    $('#stop_source').click(function() {
        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        loading_small($('#status'));
        $.post(site_url + 'api/system/stop', { sid: source_id, <?php echo get_csrf_block(); ?> }, function(data) {
            window.setTimeout(load_status, 1000);
        });
        <?php } ?>
    });
}

</script>

    <div class="row-fluid">
        <div class="span8">
            <div style="padding: 10px 0 20px 0;">
                <div style="margin-right: 20px; font-size: 32px; font-weight: bold; line-height: 28px; float: left;"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></div>
                <div class="form-horizontal <?php if (!empty($download)) { echo 'hide'; } ?>" style="float: left;">
                    <strong><?php echo lang('tabs_source_display_view'); ?>:</strong> 
                    <select id="view">
                        <option selected><?php echo lang('loading'); ?></option>
                    </select>
                    <button type="button" id="clear_view_btn" class="btn hide"><?php echo lang('clear'); ?></button>
                    <?php if ($is_admin) { ?><a href="#create_view" role="button" class="btn" data-toggle="modal"><i class="icon-file"></i> <?php echo lang('create_button'); ?></a><?php } ?>
                </div>
                <div style="clear: both;"></div>
            </div>
        </div>
        <div class="span4 <?php if (!empty($download)) { echo 'hide'; } ?>" style="text-align: right; line-height: 60px;">
            <div id="status">
                <!-- Dynamic source status area -->
            </div>
        </div>
    </div>
    <div class="row-fluid <?php if (!empty($download)) { echo 'hide'; } ?> generic-tab-box">
        <div class="span12">
            <ul class="nav nav-tabs" style="margin-bottom: 0;">
                <?php if ($tab == 'summary') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('sources/' . $source->sid); ?>"><i class="icon-home"></i> <?php echo lang('tabs_summary'); ?></a></li>
                <?php if ($tab == 'reports') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('sources/reports/' . $source->sid); ?>"><i class="icon-book"></i> <?php echo lang('tabs_reports'); ?></a></li>
                <?php if ($tab == 'queries') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('sources/queries/' . $source->sid); ?>"><i class="icon-play-circle"></i> <?php echo lang('tabs_queries'); ?></a></li>
                <?php if ($is_admin) {?>
                        <li style="float: right;"><a href="#" id='remove'><i class="icon-trash"></i> <?php echo lang('tabs_remove'); ?></a></li>
                    <?php if ($tab == 'edit') { echo '<li class="active" style="float: right;">'; } else { echo '<li style="float: right;">'; } ?>
                        <a href="<?php echo site_url('sources/edit/' . $source->sid); ?>"><i class="icon-wrench"></i> <?php echo lang('tabs_edit'); ?></a></li>
                    <?php if ($tab == 'views') { echo '<li class="active" style="float: right;">'; } else { echo '<li style="float: right;">'; } ?>
                        <a href="<?php echo site_url('sources/views/' . $source->sid); ?>"><i class="icon-eye-open"></i> <?php echo lang('tabs_views'); ?></a></li>
                <?php } ?>
                <?php if ($tab == 'percentile') { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('sources/percentile/' . $source->sid); ?>"><i class="icon-signal"></i> <?php echo lang('tabs_percentile'); ?></a></li>
            </ul>
            <div id="remove-modal" class="modal hide fade" tabindex="-1" role="dialog">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3><?php echo lang('tabs_delete_modal_header'); ?></h3>
                </div>
                <div class="modal-body">
                    <p><?php echo lang('tabs_delete_modal_text'); ?></p>
                </div>
                <div class="modal-footer">
                    <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
                    <a href="#" id="remove-modal-yes" class="btn btn-danger"><?php echo lang('yes_button'); ?></a>
                </div>
            </div>
            <div id="create_view" class="modal hide fade">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3><?php echo lang('create_view_modal_header'); ?></h3>
                </div>
                <div class="modal-body">
                    <p style="padding-bottom: 10px;"><?php echo lang('create_view_modal_text1'); ?> (<a href="#" class="po_bind" data-toggle="popover" data-placement="bottom" data-content="<?php echo lang('create_view_modal_popup_text'); ?>" title="<?php echo lang('create_view_modal_popup_title'); ?>"><?php echo lang('create_view_modal_explain'); ?></a>) <?php echo lang('create_view_modal_text2'); ?></p>
                    <div class="hide alert alert-error" id="create_view_error"></div>
                    <table>
                        <tr>
                            <td class="form-left" style="width: 120px;"><?php echo lang('create_view_modal_source'); ?>:</td>
                            <td><input type="text" class="input-large" value="<?php echo $source->name; ?>" disabled></td>
                        </tr>
                        <tr>
                            <td class="form-left"><?php echo lang('create_view_modal_name'); ?>:</td>
                            <td><input type="text" id="view_name" class="input-xlarge"></td>
                        </tr>
                        <tr>
                            <td class="form-left"><?php echo lang('create_view_modal_limiter'); ?>:</td>
                            <td><input type="text" id="limiter" placeholder="ip 192.168.0.1"> <i class="icon-question-sign tt_bind" title="<?php echo lang('create_view_modal_limiter_popup'); ?>"></i></td>
                        </tr>
                        <tr>
                            <td class="form-left"><?php echo lang('create_view_modal_lifetime'); ?>:</td>
                            <td>
                                <div>
                                    <input type="text" id="lifetime" style="margin: 0; width: 20px;" value="24">
                                    <select id="lifetime_suffix" style="margin: 0; width: 90px;">
                                        <option value="H"><?php echo lang('hours'); ?></option>
                                        <option value="d"><?php echo lang('days'); ?></option>
                                        <option value="w"><?php echo lang('weeks'); ?></option>
                                    </select>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
                    <button type="button" id="create_view_btn" class="btn btn-primary"><?php echo lang('create_button'); ?></button>
                </div>
            </div>
        </div>
    </div>
