<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_sources'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    list_sources();

    // Make the enter key also work
    $('#source_search').keyup(function(e) {
        if (e.keyCode == 13) {
            $('#source_search_btn').trigger('click');
        }
    });

    // Search sources
    $('#source_search_btn').click(function() {
        list_sources();
    });

    // Create auto-loading
    setInterval("check_source()", 30000);
    setInterval("load_summaries()", 600000);
});

function list_sources()
{
    // Get a list of sources
    $.post(site_url + 'api/sources/read', { 's[name]': $('#source_search').val(), 'o[col]':'name', 'o[sort]':'asc', <?php echo get_csrf_block(); ?> }, function(sources) {
        $.post(site_url + 'api/sources/get_pinned_sources', { <?php echo get_csrf_block(); ?> }, function(data) {
            pinned = data.pinned;

            var no_sources = "<?php echo lang('sources_home_none'); ?>";
            if ($('#source_search').val() != '') {
                no_sources = "<?php echo lang('sources_home_search_no_results'); ?>";
            }

            table_inside = '<tr><td colspan="999">' + no_sources + '</td></tr>';
            if (sources.length > 0) {
                table_inside = '';
                $.each(sources, function(key, source) {

                    table_inside += '<tr>';
                    table_inside += '<td class="source_icon" id="src-status-' + source.sid + '"></td>';
                    table_inside += '<td><a href="' + site_url + 'sources/' + source.sid + '">' + source.name + '</a>';

                    // Check if pinned or not
                    var is_pinned = false;
                    $.each(pinned, function(k, p) {
                        if (p == source.sid) {
                            is_pinned = true;
                        }
                    });

                    if (is_pinned) {
                        // Unpin button
                        table_inside += '<span class="unpin" data-sid="' + source.sid + '"><img src="<?php echo base_url('media/icons/bullet_delete.png'); ?>" title="<?php echo lang("sources_unpin"); ?>"></span>';
                    } else {
                        // Pin button
                        table_inside += '<span class="pin" data-sid="' + source.sid + '"><img src="<?php echo base_url('media/icons/bullet_add.png'); ?>" title="<?php echo lang("sources_pin"); ?>"></span>';
                    }

                    table_inside += '</td>';
                    table_inside += '<td id="src-summary-' + source.sid + '" class="nopaddingnomargin summarygraph"></td>';
                    table_inside += '<td id="src-disk-' + source.sid + '" class="disk-usage"></td>';
                    table_inside += '<td class="lifetime">' + human_readable_lifetime(source.lifetime) + '</td>';
                    table_inside += '<td>' + flowtype(source.flowtype) + '</td>';
                    table_inside += '<td>' + source.port + '</td>';

                    <?php if ($is_admin) { ?>
                    table_inside += '<td class="actions"><span id="src-actions-' + source.sid + '"></span>  &bull; <a href="#" class="delete_source" data-sid="' + source.sid + '" data-name="' + source.name + '"><?php echo lang("delete"); ?></a></td>';
                    <?php } ?>
                });
            }
            $('#table-body').html(table_inside);

            bind_buttons();
            check_source();
            load_summaries();
        });
    });
}

function load_summaries() {
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(sources) {
        $.each(sources, function(key, source) {
            $('#src-summary-' + source.sid)
                .load(site_url + 'sources/summaryviz/' + source.sid)
                .error(function() { $('#src-summary-' + source.sid).html("<?php echo lang('source_home_error_loading'); ?>"); });
        });
    });
}

function bind_buttons()
{
    $('.delete_source').unbind();
    $('.delete_source').click(function() {
        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        var source_name = $(this).data('name');
        var sid = $(this).data('sid');
        var conf = confirm("<?php echo lang('sources_home_delete_question'); ?>: " + source_name);
        if (conf === true) {
            $.post(site_url + 'api/sources/delete', { 'q[sid]': sid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                } else {
                    list_sources();
                }
            }, 'json');
        }
        <?php } ?>
    });

    $('.pin').unbind();
    $('.pin').click(function() {
        $.post(site_url + 'api/sources/pin_source', { sid: $(this).data('sid'), <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                alert("<?php echo lang('dashboard_sources_pin'); ?>");
                list_sources();
            }
        });
    });

    $('.unpin').unbind();
    $('.unpin').click(function() {
        $.post(site_url + 'api/sources/unpin_source', { sid: $(this).data('sid'), <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != 'success') {
                alert(data.error);
            } else {
                alert("<?php echo lang('dashboard_sources_unpin'); ?>");
                list_sources();
            }
        });
    });
}

function check_source() {
    $.post(site_url + 'api/system/source_status', { <?php echo get_csrf_block(); ?> }, function(status) {
        $.each(status, function(key, status) {
            $('#src-status-' + status.sid).html(status.icon);
            $('#src-disk-' + status.sid).html(status.diskusage);

            <?php if ($is_admin) { ?>
                if (status.status == 'Running' && status.pid != 'n/a') {
                    actions = '<a href="#" class="stop_link" data-sid="' + status.sid + '"><?php echo lang("stop"); ?></a>'; // stop
                } else {
                    actions = '<a href="#" class="start_link" data-sid="' + status.sid + '"><?php echo lang("start"); ?></a>'; // start
                }
                $('#src-actions-' + status.sid).html(actions);
            <?php } ?>
        });

        set_aftercheck_bindings();
    });
}

function set_aftercheck_bindings()
{
    $('.start_link').unbind();
    $('.start_link').click(function() {
        var sid = $(this).data('sid');

        loading_small($('#src-status-' + sid));
        $.post(site_url + 'api/system/start', { sid: sid, <?php echo get_csrf_block(); ?> }, function(data) {
            //alert('The source has been started.');
            check_source();
        });
    });

    $('.stop_link').unbind();
    $('.stop_link').click(function() {
        var sid = $(this).data('sid');

        <?php if ($demo_mode) { ?>
        alert("<?php echo lang('demo_mode_warning'); ?>");
        <?php } else { ?>
        loading_small($('#src-status-' + sid));
        $.post(site_url + 'api/system/stop', { sid: sid, <?php echo get_csrf_block(); ?> }, function(data) {
            //alert('The source has been stopped. You will no longer be collecting netflow data for this source.');
            check_source();
        });
        <?php } ?>
    });
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('header_tab_sources'); ?></h2>
            <p><?php echo lang('sources_home_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 15px;">
        <div class="span6">
            <?php if ($is_admin) { ?>
            <a href="<?php echo site_url('sources/create'); ?>" class="btn"><i class="icon-hdd"></i> <?php echo lang('sources_home_create_button'); ?></a>
            <?php } ?>
        </div>
        <div class="span6" style="text-align: right;">
            <div class="form-horizontal">
                <input type="text" id="source_search" placeholder="<?php echo lang('sources_home_search_placeholder'); ?>"></input> <button id="source_search_btn" class="btn"><i class="icon-search"></i></button>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <!-- Dynamically loaded source area -->
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th style="width: 40px;"><?php echo lang('sources_home_th_status'); ?></th>
                        <th><?php echo lang('sources_home_th_name'); ?></th>
                        <th><?php echo lang('sources_home_th_30m_avg'); ?></th>
                        <th><?php echo lang('sources_home_th_disk'); ?></th>
                        <th><?php echo lang('sources_home_th_lifetime'); ?></th>
                        <th style="width: 100px;"><?php echo lang('sources_home_th_flow_type'); ?></th>
                        <th style="width: 80px;"><?php echo _('Port'); ?></th>
                        <?php if ($is_admin) { ?>
                        <th style="width: 100px;"><?php echo lang('actions'); ?></th>
                        <?php } ?>
                    </tr>
                 </thead>
                <tbody id="table-body">
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php echo $footer; ?>
