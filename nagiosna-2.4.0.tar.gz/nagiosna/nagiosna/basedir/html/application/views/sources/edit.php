<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('create_source_breadcrumb'); ?> - <?php echo $source->name; ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    $('#advanced').click(function() {
        if ($('.advanced-setting').is(':visible')) {
            $(this).parent().find('.fa').removeClass('fa-chevron-down').addClass('fa-chevron-up');
            $('.advanced-setting').hide();
        } else {
            $(this).parent().find('.fa').removeClass('fa-chevron-up').addClass('fa-chevron-down');
            $('.advanced-setting').show();
        }
    });

});
</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="row-fluid">
        <div class="span12">
            <h3 style="margin-top: 15px;"><?php echo lang('edit_source_heading');?></h3>
            <p><?php echo lang('edit_source_subheading');?></p>
            <?php if ($message) { ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
            <?php
            } else if (validation_errors()) { ?>
            <div class="alert alert-error"><?php echo validation_errors(); ?></div>
            <?php
            } else if ($error) { ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php
            }
            echo form_open('sources/edit/'.$source->sid);
            ?>
            <div class="line"></div>
            <div>
                <table>
                    <tr>
                        <td class="form-left" style="width: 175px;"><?php echo lang('create_source_name'); ?><span class="red tt_bind" title="<?php echo lang('req'); ?>">*</span>:</td>
                        <td>
                            <div><input type="text" name="source_name" style="margin: 0;" disabled="disabled" value="<?php echo $source->name; ?>"></div>
                            <div class="subtext"><?php echo lang('create_source_name_desc'); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('create_source_ip'); ?>:</td>
                        <td>
                            <div>
                                <?php $lines = substr_count($source->addresses, "\n"); $height = 20 * ($lines + 2); if ($height > 400) { $height = 400; } ?>
                                <textarea type="text" name="addresses" class="input-medium" style="margin: 0; height: <?php echo $height; ?>px;"><?php echo $source->addresses; ?></textarea>
                            </div>
                            <div class="subtext"><?php echo lang('create_source_ip_desc'); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('create_source_port'); ?><span class="red tt_bind" title="<?php echo lang('req'); ?>">*</span>:</td>
                        <td>
                            <div><input type="text" name="port" style="margin: 0;" class="input-small" value="<?php echo $source->port; ?>"></div>
                            <div class="subtext"><?php echo lang('create_source_port_desc'); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('create_source_flow_type'); ?>:</td>
                        <td>
                            <div style="padding-bottom: 5px;">
                                <select name="flow_type" class="input-small" disabled="disabled">
                                    <option value="netflow" <?php if ($source->flowtype == 'netflow') { echo 'selected'; } ?>>NetFlow</option>
                                    <option value="sflow" <?php if ($source->flowtype == 'sflow') { echo 'selected'; } ?>>sFlow</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('create_source_data_lifetime'); ?>:</td>
                        <td>
                            <div>
                                <input type="text" name="lifetime" style="margin: 0; width: 20px;" value="<?php echo substr($source->lifetime, 0, strlen($source->lifetime)-1); ?>">
                                <select name="lifetime_suffix" style="margin: 0; width: 90px;">
                                    <option value="H" <?php if ($source->lifetime_suffix == 'H') { echo 'selected'; } ?>><?php echo lang('hours'); ?></option>
                                    <option value="d" <?php if ($source->lifetime_suffix == 'd') { echo 'selected'; } ?>><?php echo lang('days'); ?></option>
                                    <option value="w" <?php if ($source->lifetime_suffix == 'w') { echo 'selected'; } ?>><?php echo lang('weeks'); ?></option>
                                </select>
                            </div>
                            <div class="subtext"><?php echo lang('create_source_data_lifetime_desc'); ?> <a class="po_bind" data-toggle="popover" data-placement="top" data-content="<?php echo lang('create_source_data_lifetime_popup_text'); ?>" title="<?php echo lang('create_source_data_lifetime_popup_title'); ?>"><?php echo lang('create_source_data_lifetime_popup'); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"></td>
                        <td>
                            <label class="checkbox" style="margin-bottom: 10px;">
                                <input type="checkbox" value="1" name="disable_abnormal" <?php if (!empty($source->disable_abnormal)) { echo "checked"; } ?>>
                                <?php echo lang('sources_disable_abnormal'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="padding-bottom: 15px;"><a id="advanced"><?php echo lang('advanced_settings'); ?></a> <i class="fa fa-chevron-up"></i></td>
                    </tr>
                    <tr class="hide advanced-setting">
                        <td class="form-left"><?php echo lang('data_directory'); ?>:</td>
                        <td>
                            <input type="text" style="margin: 0; width: 400px;" name="directory" value="<?php echo $source->directory; ?>" disabled>
                            <div class="subtext"><?php echo lang('data_directory_desc'); ?></div>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="margin-top: 20px;" class="form-actions">
                <button type="submit" class="btn btn-primary"><?php echo lang('save_button'); ?></button>
                <a href="<?php echo site_url('sources') . '/' . $source->sid; ?>" class="btn"><?php echo lang('cancel_button'); ?></a>
            </div>
            <?php echo form_close();?>
        </div>
    </div>
</div>

<?php echo $footer; ?>