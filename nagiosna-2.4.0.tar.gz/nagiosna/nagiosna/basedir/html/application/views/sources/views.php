<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('sources'); ?>"><?php echo lang('header_tab_sources'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('sources/' . $source->sid); ?>"><?php echo lang('breadcrumb_source'); ?> - <?php echo $source->name; ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('tabs_views'); ?></li>
</ul>

<script type="text/javascript">
var ASSOC_VIEWS;

$(document).ready(function() {

    // Get lists 
    load_assoc_list();
    
    // Unassociate 'Selected' Button
    $('#unassoc_sel_btn').click(function() {
        var view_ids = $('input:checkbox[name=assoc_view_ids]:checked').map(function(_, el) {
            return $(el).val();
        }).get();

        var vars = { 'q[sid]': source_id, 'q[vid]': [], <?php echo get_csrf_block(); ?> }
        $.each(view_ids, function(key, value) {
            vars['q[vid]'].push(value);
        });

        unassociate(vars);
    });

    // Associate 'Selected' Button
    $('#assoc_sel_btn').click(function() {
        var view_ids = $('input:checkbox[name=unassoc_view_ids]:checked').map(function(_, el) {
            return $(el).val();
        }).get();

        var vars = { 'q[sid]': source_id, 'q[vid]': [], <?php echo get_csrf_block(); ?> }
        $.each(view_ids, function(key, value) {
            vars['q[vid]'].push(value);
        });

        associate(vars);
    });

});

function unassociate(vars)
{
    $.post(site_url + 'api/views/delete_source_associations', vars, function(data) {
        if (data.status != "success") {
            alert(data.error);
        }

        if (vars['q[vid]'] == view_id) {
            $.post(site_url + 'api/system/set_view_id', { view_id: 0, <?php echo get_csrf_block(); ?> }, function(data) {
                location.reload();
            });
        } else {
            load_view_list();
        }

        load_assoc_list();
        load_unassoc_list();
    });
}

function associate(vars)
{
    $.post(site_url + 'api/views/add_source_associations', vars, function(data) {
        if (data.status != "success") {
            alert(data.error);
        }
        
        load_assoc_list();
        load_unassoc_list();
        load_view_list();
    });
}

function bind_links()
{
    // Associate
    $('.assoc_view').unbind();
    $('.assoc_view').click(function() {
        var vid = $(this).data('vid');
        var vars = { 'q[sid]': source_id, 'q[vid]': vid, <?php echo get_csrf_block(); ?> }
        associate(vars);
    });

    // Unassociate
    $('.unassoc_view').unbind();
    $('.unassoc_view').click(function() {
        var vid = $(this).data('vid');
        var vars = { 'q[sid]': source_id, 'q[vid]': vid, <?php echo get_csrf_block(); ?> }
        unassociate(vars);
    });

    // Delete
    $('.delete_view').unbind();
    $('.delete_view').click(function() {
        var vid = $(this).data('vid');
        var name = $(this).data('name');
        var conf = confirm("<?php echo lang('view_source_delete_okay'); ?>");
        if (conf === true) {
            $.post(site_url + 'api/views/read_source_associations', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.length > 0) { 
                    var text = "<?php echo lang('view_source_delete_perm1'); ?>: " + name + "\n<?php echo lang('view_source_delete_perm2'); ?>:\n\n";
                    $.each(data, function(key, value) {
                        text += value.name + "\n";
                    });
                    var conf2 = confirm(text);
                    if (conf2) {
                        remove_all_associations_and_delete(vid);
                    }
                } else {
                    delete_view(vid);
                }
            });
        }
    });
}

function remove_all_associations_and_delete(vid)
{
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(data) {
        var sids = [];
        $.each(data, function(key, value) {
            sids.push(value.sid);
        })
         $.post(site_url + 'api/views/delete_source_associations', { 'q[vid]': vid, 'q[sid]': sids, <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status != "success") {
                alert(data.error);
            } else {
                delete_view(vid);
            }
         });
    });
}

function delete_view(vid)
{
    $.post(site_url + 'api/views/delete', { 'q[vid]': vid, <?php echo get_csrf_block(); ?> }, function(data) {
        if (data.status != "success") {
            alert(data.error);
        }

        if (vid == view_id) {
            $('#clear_view_btn').trigger('click');
        }

        load_assoc_list();
        load_unassoc_list();
        load_view_list();
    });
}

function load_assoc_list()
{
    var table = '';

    $.post(site_url + 'api/views/get_views', { 'q[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
        ASSOC_VIEWS = views;
        if (views.length > 0) {
            $.each(ASSOC_VIEWS, function(key, value) {
                table += '<tr><td><label class="checkbox tbl-checkbox"><input type="checkbox" name="assoc_view_ids" class="tbl-chk-input" id="' + value.vid + '" value="' + value.vid + '"></label></td>';
                table += '<td><label for="' + value.vid + '">' + value.name + '</label></td>';
                table += '<td>' + human_readable_lifetime(value.lifetime) + '</td>';
                table += '<td><a href="#" data-vid="' + value.vid + '" class="unassoc_view"><?php echo lang("view_source_unassociate_button"); ?></a> &bull; <a href="#" class="delete_view" data-vid="' + value.vid + '" data-name="' + value.name + '"><?php echo lang("delete"); ?></a></td>';
                table += '</tr>';
            });
        } else {
            table += '<tr><td colspan="4"><?php echo lang("view_source_no_assoc"); ?></td></tr>';
        }

        $('#table-assoc-body').html(table);
        load_unassoc_list();
    });
}

function load_unassoc_list()
{
    var table = '';

    $.post(site_url + 'api/views/get_views', { 'e[sid]': source_id, <?php echo get_csrf_block(); ?> }, function(views) {
        if (views.length > 0) {
            $.each(views, function(key, value) {
                table += '<tr><td><label class="checkbox tbl-checkbox"><input type="checkbox" name="unassoc_view_ids" class="tbl-chk-input" id="' + value.vid + '" value="' + value.vid + '"></label></td>';
                table += '<td><label for="' + value.vid + '">' + value.name + '</label></td>';
                table += '<td>' + human_readable_lifetime(value.lifetime) + '</td>';
                table += '<td><a href="#" data-vid="' + value.vid + '" class="assoc_view"><?php echo lang("view_source_associate_button"); ?></a> &bull; <a href="#" class="delete_view" data-vid="' + value.vid + '" data-name="' + value.name + '"><?php echo lang("delete"); ?></a></td>';
                table += '</tr>';
            });
        } else {
            table += '<tr><td colspan="4"><?php echo lang("view_source_no_views"); ?></td></tr>';
        }

        $('#table-unassoc-body').html(table);
        bind_links();
    });
}
</script>

<div class="container">
    <?php echo $tabs; ?>
    <div class="row-fluid">
        <div class="span12">
            <h3 style="margin-top: 15px;"><?php echo lang('view_source_header'); ?></h3>
            <p><?php echo lang('view_source_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span6">
            <h4><?php echo lang('view_source_associated'); ?> <i class="icon-question-sign tt_bind" title="<?php echo lang('view_source_associated_popup'); ?>"></i></h4>
            <button class="btn btn-mini" id="unassoc_sel_btn"><?php echo lang('view_source_unassociate_sel_button'); ?></button>
            <table class="table table-bordered table-striped" style="margin-top: 10px;">
                <thead>
                    <tr>
                        <th style="width: 20px; text-align: center;"><i class="icon-plus-sign select_all" style="cursor: pointer;" title="<?php echo lang('select_all'); ?>" data-for-name="assoc_view_ids"></i></th>
                        <th><?php echo lang('view_source_th_name'); ?></th>
                        <th style="width: 100px;"><?php echo lang('view_source_th_lifetime'); ?></th>
                        <th style="width: 170px;"><?php echo lang('view_source_th_actions'); ?></th>
                    </tr>
                </thead>
                <tbody id="table-assoc-body">
                </tbody>
            </table>
        </div>
        <div class="span6">
            <h4><?php echo lang('view_source_unassociated'); ?> <i class="icon-question-sign tt_bind" title="<?php echo lang('view_source_unassociated_popup'); ?>"></i></h4>
            <button class="btn btn-mini" id="assoc_sel_btn"><?php echo lang('view_source_associate_sel_button'); ?></button>
            <table class="table table-bordered table-striped" style="margin-top: 10px;">
                <thead>
                    <tr>
                        <th style="width: 20px; text-align: center;"><i class="icon-plus-sign select_all" style="cursor: pointer;" title="<?php echo lang('select_all'); ?>" data-for-name="unassoc_view_ids"></i></th>
                        <th><?php echo lang('view_source_th_name'); ?></th>
                        <th style="width: 100px;"><?php echo lang('view_source_th_lifetime'); ?></th>
                        <th style="width: 135px;"><?php echo lang('view_source_th_actions'); ?></th>
                    </tr>
                </thead>
                <tbody id="table-unassoc-body">
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php echo $footer; ?>
