<?php echo $header; ?>

<div class="container" style="margin: 20px auto; width: 1170px;">
    <div class="row">
        <div class="span8 offset2">
            <div class="well">
                <?php echo form_open('auth/forgot_password', array('class' => 'form-horizontal login')); ?>
                    <h2 class="login-header"><?php echo lang('forgot_password_heading'); ?></h2>
                    <?php echo lang('forgot_password_subheading');?>
                    <?php if ($message) { echo '<div class="alert" style="margin: 10px 0 0 0;">' . $message . '</div>'; } ?>
                    <div style="margin: 15px 0;">
                        <label for="username">
                        	<strong><?php echo lang('forgot_password_username_label');?>:</strong>
                        	<input type="text" class="input" name="username" id="username"></input>
                        </label>
      				</div>
                    <div>
                        <button type="submit" class="btn btn-primary"><?php echo lang('forgot_password_submit_btn'); ?></button>
                        <a href="<?php echo site_url('login'); ?>" class="btn"><?php echo lang('cancel_button'); ?></a>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>