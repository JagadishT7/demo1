<?php echo $header; ?>

<div class="container" style="margin: 20px auto; width: 1170px;">
    <div class="row">
        <div class="span4">
            <div class="well">
                <?php echo form_open('login', array('class' => 'form-horizontal login')); ?>
                    <h2 class="login-header"><?php echo lang('login_heading'); ?></h2>
                    <?php if ($message) { echo '<div class="alert">' . $message . '</div>'; } ?>
                    <fieldset>
                        <input type="text" name="username" value="<?php echo $username; ?>" placeholder="<?php echo lang('login_username_label'); ?>"><br/>
                        <input type="password" name="password" placeholder="<?php echo lang('login_password_label'); ?>"><br/>
                        <label class="checkbox"><input type="checkbox" name="remember" value="1"> <?php echo lang('login_remember_label');?></label>
                        <div class="row-fluid">
                            <div class="span4">
                            <button type="submit" class="btn btn-primary"><?php echo lang('login_button_label'); ?></button>
                            </div>
                            <div class="span8 login-forgot-password">
                                <a href="<?php echo site_url('forgot_password'); ?>"><?php echo lang('login_forgot_password'); ?></a>
                            </div>
                        </div>
                    </fieldset>
                <?php echo form_close(); ?>
            </div>
        </div>
        <div class="span8">
            <img src="<?php echo base_url('media/images/nna_splash.jpg'); ?>" style="padding-bottom: 10px;" />
            <h4><?php echo lang('login_about_heading'); ?></h4>
            <p><?php echo lang('login_about_desc'); ?> <a href="http://www.nagios.com/products/nagios-network-analyzer"><?php echo lang('login_about_desc_link'); ?></a>.</p>
            <h4><?php echo lang('login_learning_opportunities'); ?></h4>
            <p><?php echo lang('login_learning_opportunities_training'); ?></p>
            <p><?php echo lang('login_learning_opportunities_conference'); ?></p>
            <h4><?php echo lang('login_contact_us'); ?></h4>
            <p><?php echo lang('login_contact_us_text'); ?>:</p>
            <table>
                <tr>
                    <td><?php echo lang('login_contact_us_support'); ?>:</td>
                    <td><a href="http://support.nagios.com/forum/"><?php echo lang('login_contact_us_support_forum'); ?></a></td>
                </tr>
                <tr>
                    <td><?php echo lang('login_contact_us_sales'); ?>:</td>
                    <td><?php echo lang('phone'); ?>: (651) 204-9102<br/><?php echo lang('fax'); ?>: (651) 204-9103<br/><?php echo lang('email'); ?>: sales@nagios.com</td>
                </tr>
                <tr>
                    <td><?php echo lang('login_contact_us_web'); ?></td>
                    <td><a href="http://www.nagios.com">www.nagios.com</a></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<?php echo $footer; ?>
