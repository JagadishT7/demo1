<?php echo $header; ?>

<div class="container" style="margin: 20px auto; width: 1170px;">
    <div class="row">
        <div class="span8 offset2">
            <div class="well">
                <?php echo form_open('auth/reset_password', array('class' => 'form-horizontal login')); ?>
                    <h2 class="login-header"><?php echo lang('reset_password_heading'); ?></h2>
                    <?php echo lang('reset_password_subheading');?>
                    <?php if ($message) { echo '<div class="alert" style="margin: 10px 0 0 0;">' . $message . '</div>'; } ?>
                    <div style="margin: 15px 0;">
                        <label for="new_password">
                        	<strong><?php echo lang('reset_password_new_password_label'); ?>:</strong>
                        	<?php echo form_input($new_password);?>
                        </label>
                        <label for="new_password_conf">
                        	<strong><?php echo lang('reset_password_new_password_confirm_label');?>:</strong>
                        	<?php echo form_input($new_password_confirm);?>
                        </label>
                        <?php echo form_input($user_id);?>
						<?php echo form_hidden($csrf); ?>
      				</div>
                    <div>
                        <button type="submit" class="btn btn-primary"><?php echo lang('reset_password_submit_btn'); ?></button>
                        <a href="<?php echo site_url('login'); ?>" class="btn"><?php echo lang('cancel_button'); ?></a>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>