<html>
<body>
	<h1><?php echo lang('email_forgot_password_heading');?></h1>
	<p><?php echo lang('email_forgot_password_desc'); ?></p>
	<p><?php echo site_url('auth/reset_password/'. $forgotten_password_code);?></p>
</body>
</html>