    </div>
    <div class="push"></div>
</div>
<div id="footer">
    <div class="well">
        <div class="row-fluid" style="height: 15px;">
            <div class="span6">
                <?php echo lang('nnafooter'); ?> <?php if ($logged_in) { ?> <?php echo get_product_version(); ?> &nbsp;&nbsp;&bull;&nbsp;&nbsp; <a target="_new" class="updates" href="http://www.nagios.com/checkforupdates/?product=nagiosnetworkanalyzer&version=<?php echo get_product_version(); ?>"><?php echo lang('footer_check_updates'); ?> <i class="icon-share"></i></a> <?php } ?>
            </div>
            <div class="span6" style="text-align: right;">
                <a target="_new" href="http://www.nagios.com/products/nagios-network-analyzer"><?php echo lang('about'); ?></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a target="_new" href="http://www.nagios.com/legal"><?php echo lang('legal'); ?></a> &nbsp;&nbsp;|&nbsp;&nbsp; <?php echo lang('copyright'); ?> &copy; 2013-<?php echo date("Y"); ?> <a target="_new" href="http://www.nagios.com/"><?php echo lang('ne'); ?></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>