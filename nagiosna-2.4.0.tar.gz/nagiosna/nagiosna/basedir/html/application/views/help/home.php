<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_help'); ?></li>
</ul>

<div class="container">
    <div class="row-fluid">
    	<div class="span2 offset1">
            <div>
                <h4><?php echo lang('help_sidebar_resources'); ?></h4>
                <ul class="nav nav-tabs nav-stacked">
                    <li><a href="https://support.nagios.com/kb/category.php?id=43" target="_new"><?php echo lang('help_sidebar_support_kb'); ?></a></li>
                    <li><a href="https://support.nagios.com/forum/" target="_new"><?php echo lang('help_sidebar_support_forum'); ?></a></li>
                    <li><a href="https://library.nagios.com" target="_new"><?php echo lang('help_sidebar_library'); ?></a></li>
                </ul>
                <h4><?php echo lang('help_sidebar_guides'); ?></h4>
                <ul class="nav nav-tabs nav-stacked">
                    <li><a href="https://assets.nagios.com/downloads/nagios-network-analyzer/guides/nna-ag/" target="_blank"><?php echo lang('help_sidebar_admin_guide'); ?></a></li>
                    <!-- <li><a href="">User Guide</a></li> -->
                </ul>
            </div>
    	</div>
        <div class="span8">
            <h2><?php echo lang('help_title'); ?></h2>
            <p><?php echo lang('help_title_desc'); ?></p>
            <p><?php echo lang('help_title_desc2'); ?></p>
            <h3><?php echo lang('help_step1_title'); ?></h3>
            <p><?php echo lang('help_step1_desc'); ?></p>
            <p><?php echo lang('help_step1_desc2'); ?> <a href="https://library.nagios.com/library/products/nagios-network-analyzer/documentation/654-understanding-network-flows"><?php echo lang('help_step1_link'); ?></a></p>
            <p>
                <?php echo lang('help_flows_title'); ?>
                <ul>
                    <li><a href="https://library.nagios.com/library/products/nagios-network-analyzer/documentation/658-configuring-switches-and-routers-to-send-netflow-data-to-nagios-network-analyzer"><?php echo lang('help_flows_routers'); ?></a></i>
                    <li><a href="https://library.nagios.com/library/products/nagios-network-analyzer/documentation/652-installing-and-configuring-windows-netflow-exporters-for-network-analyzer"><?php echo lang('help_flows_windows'); ?></a></li>
                    <li><a href="https://library.nagios.com/library/products/nagios-network-analyzer/documentation/659-configuring-a-linux-server-to-send-netflow-data-to-nagios-network-analyzer"><?php echo lang('help_flows_linux'); ?></a></li>
                    <li><?php echo lang('help_flows_vmware'); ?></li>
                </ul>
            </p>
            <p><?php echo lang('help_step1_desc3'); ?></p>
            <h3><?php echo lang('help_step2_title'); ?></h3>
            <p><?php echo lang('help_step2_desc'); ?></p>
            <p><?php echo lang('help_step2_name'); ?></p>
            <p><?php echo lang('help_step2_ip'); ?></p>
            <p><?php echo lang('help_step2_port'); ?></p>
            <p><?php echo lang('help_step2_type'); ?></p>
            <p><?php echo lang('help_step2_lifetime'); ?></p>
            <p><?php echo lang('help_step2_final'); ?></p>
        </div>
    </div>
</div>


<?php echo $footer; ?>
