<?php echo $header; ?>

<script type="text/javascript">
$(document).ready(function() {
    var temp;
    $('input[name="key_type"]').click(function() {
        if ($(this).val() == 'trial') {
            temp = $('input[name="key"]').val();
            $('input[name="key"]').val('');
            $('input[name="key"]').attr('disabled', true);
        } else {
            $('input[name="key"]').val(temp);
            $('input[name="key"]').attr('disabled', false);
        }
    });
});
</script>

<?php echo form_open('install'); ?>
<div id="conatiner">
    <div class="row-fluid">
        <div class="span12">
            <div class="install-title">
                <h2><?php echo lang('setup_install_header'); ?></h2>
                <p><?php echo lang('setup_install_desc'); ?></p>
            </div>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 10px;">
        <div class="span6 offset3">
            <?php if (!empty($error)) { ?>
            <div class="alert alert-error" style="text-align: center; margin-top: 20px;"><?php echo $error; ?></div>
            <?php } ?>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 10px;">
        <div class="span2 offset3">
            <h4><?php echo lang('setup_install_license_header'); ?></h4>
            <p><?php echo lang('setup_install_license_desc'); ?></p>
        </div>
        <div class="span4">
            <div class="well">
                <table style="margin: 0 auto;">
                    <tr>
                        <td colspan="2" style="text-align: center;">
                            <label class="radio" style="display: inline-block; margin: 0 15px 10px 0;"><input type="radio" name="key_type" value="trial" checked> <?php echo lang('setup_install_trial'); ?></label>
                            <label class="radio" style="display: inline-block;"><input type="radio" value="key" name="key_type"> <?php echo lang('setup_install_have_key'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_license_key'); ?>:</td>
                        <td><input type="text" class="input-xlarge" style="margin: 0; width: 296px;" name="key" value="<?php echo get_license_key(); ?>" disabled></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span2 offset3">
            <h4><?php echo lang('setup_install_account_header'); ?></h4>
            <p><?php echo lang('setup_install_account_desc'); ?></p>
        </div>
        <div class="span4">
            <div class="well">
                <table style="margin: 0 auto;">
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_account_username'); ?>:<span class="req">*</span></td>
                        <td><input type="text" name="username" value="nagiosadmin"></td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_account_password'); ?>:<span class="req">*</span></td>
                        <td><input type="password" name="password" class="input-medium"></td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_account_conf_password'); ?>:<span class="req">*</span></td>
                        <td><input type="password" name="conf_password" class="input-medium"></td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_account_email'); ?>:<span class="req">*</span></td>
                        <td><input type="text" name="email" value="" class="input-xlarge"></td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_language'); ?>:</td>
                        <td>
                            <select id="language" name="language" class="input-medium">
                                <option value="default" <?php if ($user_language == 'default') { echo 'selected'; } ?>><?php echo lang('default'); ?></option>
                                <?php foreach ($languages as $l) { ?>
                                <option value="<?php echo $l; ?>" <?php if ($user_language == $language && $language == $l) { echo 'selected'; } ?>>
                                    <?php $output = lang('language_' . $l); if (empty($output)) { echo uppercase($l); } else { echo $output; } ?>
                                </option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="form-left"><?php echo lang('setup_install_timezone'); ?>:</td>
                        <td>
                            <select name="timezone" id="tz" style="width: 300px; margin: 0;">
                                <?php
                                $cur_timezone = get_current_timezone();
                                if (!empty($set_timezone)) { $cur_timezone = $set_timezone; }
                                foreach (get_timezones() as $name => $val) {
                                ?>
                                <option value="<?php echo $val; ?>" <?php if ($val == $cur_timezone) { echo 'selected'; } ?>><?php echo $name; ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="text-align: right;">
                <button type="submit" value="1" name="finish" class="btn btn-primary"><?php echo lang('setup_install_finish_button'); ?> <i class="icon-chevron-right icon-white"></i></button>
            </div>
        </div>
    </div>
</div>
<?php echo form_close(); ?>

<?php echo $footer; ?>