<?php echo $header; ?>

<div id="conatiner">
    <div class="row-fluid">
        <div class="span12">
            <div class="install-title">
                <h2><?php echo lang('setup_enterkey_trial_expired'); ?></h2>
                <p><?php echo lang('setup_enterkey_trial_expired_desc'); ?></p>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span6 offset3">
            <?php if (!empty($error)) { ?>
            <div class="alert alert-error" style="text-align: center; margin-top: 30px;"><?php echo $error; ?></div>
            <?php } ?>
        </div>
    </div>
    <div class="row-fluid" style="margin-top: 20px;">
        <div class="span4 offset4">
            <div class="well" style="text-align: center; padding-top: 35px;">
                <?php echo form_open('enterkey' , 'form-horizontal'); ?>
                <input type="text" name="key" style="margin: 0; width: 304px;" placeholder="License Key">
                <button type="submit" value="1" name="set" class="btn btn-primary"><?php echo lang('setup_enterkey_setkey'); ?></button>
                <?php form_close(); ?>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <p style="text-align: center;"><?php echo lang('setup_enterkey_text'); ?></p>
        </div>
    </div>
</div>

<?php echo $footer; ?>