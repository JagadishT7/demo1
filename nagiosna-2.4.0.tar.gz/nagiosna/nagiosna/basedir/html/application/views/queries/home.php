<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_queries'); ?></li>
</ul>

<script type="text/javascript">
var QUERIES_LIST = [];
var temp_qid;

$(document).ready(function() {

    load_queries_list();
    load_run_modal();

    $('#queries_search').click(function() {
        load_queries_list();
    });
    
    $('#queries_search_input').keyup(function(e) {
        if (e.keyCode == 13) {
            $('#queries_search').trigger('click');
        }
    });

    <?php if ($is_admin) { ?>
    $('#create_query_btn').click(function() {
        $('#create_query_error').hide();
        $('#query_name').val('');
        $('#desc').val('');
        $('#ag').val('');
        $('#rawquery').val('');
        $('#title').html('<?php echo lang("query_home_modal_create"); ?>');
        $('#hidden').val('create');
        $('#timerange').val('2h').trigger('change');
        $('#create_query').modal('show');
    });

    $('#create_query_btn_modal').click(function() {
        var vars = { <?php echo get_csrf_block(); ?> }
        var name = $('#query_name').val();
        var description = $('#desc').val();
        var ag = $('#ag').val();
        dates = get_correct_datetimes();
        var rawquery = $('#rawquery').val();

        var url;
        if ($('#hidden').val() == 'create') {
            url = site_url + 'api/queries/create';
            vars['q[name]'] = name;
            vars['q[description]'] = description;
            vars['q[aggregate_csv]'] = ag;
            vars['q[begindate]'] = dates.start;
            vars['q[enddate]'] = dates.end;
            vars['q[rawquery]'] = rawquery;
        } else if ($('#hidden').val() == 'update') {
            url = site_url + 'api/queries/update';
            vars['q[qid]'] = temp_qid;
            vars['u[name]'] = name;
            vars['u[description]'] = description;
            vars['u[aggregate_csv]'] = ag;
            vars['u[begindate]'] = dates.start;
            vars['u[enddate]'] = dates.end;
            vars['u[rawquery]'] = rawquery;
        }

        $.post(url, vars, function(data) {
            if (data.status != 'success') {
                $('#create_query_error').html(data.error).show();
            } else {
                $('#create_query_error').hide();
                $('#create_query').modal('hide');
                temp_qid = 0;
                load_queries_list();
            }
        });
    });

    $('#delete_multi_query').click(function() {
        var query_ids = $('input:checkbox[name=queries]:checked').map(function(_, el) {
            return $(el).val();
        }).get();
        var conf = confirm("<?php echo lang('query_home_are_you_sure'); ?>");
        if (conf === true) {
            $.post(site_url + 'api/queries/delete', { 'q[qid]': query_ids, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                } else {
                    load_queries_list();
                }
            }, 'json');
        }
    });
    <?php } ?>

    // Select source/group
    $('input[name="type"]').change(function() {
        if ($(this).val() == 'source') {
            $('#sources').show();
            $('#groups').hide();
        } else if ($(this).val() == 'group') {
            $('#sources').hide();
            $('#groups').show();
        }
    });

    // Run query button
    $('#run_query_send').click(function() {
        var qid = $('#qid').val();
        var type = $('input[name="type"]:checked').val() + 's';
        var id = $('#' + type).val();
        var url = site_url + type + '/queries/' + id + '?qid=' + qid;
        window.location.href = url;
    });

});

function bind_buttons()
{
    <?php if ($is_admin) { ?>
    $('.view_query').unbind();
    $('.view_query').click(function() {
        var qid = $(this).data('qid');
        $.post(site_url + 'api/queries/read', { 'q[qid]': qid, <?php echo get_csrf_block(); ?> }, function(data) {
            var query = data[0];
            temp_qid = qid;
            $('#create_query_error').hide();
            $('#create_query').modal('show');
            $('#query_name').val(query.name);
            $('#desc').val(query.description);
            $('#ag').val(query.aggregate_csv);
            $('#rawquery').val(query.rawquery);
            $('#hidden').val('update');
            set_time_range(query.begindate, query.enddate);
            $('#title').html('<?php echo lang("query_home_modal_update"); ?>');
        });
    });

    $('.delete_query').unbind();
    $('.delete_query').click(function() {
        var name = $(this).data('name');
        var qid = $(this).data('qid');
        var conf = confirm("<?php echo lang('query_home_delete'); ?>: " + name);
        if (conf === true) {
            $.post(site_url + 'api/queries/delete', { 'q[qid]': qid, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.status != 'success') {
                    alert(data.error);
                }
                load_queries_list();
            }, 'json');
        }
    });
    <?php } ?>

    // Run query
    $('.run_query_btn').unbind();
    $('.run_query_btn').click(function() {
        var qid = $(this).data('qid');
        $('#qid').val(qid);
        $('#run_query').modal('show');
    });

    $('.tbl-chk-input').unbind();
    $('.tbl-chk-input').change(function() {
        var query_ids = $('input:checkbox[name=queries]:checked').map(function(_, el) {
            return $(el).val();
        }).get();

        if (query_ids.length >= 1) {
            $('#delete_multi_query').attr('disabled', false);
        } else {
            $('#delete_multi_query').attr('disabled', true);
        }
    });
}

function load_queries_list()
{
    $.post(site_url + 'api/queries/read', { 's[name]': $('#queries_search_input').val(), <?php echo get_csrf_block(); ?> }, function(queries) {
        QUERIES_LIST = queries;
        var table;
        if (QUERIES_LIST.length > 0) {
            $.each(QUERIES_LIST, function(key, query) {
                table +='<tr><td><label class="checkbox tbl-checkbox"><input type="checkbox" name="queries" class="tbl-chk-input" value="' + query.qid + '"></label></td>';
                table += '<td>' + query.name + '</td>';
                table += '<td>' + query.description + '</td>';
                table += '<td><a href="#" class="run_query_btn" data-qid="' + query.qid + '"><?php echo lang("run"); ?></a>';

                <?php if ($is_admin) { ?>
                table += ' &bull; <a href="#" class="view_query" data-qid="' + query.qid + '"><?php echo lang("edit"); ?></a> &bull; <a href="#" class="delete_query" data-name="' + query.name + '" data-qid="' + query.qid + '"><?php echo lang("delete"); ?></a>';
                <?php } ?>

                table += '</td></tr>';
            });
        } else {
            table += '<tr><td colspan="4"><?php echo lang("query_home_none"); ?></td></tr>';
        }
        $('#table-body').html(table);
        bind_buttons();
    });
}

function load_run_modal()
{
    // Get a list of sources
    $.post(site_url + 'api/sources/read', { <?php echo get_csrf_block(); ?> }, function(sources) {
        $.each(sources, function(key, source) {
            $('#sources').append('<option value="' + source.sid + '">' + source.name + '</option>');
        });
    });

    // Get a list of source groups
    $.post(site_url + 'api/groups/read', { <?php echo get_csrf_block(); ?> }, function(groups) {
        $.each(groups, function(key, group) {
            $('#groups').append('<option value="' + group.gid + '">' + group.name + '</option>');
        });
    });
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12">
            <h2 style="margin-top: 0;"><?php echo lang('header_tab_queries'); ?></h2>
            <p><?php echo lang('query_home_desc'); ?></p>
        </div>
    </div>
    <div class="row-fluid" style="margin-bottom: 15px;">
        <div class="span6">
            <?php if ($is_admin) { ?>
            <button type="button" class="btn" id="delete_multi_query" disabled><i class="icon-trash"></i> <?php echo lang('delete'); ?></button>
            <a href="#" class="btn" id="create_query_btn"><i class="icon-file"></i> <?php echo lang('query_home_create'); ?></a>
            <?php } ?>
        </div>
        <div class="span6" style="text-align: right;">
            <div class="form-horizontal">
            <input type="text" id="queries_search_input" placeholder="<?php echo lang('query_name_search'); ?>"></input> <button id="queries_search" class="btn"><i class="icon-search"></i></button>
            </div>
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12">
            <div>
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th style="width: 16px; text-align: center;"><i class="icon-plus-sign select_all" style="cursor: pointer;" title="<?php echo lang('select_all'); ?>" data-for-name="queries"></i></th>
                            <th style="width: 25%;"><?php echo lang('query_home_th_name'); ?></th>
                            <th><?php echo lang('query_home_th_desc'); ?></th>
                            <th style="width: 150px;"><?php echo lang('query_home_th_actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($is_admin) { ?>
<!-- Create Query Modal -->
<div id="create_query" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3 id="title"></h3>
    </div>
    <div class="modal-body">
        <p style="padding-bottom: 10px;"><?php echo lang('query_home_modal_desc'); ?></p>
        <div class="hide alert alert-error" id="create_query_error"></div>
        <table>
            <tr>
                <td class="form-left"><?php echo lang('query_home_modal_name'); ?>:</td>
                <td><input type="text" id="query_name" class="input-xlarge"></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_home_modal_desc_input'); ?>:</td>
                <td><textarea id="desc" style="width: 400px; height: 50px;"></textarea></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_home_modal_ag'); ?>:</td>
                <td><input type="text" id="ag" class="field tt_bind" title="<?php echo lang('query_home_modal_ag_desc'); ?>"></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_home_modal_tf'); ?>:</td>
                <td>
                    <select id="timerange" style="width: 185px;">
						<option value="2h"><?php echo lang('timerange_2hrs'); ?></option>
                        <option value="4h"><?php echo lang('timerange_4hrs'); ?></option>
                        <option value="6h"><?php echo lang('timerange_6hrs'); ?></option>
                        <option value="12h"><?php echo lang('timerange_12hrs'); ?></option>
                        <option value="24h"><?php echo lang('timerange_24hrs'); ?></option>
                        <option value="2d"><?php echo lang('timerange_2days'); ?></option>
                        <option value="1w"><?php echo lang('timerange_week'); ?></option>
                        <option value="1m"><?php echo lang('timerange_month'); ?></option>
                        <option value="range"><?php echo lang('timerange_custom_range'); ?></option>
                        <option value="elapsed"><?php echo lang('timerange_custom_elapsed'); ?></option>
                    </select>
                    <div id="range_inputs" class="hide">
                        <input type="text" class="input-datetime" id="range_start">
                        <?php echo lang('to'); ?>
                        <input type="text" class="input-datetime" id="range_end">
                    </div>
                    <div id="elapsed_inputs" class="hide">
                        <input type="text" value="24 hours" title="<?php echo lang('timerange_elsapsed_desc'); ?>" class="input-small tt_bind" id="elapsed_start">
                        <?php echo lang('ago'); ?>
                        <input type="hidden" value="1 second" class="input-small" id="elapsed_end">
                    </div>
                </td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_home_modal_raw'); ?>:</td>
                <td><textarea id="rawquery" style="width: 400px; height: 80px;"></textarea></td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <input type="hidden" id="hidden" value="create">
        <button type="button" class="btn" data-dismiss="modal" aria-hidden="true"><?php echo lang('cancel_button'); ?></button>
        <button type="button" id="create_query_btn_modal" class="btn btn-primary"><?php echo lang('save_button'); ?></button>
    </div>
</div>
<?php } ?>

<!-- Run Query Modal -->
<div id="run_query" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3><?php echo lang('query_home_run_title'); ?></h3>
    </div>
    <div class="modal-body">
        <p><?php echo lang('query_home_run_desc'); ?></p>
        <table>
            <tr>
                <td class="form-left"></td>
                <td><label class="radio" style="display: inline-block; margin: 0 10px 10px 0;"><input type="radio" name="type" value="source" checked><?php echo lang('breadcrumb_source'); ?></label> <label class="radio" style="display: inline-block;"><input type="radio" name="type" value="group"><?php echo lang('breadcrumb_sourcegroup'); ?></label></td>
            </tr>
            <tr>
                <td class="form-left"><?php echo lang('query_home_run_on'); ?>:</td>
                <td>
                    <select id="sources" class="input-large">
                    </select>
                    <select id="groups" class="input-large hide">
                    </select>
                </td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <input type="hidden" value="0" id="qid">
        <a href="#" data-dismiss="modal" class="btn"><?php echo lang('cancel_button'); ?></a>
        <a href="#" id="run_query_send" class="btn btn-primary"><?php echo lang('query_home_run_button'); ?> <i class="icon-chevron-right icon-white"></i></a>
    </div>
</div>

<?php echo $footer; ?>