<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_backup'); ?></li>
</ul>

<script type="text/javascript">

$(document).ready(function() {

    backup_status();

    $('#create-backup').click(function() {
        $('#backup-failed').hide();
        $('#backup-success').hide();
        $('#delete-box').hide();
        $('#backup-result-box').addClass('inline').show();

        // Run the backup command
        $.post(site_url + 'api/system/do_backup', { <?php echo get_csrf_block(); ?> }, function(data) {
            $('.fa-spinner').hide();

            // success
            $('#backup-success').show();
            backup_status();
        }, 'json').fail( function(xhr, textStatus, errorThrown) {
            $('.fa-spinner').hide();

            // failure
            var errorString = "<p style='margin:0 0 0 20px;'><b>" + textStatus + ":</b> " + xhr.status + " - " + errorThrown +"</p>";
            $('#backup-failed').append(errorString).show();
        });
    });

    function backup_status() {
        $.post(site_url + 'api/system/backup_cron_status', { <?php echo get_csrf_block(); ?> }, function(data) {
            if (data.status > 0) {
                // backup in progress - disable button
                $('#create-backup').attr('disabled', 'disabled');
                $('#backup-running').addClass('inline').show();
            }
        });
    }

});

</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('backup_heading'); ?></h2>
                <p><?php echo lang('backup_desc'); ?></p>
                <p>
                    <div>
                        <a id="create-backup" class="btn"><i class="fa fa-upload"></i> <?php echo lang('index_create_backup'); ?></a>
                        <span class="hide" id="backup-running">
                            <?php echo lang('index_backup_running'); ?>
                        </span>
                    </div>
                    <div class="well hide" id="backup-result-box" style="margin-top:10px;">
                        <span class="hide" id="backup-failed">
                            <img src="<?php echo media_url('icons/exclamation.png'); ?>"> <?php echo lang('backup_failed'); ?>
                        </span>
                        <span class="hide" id="backup-success">
                            <img src="<?php echo media_url('icons/accept.png'); ?>"> <?php echo lang('backup_success'); ?>
                        </span>
                        <i class="fa fa-spinner fa-spin"></i>
                    </div>
                </p>
                <?php
                // check for delete backup messages
                if ($delete) { ?>
                    <div id="delete-box" class="well" style="display: inline-block;">
                    <?php if ($delete['result'] == 0) { ?>
                            <p><img src="<?php echo media_url('icons/accept.png'); ?>">&nbsp;&nbsp;<?php echo $delete['message']; ?></p>
                    <?php } else { ?>
                            <p><img src="<?php echo media_url('icons/exclamation.png'); ?>">&nbsp;&nbsp;<?php echo $delete['message'];  ?></p>
                    <?php } ?>
                    </div>
                <?php } ?>
                <table class="table table-striped table-hover table-bordered" style="width: auto;">
                    <thead>
                        <tr>
                            <th style="min-width: 200px;"><?php echo lang('backup_name_th'); ?></th>
                            <th><?php echo lang('backup_date_th'); ?></th>
                            <th><?php echo lang('backup_size_th'); ?></th>
                            <th><?php echo lang('backup_action_th'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $x = 0;

                    foreach ($backups as $backup) {
                        $x++;

                        if (($x % 2) != 0) {
                            $rowclass = "odd";
                        } else {
                            $rowclass = "even";
                        }
                    ?>
                        <tr class="<?php echo $rowclass; ?>">
                        <td><?php echo $backup['file']; ?></td>
                        <td><?php echo $backup['date']; ?></td>
                        <td><?php echo $backup['size']; ?></td>
                        <td>
                            <?php echo anchor("admin/backup/download/" . $backup['file'], lang("download")); ?> &bull;
                            <?php echo anchor("admin/backup/delete/" . $backup['file'], lang('delete'), array('onclick' => "return confirm('Do you want delete this backup file?')")); ?>
                        </td>
                        </tr>
                    <?php 
                    }

                    if (count($backups) == 0) {
                        ?>

                        <tr>
                            <td colspan="9"><?php echo _('There are no system backups available.'); ?></td>
                        </tr>

                    <?php
                    }

                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>