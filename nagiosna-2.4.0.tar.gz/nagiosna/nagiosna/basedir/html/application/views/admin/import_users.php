<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('admin/users'); ?>"><?php echo lang('breadcrumb_users'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('index_import_users'); ?></li>
</ul>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('ldap_ad_import_title'); ?></h2>
                <p><?php echo lang('ldap_ad_import_desc_step1'); ?></p>

                <?php if (!empty($errors)) { ?>
                <div class="alert alert-error" style="margin: 15px 0 10px 0;">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo $errors; ?>
                </div>
                <?php } ?>

                <?php echo form_open('admin/users/import'); ?>
                <div style="padding: 10px 0; margin-bottom: 20px;">
                    <div>
                        <input type="text" name="username" value="<?php if (!empty($username)) { echo $username; } ?>" placeholder="<?php echo lang('username'); ?>">
                    </div>
                    <div>
                        <input type="password" name="password" placeholder="<?php echo lang('password'); ?>">
                    </div>
                    <div>
                        <select name="auth_server_id" style="width: 340px;">
                            <?php foreach ($auth_servers as $as) { ?>
                            <option value="<?php echo $as->id; ?>" <?php if (empty($as->active)) { echo "disabled"; } if (!empty($auth_server_id)) { if ($auth_server_id == $as->id) { echo 'selected'; } } ?>><?php if ($as->type == "ad") { echo lang('active_directory').' - '.$as->controllers; } else { echo lang('ldap').' - '.$as->host; } ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div>
                        <button type="submit" value="1" name="submitted" class="btn btn-default"><?php echo lang('next'); ?> <i class="fa fa-chevron-right" style="font-size: 11px; margin-left: 4px;"></i></button>
                    </div>
                </div>
                <?php echo form_close(); ?>

                <a href="<?php echo site_url('admin/auth_servers'); ?>"><?php echo lang('ldap_ad_manage_servers_link'); ?></a>

            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>