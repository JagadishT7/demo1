<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_license'); ?></li>
</ul>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('license_heading'); ?></h2>
                <p><?php echo lang('license_desc'); ?></p>
                <?php if (is_trial_license()) { ?>
                <div class="alert alert-error"><?php echo lang('license_trial_end'); ?> <strong><?php echo get_trial_days_left(); ?></strong> <?php echo lang('license_trial_end_days'); ?>.</div>
                <?php } else if ($error) { ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
                <?php } else { ?>
                <div class="alert alert-success"><?php echo lang('license_valid'); ?></div>
                <?php } ?>
                <div class="form-horizontal">
                    <?php echo form_open('admin/license'); ?>
                    <strong><?php echo lang('license_key'); ?>:</strong>
                    <input <?php if ($demo_mode) { echo 'disabled'; } ?> type="text" name="key" style="width: 304px;" value="<?php if (!$demo_mode) { echo get_license_key(); } else { echo 'DEMO MODE'; } ?>">
                    <button <?php if ($demo_mode) { echo 'disabled'; } ?> type="submit" value="1" name="setkey" class="btn btn-primary"><?php echo lang('license_set_key'); ?> <i class="icon-chevron-right icon-white"></i></button>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>