<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_users'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    $('.remove').click(function() {
        var id = $(this).data('id');

        <?php if ($demo_mode) { ?>
        alert('<?php echo lang("demo_mode_warning"); ?>');
        <?php } else { ?>
        // Confirm remove
        var conf = confirm("<?php echo lang('users_delete'); ?>");

        if (conf == true) {
            $.post(site_url + 'admin/users/delete', { id: id, <?php echo get_csrf_block(); ?> }, function(data) {
                if (data.success == 0) {
                    alert(data.errormsg);
                } else {
                    // window.location.href = "<?php echo current_url(); ?>";
                    window.location.href = "<?php echo site_url('admin/users') ?>";
                }
            }, 'json');
        }
        <?php } ?>
    });

});
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('user_management_heading');?></h2>
                <p>
                    <a href="<?php echo site_url('admin/users/create'); ?>" class="btn"><i class="fa fa-plus"></i> <?php echo lang('index_create_user'); ?></a>
                    <a href="<?php echo site_url('admin/users/import'); ?>" class="btn" style="margin-left: 5px;"><i class="fa fa-users"></i> <?php echo lang('index_import_users'); ?></a>
                </p>
                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo lang('index_name_th'); ?></th>
                            <th><?php echo lang('index_email_th'); ?></th>
                            <th><?php echo lang('index_access_level_th'); ?></th>
                            <th><?php echo lang('index_type_th'); ?></th>
                            <th><?php echo lang('index_api_th'); ?></th>
                            <th><?php echo lang('index_action_th'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($users as $user) { ?>
                        <tr>
                            <td>
                                <?php
                                echo $user->username;
                                if (!empty($user->first_name) && !empty($user->last_name)) { 
                                    echo ' (' . $user->first_name . ' ' .$user->last_name . ')'; 
                                } else if (empty($user->last_name) && !empty($this->first_name)) {
                                    echo ' (' . $user->first_name . ')'; 
                                } ?></td>
                            <td><?php echo $user->email;?></td>
                            <td>
                                <?php
                                $level = lang('user_level');
                                foreach ($user->groups as $group) {
                                    if ($group->id == 1) {
                                        $level = lang('admin_level');
                                    }
                                }
                                echo $level; ?>
                            </td>
                            <td>
                                <?php
                                if ($user->type == "ad") {
                                    echo lang('active_directory').' - '.$user->auth_server->name;
                                } else if ($user->type == "ldap") {
                                    echo lang('ldap').' - '.$user->auth_server->name;
                                } else {
                                    echo "Local";
                                }
                                ?>
                            </td>
                            <td><?php if ($user->apiaccess) { echo lang('yes_button'); } else { echo lang('no_button'); } ?></td>
                            <td>
                                <?php echo anchor("admin/users/edit/".$user->id, lang("edit")) ;?>
                                <?php if ($user->id != $myuserid && $user->id != 1) { ?>
                                &bull; <a href="#" class="remove" data-id="<?php echo $user->id; ?>"><?php echo lang('delete'); ?></a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>