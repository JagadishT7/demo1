<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('leftbar_updates'); ?></li>
</ul>

<script type="text/javascript">
var command_id = '';

$(document).ready(function() {

    $('#check').click(function() {
        $('#update-avail').hide();
        $('#update-no').hide();
        $('#update-box').addClass('inline').show();

        // Do an update check...
        $.post(site_url + 'api/system/do_update_check', { <?php echo get_csrf_block(); ?> }, function(data) {
            $('.fa-spinner').hide();

            if (data.update_available) {
                $('#version').html(data.update_version);
                $('#update-avail').show();
            } else {
                $('#update-no').show();
            }

        }, 'json');
    });

    $('#update-now').click(function() {
        var can_update = confirm("<?php echo lang('update_are_you_sure'); ?>");
        if (can_update) {
            run_upgrade_command();
        }
    });

});

function run_upgrade_command() {
    $('#update-check').hide();
    $('#update-logs').hide();
    $('#start').show();
    $.post(site_url + "api/system/do_upgrade", { <?php echo get_csrf_block(); ?> }, function (data) {
        started_updating = 0;
        if (data.error == 1) {
            $('#update_error').html(data.message).show();
        } else {
            command_id = data.command_id;
            $('#updating').show();
            $('#updating_container span i').show();
            setInterval(watch_command, 1000);
        }
    }, 'json');
}

function watch_command() {
    if (command_id != '') // If command is running
    {
        $('#start').hide();
        $('#updating_container').show();
        $('#updating_text').fadeIn(600);
        $('#output').fadeIn(600);

        // If the update finishes, we should stop the updating
        $.post(site_url + "api/system/get_upgrade", {
            command_id: command_id,
            <?php echo get_csrf_block(); ?>
        }, function (data) {
            if (!data.running) {
                command_id = '';
                $('#updating_container').removeClass('alert-info').addClass('alert-success');
                $('#updating').hide();
                $('#updating_text').html('<?php echo lang("update_completed"); ?>.');
            }

            // Make sure to update data output
            $('#output').html(data.stream);
            $('#output').scrollTop($('#output')[0].scrollHeight);

        }, 'json');
    }
}

</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside updates">
                <h2><?php echo lang('leftbar_updates'); ?></h2>
                <p><?php echo lang('update_desc'); ?></p>

                <div id="update-check" style="margin-bottom: 40px; <?php if ($locked) { echo 'display: none;'; } ?>">
                    <p style="margin-bottom: 15px;">
                        <button class="btn btn-default" id="check"><?php echo lang('update_check'); ?></button>
                    </p>
                    <div class="well hide" id="update-box">
                        <span class="hide" id="update-avail">
                            <img src="<?php echo media_url('icons/exclamation.png'); ?>"> <?php echo lang('update_available'); ?>: <strong id="version"></strong>
                            <button class="btn btn-default btn-mini" style="margin-left: 20px;" id="update-now"><?php echo lang('update_now'); ?></button>
                        </span>
                        <span class="hide" id="update-no">
                            <img src="<?php echo media_url('icons/accept.png'); ?>"> <?php echo lang('update_none'); ?>
                        </span>
                        <i class="fa fa-spinner fa-spin"></i>
                    </div>
                </div>

                <div id="start" class="alert alert-info" style="<?php if ($locked) { echo 'display: inline-block;'; } else { echo 'display: none;'; } ?>">
                    <i class="fa fa-spinner fa-spin"></i>
                    <?php echo lang('update_running'); ?>
                </div>

                <div id="updating_container" class="alert alert-info" style="<?php if ($locked) { echo 'display: inline-block;'; } else { echo 'display: none;'; } ?>">
                    <span id="updating" style="margin-right: 8px; font-size: 16px;"><i class="fa fa-spinner fa-spin"></i></span>
                    <span id="updating_text" style="<?php if (!$locked) { echo 'display: inline-block;'; } ?>"><?php echo lang('update_working'); ?></span>
                </div>
        
                <div style="clear: both;"></div>

                <textarea id="output" class="code" style="width: 600px; height: 260px; margin-top: 20px; <?php if (!$locked) { echo 'display: none;'; } ?>" readonly><?php
                    if ($locked) {
                        $logfile = file_get_contents(AU_LOGFILE);
                        print $logfile;
                    }
                    ?></textarea>

                <?php if (!$locked) { ?>
                <div id="update-logs">
                    <h4><?php echo lang('update_logs'); ?></h4>
                    <table class="table table-bordered table-condensed table-striped" style="min-width: 500px; width: auto;">
                        <thead> 
                            <tr>
                                <th><?php echo lang('update_th1'); ?></th>
                                <th><?php echo lang('update_th2'); ?></th>
                                <th><?php echo lang('update_th3'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($upgrades) > 0) { ?>
                            <?php foreach ($upgrades as $u) { ?>
                            <tr>    
                                <td><?php echo $u['date']; ?></td>
                                <td><?php echo $u['file']; ?></td>
                                <td><?php echo $u['status']; ?></td>
                            </tr>
                            <?php }
                            } else { ?>
                            <tr>
                                <td colspan="3"><?php echo lang('update_no_logs'); ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>

            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>