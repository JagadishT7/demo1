<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('admin/auth_servers'); ?>"><?php echo lang('breadcrumb_ldap_ad_servers'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_ldap_ad_edit_server'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    setup_form();

    // Activate tool tips
    $('.tt').tooltip();

    // Change what's displayed when the server type changes
    $('#type').change(function() {
        setup_form();
    });

});

function setup_form() {
    if ($('#type').val() == "ldap") {
        $('.ad-specific').hide();
        $('.ldap-specific').show();
    } else {
        $('.ad-specific').show();
        $('.ldap-specific').hide();
    }
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('ldap_ad_edit_server_title'); ?></h2>
                <p><?php echo lang('ldap_ad_add_server_desc'); ?></p>

                <div class="alert alert-error <?php if (empty($errors)) { echo "hide"; } ?>">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php if (!empty($errors)) { echo $errors; } ?>
                </div>
                
                <?php echo form_open(); ?>
                    <div class="form-horizontal well fl" style="margin-bottom: 15px;">
                        <div style="margin: 20px;">
                            <div class="control-group" style="margin-bottom: 12px;">
                                <label class="control-label" for="type"><?php echo lang('ldap_ad_server_type'); ?></label>
                                <div class="controls">
                                    <select id="type" name="type">
                                        <option value="ad" <?php if (!empty($type)) { if ($type == "ad") { echo "selected"; } } ?>>Active Directory</option>
                                        <option value="ldap" <?php if (!empty($type)) { if ($type == "ldap") { echo "selected"; } } ?>>LDAP</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group" style="margin-bottom: 12px;">
                                <div class="controls">
                                    <label class="checkbox" style="display: inline-block;">
                                        <input type="checkbox" name="enabled" value="1" <?php if (!isset($enabled)) { echo "checked"; } else { if (!empty($enabled)) { echo "checked"; } } ?>> <?php echo lang('enabled'); ?> <i class="fa fa-question-circle tt" title="<?php echo lang('ldap_ad_enabled_desc'); ?>"></i>
                                    </label>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="name"><?php echo lang('ldap_ad_server_name'); ?></label>
                                <div class="controls">
                                    <input type="text" id="name" name="name" value="<?php if (!empty($name)) { echo $name; } ?>">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_server_name_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="basedn"><?php echo lang('ldap_ad_basedn'); ?></label>
                                <div class="controls">
                                    <input type="text" id="basedn" name="basedn" value="<?php if (!empty($basedn)) { echo $basedn; } ?>" style="width: 300px;" placeholder="DC=nagios,DC=com">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_basedn_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group ad-specific hide">
                                <label class="control-label" for="suffix"><?php echo lang('ldap_ad_account_suffix'); ?></label>
                                <div class="controls">
                                    <input type="text" id="suffix" name="suffix" value="<?php if (!empty($suffix)) { echo $suffix; } ?>" placeholder="@nagios.com">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_account_suffix_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group ad-specific hide">
                                <label class="control-label" for="controllers"><?php echo lang('ldap_ad_controllers'); ?></label>
                                <div class="controls">
                                    <input type="text" id="controllers" name="controllers" value="<?php if (!empty($controllers)) { echo $controllers; } ?>" style="width: 400px;" placeholder="dc1.nagios.com,dc2.nagios.com">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_controllers_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group ldap-specific hide">
                                <label class="control-label" for="host"><?php echo lang('ldap_ad_ldap_host'); ?></label>
                                <div class="controls">
                                    <input type="text" id="host" name="host" value="<?php if (!empty($host)) { echo $host; } ?>" placeholder="ldap.nagios.com">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_ldap_host_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group ldap-specific hide">
                                <label class="control-label" for="port"><?php echo lang('ldap_ad_ldap_port'); ?></label>
                                <div class="controls">
                                    <input type="text" id="port" name="port" value="<?php if (!empty($port)) { echo $port; } else { echo "389"; } ?>" style="width: 50px;">
                                    <div class="subcontrol"><?php echo lang('ldap_ad_ldap_port_desc'); ?></div>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="encryption"><?php echo lang('ldap_ad_encryption'); ?></label>
                                <div class="controls">
                                    <select id="encryption" name="encryption" style="width: 100px;">
                                        <option value="none" <?php if (!empty($encryption)) { if ($encryption == "none") { echo "selected"; } } ?>>None</option>
                                        <option value="ssl" <?php if (!empty($encryption)) { if ($encryption == "ssl") { echo "selected"; } } ?>>SSL</option>
                                        <option value="tls" <?php if (!empty($encryption)) { if ($encryption == "tls") { echo "selected"; } } ?>>TLS</option>
                                    </select>
                                    <div class="subcontrol"><?php echo lang('ldap_ad_encryption_desc'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <button type="submit" name="save" value="1" class="btn btn-primary"><?php echo lang('ldap_ad_save_server'); ?></button>
                    <a href="<?php echo site_url('admin/auth_servers'); ?>" class="btn btn-default" style="margin-left: 10px;"><?php echo lang('cancel_button'); ?></a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>