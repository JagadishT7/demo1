<?php echo $header; ?>

<script>
    $(document).ready(function() {

        $('.upload-button').click(function() {
            $('.real-upload').click();
        });

        $('.real-upload').change(function() {
            var file_input = $('.real-upload')[0];
            var filename = file_input.files.item(0).name;
            $('.upload-filename').val(filename);
        });

        $('.add-certificate').click(function() {
            $('#add-certificate-modal').modal('show');
        });

        // Popup the window to load in a certificate
        $("#add-certificate-modal").on("paste", "textarea.ajax-validated", function(e) {
            $(".ca-error").addClass('hide');
            $('textarea.ajax-validated').removeClass('form-error');
            var elem = $(this);
            setTimeout(function() {

                var cert = elem.val();
                $.post(site_url + "api/LDAP/add_certificate", { cert: cert, verify: true }, function(data) {

                    if (data.error) {
                        $(".ca-error").html(data.message).removeClass('hide');
                        $('textarea.ajax-validated').addClass('form-error');
                        $('.btn-primary.raw-input').attr('disabled', 'disabled');
                    }
                    else {
                        $(".ca-host").attr('disabled', false).val(data.subject.CN);
                        $('.btn-primary.raw-input').attr('disabled', false);
                    }
                }, "json");
            }, 200);
        });

        // Actually add the certificate when clicking the button
        $(".btn-primary.raw-input").on("click", function(e) {
            $(".ca-error").addClass('hide');
            $('textarea.ajax-validated').removeClass('form-error');

            var cert = $("textarea.ajax-validated").val();

            $.post(site_url + 'api/LDAP/add_certificate', { cert: cert }, function(data) {

                if (data.error) {
                    alert(data.message);
                } else {

                    setTimeout(function () {
                        load_certificates();
                    }, 200);
                }

                $('.btn-primary.raw-input').attr('disabled', true);
                $('.ca-host').val('').attr('disabled', true);
                $('textarea.ajax-validated').val('').removeClass('form-error');
            }, "json");
        });

        load_certificates();
    });

function load_certificates() {
    $.post(site_url + 'api/LDAP/get_certificates', function(certs) {
        if (certs === false) {
            return;
        }

        var table_text = '';
        for (ind in certs) {
            table_text += '<tr><td>' + certs[ind]['subject']['CN'] + '</td><td>' + certs[ind]['issuer']['CN'] + '</td><td>' + new Date(certs[ind]['validTo_time_t']) + '</td><td><a><i class="fa fa-times remove-certificate" data-id="' + ind + '" ></i></button></a></td></tr>';
        }

        if (table_text === '') {
            table_text = '<tr><td colspan="4"><?php echo _("No certificates have been added.");?></td></tr>';
        }
        $('.certificates-go-here').html(table_text);

        $('.remove-certificate').off('click');
        $('.remove-certificate').on('click', function() {

            var id = $(this).data('id');

            var conf = confirm('<?php echo _("Are you sure you want to delete this certificate?");?>');
            if (!conf) {
                return;
            }

            $.post(site_url + 'api/LDAP/remove_certificate', {id: id}, function(ret_bool) {

                if (!ret_bool) {
                    alert("Failed to remove certificate.");
                }

                load_certificates();

            }, 'json');
        });
    }, 'json');
}
</script>


<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_ldap_ad_servers'); ?></li>
</ul>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('ldap_ad_header'); ?></h2>
                <p><?php echo lang('ldap_ad_desc'); ?> <a href="<?php echo site_url('admin/users/import'); ?>"><?php echo lang('ldap_ad_import'); ?></a>.</p>
                <p style="margin-bottom: 15px;"><a href="<?php echo site_url('admin/add_auth_server'); ?>" class="btn btn-default"><i class="fa fa-plus"></i> <?php echo lang('ldap_ad_add_server'); ?></a></p>
                <table class="table table-striped table-hover table-bordered" style="width: auto; min-width: 60%;">
                    <thead>
                        <tr>
                            <th style="width: 20px; text-align: center;"></th>
                            <th><?php echo lang('name'); ?></th>
                            <th><?php echo lang('servers'); ?></th>
                            <th style="width: 140px;"><?php echo lang('type'); ?></th>
                            <th style="width: 80px;"><?php echo lang('encryption'); ?></th>
                            <th style="width: 120px;"><?php echo lang('associated_users'); ?></th>
                            <th style="width: 80px; text-align: center;"><?php echo lang('actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (count($servers) > 0) {
                            foreach ($servers as $server) {
                        ?>
                        <tr>
                            <td style="text-align: center;"><?php if ($server->active == 1) { echo '<img src="'.media_url('icons/accept.png').'" title="'.lang('enabled').'">'; } ?></td>
                            <td><?php echo $server->name; ?></td>
                            <td><?php if ($server->type == "ad") { echo $server->controllers; } else { echo $server->host; } ?></td>
                            <td><?php if ($server->type == "ad") { echo lang('active_directory'); } else if ($server->type == "ldap") { echo lang('ldap'); } ?></td>
                            <td><?php echo strtoupper($server->encryption); ?></td>
                            <td><?php echo $server->associated_users; ?></td>
                            <td style="font-size: 18px; text-align: center;">
                                <a href="<?php echo site_url('admin/edit_auth_server/'.$server->id); ?>" title="<?php echo lang('edit'); ?>"><i class="fa fa-wrench"></i></a>
                                <?php if ($server->associated_users == 0) { ?><a href="<?php echo site_url('admin/delete_auth_server/'.$server->id); ?>" title="<?php echo lang('remove_server'); ?>" style="margin-left: 10px;"><i class="fa fa-times"></i></a><?php } ?>
                            </td>
                        </tr>
                        <?php
                            }
                        } else {
                        ?>
                        <tr>
                            <td colspan="7"><?php echo lang('ldap_ad_no_servers'); ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                
                <h5>
                    <?php echo lang('ldap_ad_ca_management_header');?>
                </h5>
                <p><?php echo lang('ldap_ad_ca_management_description');?></p>
                <p style="margin-bottom: 10px;"><a class="btn btn-sm btn-default add-certificate"><i class="fa fa-plus"></i> <?php echo lang('ldap_ad_add_cert'); ?></a></p>
                <table class="table table-striped table-hover table-condensed table-bordered table-va-middle" style="width: auto; min-width:60%;">
                    <thead>
                        <tr>
                            <th><?php echo lang('ldap_ad_hostname');?></th>
                            <th><?php echo lang('ldap_ad_issuer_ca');?></th>
                            <th><?php echo lang('ldap_ad_expiration_date');?></th>
                            <th style="width: 80px; text-align: center;"><?php echo lang('actions');?></th>
                        </tr>
                    </thead>
                    <tbody class="certificates-go-here">
                        <tr>
                            <td colspan="4"><?php echo lang('ldap_ad_no_certs');?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal hide" id="add-certificate-modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3><?php echo lang('ldap_ad_add_cert');?><span class="snapshot-time"></span></h3>
            </div>
            <div class="modal-body">
                <p><?php echo lang('ldap_ad_cert_desc'); ?></p>
                <div class="form-horizontal">
                    <div class="form-group" style="padding-bottom: 10px">
                        <h5><?php echo lang('ldap_ad_hostname');?>:</h5>
                        <input class="form-control ca-host" style="width: 300px" type="text" value="" disabled>
                    </div>
                    <div class="form-group">
                        <h5><?php echo lang('ldap_ad_cert'); ?>:</h5>
                        <textarea class="form-control ajax-validated" placeholder="" style="height: 300px; resize: vertical; font-family: monospace; font-size: 13px; width: calc(100% - 14px);"></textarea>
                        <span class="ca-error hide" style="color: red; font-weight: bold; border-top: 10px;"><?php echo lang('ldap_ad_certificate_invalid');?></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default" data-dismiss="modal" aria-hidden="true"><?php echo lang('close'); ?></button>
                <button class="btn btn-sm btn-primary raw-input" data-dismiss="modal" aria-hidden="true" disabled><?php echo lang('add'); ?></button>
            </div>
        </div>
    </div>
</div>


<?php echo $footer; ?>