        <div class="lside admin-leftbar">
            <div class="well" style="padding: 8px 0; min-height: 355px;">
                <ul class="nav nav-list">
                    <li class="nav-header"><?php echo lang('leftbar_dashboards'); ?></li>
                    <?php if ($tab == "system") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin'); ?>"><i class="fa fa-tachometer"></i> <?php echo lang('leftbar_system_dashboard_link'); ?></a></li>
                    <li class="nav-header"><?php echo lang('leftbar_general'); ?></li>
                    <?php if ($tab == "globals") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/globals'); ?>"><i class="fa fa-globe"></i> <?php echo lang('leftbar_global_defaults_link'); ?></a></li>
                    <?php if ($tab == "updates") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/updates'); ?>"><i class="fa fa-check-circle-o"></i> <?php echo lang('leftbar_updates'); ?></a></li>
                    <li class="nav-header"><?php echo lang('leftbar_auth'); ?></li>
                    <?php if ($tab == "users") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/users'); ?>"><i class="fa fa-user"></i> <?php echo lang('leftbar_users_link'); ?></a></li>
                    <?php if ($tab == "auth_servers") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/auth_servers'); ?>"><i class="fa fa-database"></i> <?php echo lang('leftbar_ldap_ad_servers'); ?></a></li>
                    <li class="nav-header"><?php echo lang('leftbar_license'); ?></li>
                    <?php if ($tab == "license") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/license'); ?>"><i class="fa fa-key"></i> <?php echo lang('leftbar_license_link'); ?></a></li>
                    <li class="nav-header"><?php echo lang('leftbar_backup'); ?></li>
                    <?php if ($tab == "backup") { echo '<li class="active">'; } else { echo '<li>'; } ?><a href="<?php echo site_url('admin/backup'); ?>"><i class="fa fa-file-archive-o"></i> <?php echo lang('leftbar_backup_link'); ?></a></li>
                </ul>
            </div>
        </div>