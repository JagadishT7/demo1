<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_globals'); ?></li>
</ul>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('breadcrumb_globals'); ?></h2>
                <p><?php echo lang('globals_desc'); ?></p>
                <?php if (!empty($success)) { ?><div class="alert alert-success"><?php echo $success; ?></div><?php } ?>
                <?php if ($error) { ?><div class="alert alert-error"><?php echo $error; ?></div><?php } ?>
                <div class="form-horizontal">
                    <?php echo form_open('admin/globals'); ?>
                    <div class="well" style="margin-bottom: 10px;">
                        <div class="control-group" style="margin-bottom: 10px;">
                            <label class="control-label" for="language"><?php echo lang('globals_default_language'); ?>:</label>
                            <div class="controls">
                                <select id="language" name="language" class="input-medium">
                                    <?php foreach ($languages as $l) { ?>
                                    <option value="<?php echo $l; ?>" <?php if ($global_language == $l) { echo 'selected'; } ?>><?php echo lang('language_' . $l); ?></option>
                                    <?php } ?>
                                </select>
                                <p><?php echo lang('globals_default_language_desc'); ?></p>
                            </div>
                        </div>
                        <div class="control-group" style="margin-bottom: 15px;">
                            <label class="control-label"><?php echo lang('global_resolve_host'); ?>:</label>
                            <div class="controls">
                                <label class="checkbox" style="display: inline-block;">
                                    <input type="checkbox" value="1" <?php if ($resolve_hosts) { echo "checked"; } ?> name="resolve_hosts" id="reshosts">
                                    <?php echo lang('global_resolve_host_rq'); ?>
                                </label>
                                <label class="checkbox" style="display: inline-block; margin-left: 10px;">
                                    <input type="checkbox" value="1" <?php if ($resolve_hosts_graphs) { echo "checked"; } ?> name="resolve_hosts_graphs" id="reshostsg">
                                    <?php echo lang('global_resolve_host_g'); ?>
                                </label>
                                <p><?php echo lang('global_resolve_host_desc'); ?></p>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="cache_time"><?php echo lang('global_cache_time'); ?>:</label>
                            <div class="controls">
                                <input type="text" name="cache_time" id="cache_time" value="<?php echo $cache_time; ?>" style="width: 80px;">
                                <p><?php echo lang('global_cache_time_desc'); ?></p>
                            </div>
                        </div>
                        <div class="control-group" style="margin-bottom: 15px;">
                            <label class="control-label" for="relmax"><?php echo lang('global_rel_mapping'); ?>:</label>
                            <div class="controls">
                                <input type="text" value="<?php echo $rel_map_max; ?>" name="rel_map_max" id="relmax" style="width: 50px;">
                                <p><?php echo lang('global_rel_mapping_desc'); ?></p>
                            </div>
                        </div>
                        <div class="control-group end">
                            <label class="control-label" for="tz"><?php echo lang('global_timezone'); ?>:</label>
                            <div class="controls">
                                <select name="timezone" id="tz" style="width: 300px;">
                                    <?php
                                    $cur_timezone = get_current_timezone();
                                    if (!empty($set_timezone)) { $cur_timezone = $set_timezone; }
                                    foreach (get_timezones() as $name => $val) {
                                    ?>
                                    <option value="<?php echo $val; ?>" <?php if ($val == $cur_timezone) { echo 'selected'; } ?>><?php echo $name; ?></option>
                                    <?php } ?>
                                </select>
                                <p><?php echo lang('global_timezone_desc'); ?></p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <button <?php if ($demo_mode) { echo 'disabled'; } ?> type="submit" value="1" name="saveglobals" class="btn btn-primary"><?php echo lang('global_save_button'); ?></button>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>