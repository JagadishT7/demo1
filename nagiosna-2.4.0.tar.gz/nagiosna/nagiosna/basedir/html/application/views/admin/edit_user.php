<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('admin/users'); ?>"><?php echo lang('breadcrumb_users'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('breadcrumb_edit_user'); ?></li>
</ul>

<script type="text/javascript">
var USERID = <?php echo $user->id; ?>;
$(document).ready(function() {

    show_correct_fields();

    $('#account_type').change(function() {
        show_correct_fields();
    });

});

function show_correct_fields()
{
    var type = $('#account_type').val();

    if (type == "ldap") {
        $('.ad-required').hide();
        $('.ldap-required').show();
        $('.pw-box').hide();
    } else if (type == "ad") {
        $('.ldap-required').hide();
        $('.ad-required').show();
        $('.pw-box').hide();
    } else {
        $('.ldap-required').hide();
        $('.ad-required').hide();
        $('.pw-box').show();
    }

    if (USERID == 1) {
        $('.pw-box').show();
    }
}
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('edit_user_heading'); ?></h2>
                <p><?php echo lang('edit_user_subheading'); ?></p>
                <?php if (!empty($msg)) { ?><div class="alert alert-success"><?php echo $msg; ?></div><?php } ?>
                <?php if (!empty($error)) { ?><div class="alert alert-error"><?php echo $error; ?></div><?php } ?>
                <?php echo form_open('admin/users/edit/' . $user->id); ?>
                <div class="row-fluid">
                    <div class="span6">
                        <h4><?php echo lang('create_user_details_heading'); ?></h4>
                        <table>
                            <tr>
                                <td class="form-left" style="width: 140px;"><?php echo lang('create_user_name'); ?>:</td>
                                <td>
                                    <input type="text" name="first_name" value="<?php if (set_value('first_name')) { echo set_value('first_name'); } else { echo $user->first_name; } ?>" class="input-medium"> 
                                    <input type="text" name="last_name" value="<?php if (set_value('last_name')) { echo set_value('last_name'); } else { echo $user->last_name; } ?>" class="input-medium">
                                </td>
                            </tr>
                            <tr>
                                <td class="form-left"><?php echo lang('create_user_company'); ?>:</td>
                                <td><input type="text" name="company" value="<?php if (set_value('company')) { echo set_value('company'); } else { echo $user->company; } ?>" class="input-xlarge"></td>
                            </tr>
                            <tr>
                                <td class="form-left"><?php echo lang('create_user_email'); ?>:</td>
                                <td><input type="text" name="email" value="<?php if (set_value('email')) { echo set_value('email'); } else { echo $user->email; } ?>" class="input-xlarge"> *</td>
                            </tr>
                            <tr>
                                <td class="form-left"><?php echo lang('create_user_phone'); ?>:</td>
                                <td><input type="text" name="phone" value="<?php if (set_value('phone')) { echo set_value('phone'); } else { echo $user->phone; } ?>" class="input-small" maxlength="10"></td>
                            </tr>
                        </table>
                        <h4><?php echo lang('create_user_account_heading'); ?></h4>
                        <table>
                            <tr>
                                <td class="form-left" style="width: 140px;"><?php echo lang('create_user_username'); ?>:</td>
                                <td><input type="text" name="username" value="<?php echo $user->username; ?>" class="input" disabled></td>
                            </tr>
                            <tr class="pw-box">
                                <td class="form-left"><?php echo lang('create_user_password'); ?>:</td>
                                <td><input type="password" name="password" value="<?php echo set_value('password'); ?>" class="input-medium"> *</td>
                            </tr>
                            <tr class="pw-box">
                                <td class="form-left"><?php echo lang('create_user_conf_password'); ?>:</td>
                                <td><input type="password" name="password2" value="<?php echo set_value('password2'); ?>" class="input-medium"> *</td>
                            </tr>
                            <tr>
                                <td class="form-left"><?php echo lang('language'); ?>:</td>
                                <td>
                                    <select name="language" class="input-medium">
                                        <option value="default" <?php if ($user->lang == 'default') { echo 'selected'; } ?>><?php echo lang('default'); ?></option>
                                        <?php foreach ($languages as $l) { ?>
                                        <option value="<?php echo $l; ?>" <?php if ($user->lang == $l) { echo 'selected'; } ?>>
                                            <?php $output = lang('language_' . $l); if (empty($output)) { echo uppercase($l); } else { echo $output; } ?>
                                        </option>
                                        <?php } ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <h4><?php echo lang('create_user_account_auth'); ?></h4>
                        <p><?php echo lang('create_user_account_auth_desc'); ?></p>

                        <?php if ($user->id == 1) { ?>
                        <div class="alert alert-info">
                            <?php echo lang('superuser_auth_warning'); ?>
                        </div>
                        <?php } ?>

                        <table style="width: 100%;">
                            <tr>
                                <td class="form-left" style="width: 140px;"><?php echo lang('ldap_ad_auth_type'); ?>:</td>
                                <td>
                                    <select name="account_type" id="account_type">
                                        <option value="local" <?php if ($user->type == "local") { echo "selected"; } ?>><?php echo lang('ldap_ad_local'); ?></option>
                                        <option value="ad" <?php if (empty($ad_servers)) { echo "disabled"; } if ($user->type == "ad") { echo "selected"; } ?>><?php echo lang('active_directory'); ?> <?php if (empty($ad_servers)) { ?>(<?php echo lang('no_servers'); ?>)<?php } ?></option>
                                        <option value="ldap" <?php if (empty($ldap_servers)) { echo "disabled"; } if ($user->type == "ldap") { echo "selected"; } ?>><?php echo lang('ldap'); ?> <?php if (empty($ldap_servers)) { ?>(<?php echo lang('no_servers'); ?>)<?php } ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr class="hide ldap-required">
                                <td class="form-left"><?php echo lang('ldap_server'); ?>:</td>
                                <td>
                                    <select name="ldap_server" id="ldap_server" style="min-width: 340px;">
                                        <?php foreach ($ldap_servers as $ldap) { ?>
                                        <option value="<?php echo $ldap->id; ?>"><?php echo $ldap->name.' ('.$ldap->host.')'; ?></option>
                                        <?php } ?>
                                    </select>
                                </td>
                            </tr>
                            <tr class="hide ad-required">
                                <td class="form-left"><?php echo lang('ad_server'); ?>:</td>
                                <td>
                                    <select name="ad_server" id="ad_server" style="min-width: 340px;">
                                        <?php foreach ($ad_servers as $ad) { ?>
                                        <option value="<?php echo $ad->id; ?>"><?php echo $ad->name.' ('.$ad->controllers.')'; ?></option>
                                        <?php } ?>
                                    </select>
                                </td>
                            </tr>
                            <tr class="hide ad-required">
                                <td class="form-left">AD Username:</td>
                                <td>
                                    <input type="text" name="ad_username" id="ad_username" <?php if (!empty($user->auth_server_data['username'])) { echo 'value="'.$user->auth_server_data['username'].'"'; } ?> style="min-width: 160px;">
                                </td>
                            </tr>
                            <tr class="hide ldap-required">
                                <td class="form-left">User's Full DN:</td>
                                <td>
                                    <input type="text" name="dn" <?php if (!empty($user->auth_server_data['dn'])) { echo 'value="'.$user->auth_server_data['dn'].'"'; } ?> placeholder="cn=John Smith,dn=nagios,dc=com" style="min-width: 280px; width: 75%;">
                                </td>
                            </tr>
                            <tr class="hide">
                                <td></td>
                                <td>
                                    <input type="checkbox"> 
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="span6">
                        <h4><?php echo lang('create_user_al_title'); ?></h4>
                        <p><?php echo lang('create_user_al_desc'); ?></p>
                        <label class="radio"><input type="radio" name="group" value="1" <?php if ($admin_checked) { echo "checked"; } if ($user->id == 1) { echo ' disabled'; } ?>> <strong><?php echo lang('create_user_al_admin'); ?></strong> - <?php echo lang('create_user_al_admin_desc'); ?></label>
                        <label class="radio"><input type="radio" name="group" value="2" <?php if ($user_checked) { echo "checked"; } if ($user->id == 1) { echo ' disabled'; } ?>> <strong><?php echo lang('create_user_al_user'); ?></strong> - <?php echo lang('create_user_al_user_desc'); ?></label>
                        <h4><?php echo lang('create_user_api_title'); ?></h4>
                        <p><?php echo lang('create_user_api_desc'); ?></p>
                        <label class="radio">
                            <input type="radio" name="apiaccess" value="1" <?php if ($user->apiaccess) { echo "checked"; } ?>> <?php echo lang('yes_button'); ?>
                        </label>
                        <label class="radio">
                            <input type="radio" name="apiaccess" value="0" <?php if (!$user->apiaccess) { echo "checked"; } ?>> <?php echo lang('no_button'); ?>
                        </label>
                    </div>
                </div>
                <div class="row-fluid">
                    <div class="span12">
                        <div style="margin-top: 15px; margin-bottom: 0;" class="form-actions">
                            <button type="submit" class="btn btn-primary"><?php echo lang('edit_user_submit_btn'); ?></button>
                            <a href="<?php echo site_url('admin/users'); ?>" class="btn"><?php echo lang('cancel_button'); ?></a>
                        </div>
                    </div>
                </div>
                <?php echo form_close();?>

            </div>
        </div>
    </div>
</div>


<?php echo $footer; ?>