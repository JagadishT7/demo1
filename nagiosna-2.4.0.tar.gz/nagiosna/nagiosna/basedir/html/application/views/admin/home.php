<?php echo $header; ?>

<ul class="breadcrumb">
    <li class="active"><?php echo lang('header_tab_configure'); ?></li>
</ul>

<script>
function sort_alphabetically(a,b)
{
    return b.name.toLowerCase() < a.name.toLowerCase();
}

function draw_status_dashboard()
{
    var STATUSDIV = '#sourcestatustable';
    $(STATUSDIV).empty();
    
    $.getJSON(site_url + 'api/sources/read', function(data) {
        data.sort(sort_alphabetically);
        $.each(data, function(i, d) {
            var sid = d.sid;
            var name = d.name;
            var node = $('<tr>');
            node.appendTo(STATUSDIV);
            $.getJSON(site_url + 'api/system/source_status/' + sid, function(r) {
                var usage = r.diskusage;
                var icon = r.icon;
                var status;
                if(r.status == 'Stopped') {
                    status = 'error';
                } else {
                    status = 'success';
                }
                node.addClass(status);
                node.html('<td><a href="' + site_url + 'sources/' + sid + '">' + name + '</a></td>' +
                                        '<td style="text-align:center">' + usage + '</td>' +
                                        '<td style="text-align:center">' + icon + '</td>' +
                                    '</tr>');
            });
        });
    });
}

$(document).ready(function() {
    
    var gauges = {};
    
    gauges['cpu'] = create_gauge('cpustatus', '<?php echo lang("guage_cpu"); ?>', '/nagiosna/api/system/cpu_status', 'cpu_usage', 1);
    gauges['disk'] = create_gauge('diskstatus', '<?php echo lang("guage_disk"); ?>', '/nagiosna/api/system/root_drive_status', 'percent', 1); 
    gauges['memory'] = create_gauge('memorystatus', '<?php echo lang("guage_mem"); ?>', '/nagiosna/api/system/memory_status', 'used_percent', 1);
    gauges['swap'] = create_gauge('swapstatus', '<?php echo lang("guage_swap"); ?>', '/nagiosna/api/system/memory_status', 'swap_percent', 1);
    
    for(var key in gauges) {
        gauges[key].render();
    }
    
    setInterval(function() {
        for(var key in gauges) {
            gauges[key].redraw(500);
        }
    }, 5000);

    draw_status_dashboard();

    setInterval(function() {
        draw_status_dashboard();
    }, 60000);

});
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('dashboard_system'); ?></h2>
                <div class="row-fluid">
                    <div class="span12 well">
                        <div class="gauge centerme span2">
                            <strong><?php echo lang('dashboard_system_cpu'); ?> %</strong>
                            <div id='cpustatus'></div>
                        </div>
                        <div class="gauge centerme span2">
                            <strong><?php echo lang('dashboard_system_disk'); ?> %</strong>
                            <div id='diskstatus'></div>
                        </div>
                        <div class="gauge centerme span2">
                            <strong><?php echo lang('dashboard_system_memory'); ?> %</strong>
                            <div id='memorystatus'></div>
                        </div>
                        <div class="gauge centerme span2">
                            <strong><?php echo lang('dashboard_system_swap'); ?> %</strong>
                            <div id='swapstatus'></div>
                        </div>
                        <div class="span4">
                            <div class="make-me-scroll" id="sourcestatusdiv">
                                <table class="source-scroll table table-condensed">
                                    <thead>
                                        <tr>
                                            <th><?php echo lang('dashboard_system_table_name'); ?></th>
                                            <th style="width: 15px;"><?php echo lang('dashboard_system_table_usage'); ?></th>
                                            <th style="width: 15px;"><?php echo lang('dashboard_system_table_status'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="sourcestatustable">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>