<?php echo $header; ?>

<ul class="breadcrumb">
    <li><a href="<?php echo site_url('admin'); ?>"><?php echo lang('header_tab_configure'); ?></a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('admin/users'); ?>"><?php echo lang('breadcrumb_users'); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo lang('index_import_users'); ?></li>
</ul>

<script type="text/javascript">
$(document).ready(function() {

    $('#create').click(function() {

        $.get(site_url + 'api/system/get_users', { }, function(data) {
            var alerts = [];
            var all_usernames = [];

            $.each(data, function(k, v) {
                all_usernames.push(v.username);
            });

            $.each($('.email'), function(k, v) {
                var email = $(v).val();
                if (email == '' || email.length < 4 || email.indexOf('@') == -1) {
                    $(v).addClass('req');
                    if (alerts.indexOf('email') == -1) {
                        alerts.push('email');
                    }
                }
            });

            $.each($('.username'), function(k, v) {
                if (all_usernames.indexOf($(v).val()) != -1) {
                    $(this).addClass('req');
                    if (alerts.indexOf('username') == -1) {
                        alerts.push('username');
                    }
                }
            });
            
            // Submit the form manually or show an error...
            if (alerts.length == 0) {
                $('#main-alert').hide();
                $('form').submit();
            } else {
                var alert_text = '';
                $.each(alerts, function(k, v) {
                    if (v == 'email') {
                        alert_text += '<?php echo lang("ldap_ad_import_error_emails"); ?> ';
                    } else if (v == 'username') {
                        alert_text += '<?php echo lang("ldap_ad_import_error_usernames"); ?> ';
                    }
                });

                $('#main-alert-text').html(alert_text);
                $('#main-alert').show();
            }

        });

        return false;
    });

    $('.email').blur(function() {
        if ($(this).hasClass('req')) {
            if ($(this).val() != '') {
                $(this).removeClass('req');
            }
        }
    });

    $('.username').blur(function() {
        $(this).removeClass('req');
    });

});
</script>

<div class="container">
    <div class="row-fluid">
        <div class="span12 configure-layout">
            <?php echo $leftbar; ?>
            <div class="rside">
                <h2><?php echo lang('ldap_ad_import_title'); ?></h2>
                <p><?php echo lang('ldap_ad_import_desc_step3'); ?></p>
                <h4><?php echo lang('ldap_ad_import_step3_subtitle'); ?></h4>

                <div class="alert alert-error hide" id="main-alert">
                    <span id="main-alert-text"></span>
                </div>

                <?php echo form_open('admin/users/import/complete'); ?>
                <table class="table table-striped table-bordered table-hover import-users-table">
                    <thead>
                        <tr>
                            <th></th>
                            <th><?php echo lang('profile_full_name'); ?></th>
                            <th><?php echo lang('profile_username'); ?> <span class="red tt_bind" title="Required">*</span></th>
                            <th><?php echo lang('profile_email'); ?> <span class="red tt_bind" title="Required">*</span></th>
                            <th><?php echo lang('user_type'); ?> <span class="red tt_bind" title="Required">*</span></th>
                            <th><?php echo lang('api_access'); ?></th>
                            <th><?php echo lang('ldap_ad_auth_type'); ?></th>
                            <th><?php echo lang('ldap_ad_auth_identifier'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($new_users as $i => $user) { ?>
                        <tr>
                            <td>
                                <input type="checkbox" value="1" name="import[<?php echo $i; ?>]" checked style="margin-top: 9px;" class="tt_bind" title="<?php echo lang('ldap_ad_selected_desc'); ?>">
                            </td>
                            <td>
                                <input type="text" class="name" name="first_name[<?php echo $i; ?>]" value="<?php echo $user['firstname']; ?>">
                                <input type="text" class="name" name="last_name[<?php echo $i; ?>]" value="<?php echo $user['lastname']; ?>">
                            </td>
                            <td>
                                <input type="text" class="username" name="username[<?php echo $i; ?>]" value="<?php echo $user['username']; ?>" style="width: 120px;">
                            </td>
                            <td>
                                <input type="text" class="email" name="email[<?php echo $i; ?>]" value="<?php echo $user['email']; ?>">
                            </td>
                            <td>
                                <select name="level[<?php echo $i; ?>]" style="width: 100px;">
                                    <option value="2"><?php echo lang('user'); ?></option>
                                    <option value="1"><?php echo lang('admin'); ?></option>
                                </select>
                            </td>
                            <td>
                                <select name="apiaccess[<?php echo $i; ?>]" style="width: 70px;">
                                    <option value="1"><?php echo lang('yes_button'); ?></option>
                                    <option value="0" selected><?php echo lang('no_button'); ?></option>
                                </select>
                            </td>
                            <td>
                                <input type="hidden" name="account_type[<?php echo $i; ?>]" value="<?php echo $server->type; ?>">
                                <input type="hidden" name="server_id[<?php echo $i; ?>]" value="<?php echo $server->id; ?>">
                                <input type="text" value="<?php if ($server_type == "ad") { echo lang('active_directory'); } else if ($server_type == "ldap") { echo lang('ldap'); } ?>" disabled style="width: 100px;">
                            </td>
                            <?php if ($server_type == "ad") { ?>
                            <td>
                                <input type="hidden" name="ad_username[<?php echo $i; ?>]" value="<?php echo $user['username']; ?>">
                                <input type="text" value="<?php echo $user['username'].$server->suffix; ?>" disabled style="width: auto;">
                            </td>
                            <?php
                            } else if ($server_type == "ldap") {
                                $size = strlen($user['dn']);
                                $pixels = $size*8;
                                if ($pixels < 100) { $pixels = 100; } else if ($pixels > 300) { $pixels = 300; }
                            ?>
                            <td>
                                <input type="hidden" name="dn[<?php echo $i; ?>]" value="<?php echo $user['dn']; ?>">
                                <input type="text" value="<?php echo $user['dn']; ?>" disabled style="width: <?php echo $pixels; ?>px;">
                            </td>
                            <?php } ?>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <button type="submit" id="create" class="btn btn-primary"><?php echo lang('ldap_ad_create_users'); ?></button>
                <?php echo form_close(); ?>

            </div>
        </div>
    </div>
</div>

<?php echo $footer; ?>