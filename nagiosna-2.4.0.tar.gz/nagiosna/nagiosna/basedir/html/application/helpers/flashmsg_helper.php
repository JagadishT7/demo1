<?php

/**
 *  Shortcuts to make dealing with flash (success/error) messages easier.
 *  Codeigniter's built-in flash message stuff is retrieved on the next
 *  page view, which bugs me.
 **/
    session_start();

    function flash_info($txt)
    {
        $ci =& get_instance();
        $ci->session->set_userdata('info', $txt);
    }
    
    function flash_warning($txt)
    {
        $ci =& get_instance();
        $ci->session->set_userdata('warning', $txt);
    }

    function flash_error($txt)
    {
        $ci =& get_instance();
        $ci->session->set_userdata('error', $txt);
    }

    function flash_success($txt)
    {
        $ci =& get_instance();
        $ci->session->set_userdata('success', $txt);
    }

    function get_flash($type)
    {
        $ci =& get_instance();
        if($messages = $ci->session->userdata($type)) {
            $data = array(
                'type' => $type,
                'messages' => $messages
            );
            $ci->session->unset_userdata($type);
            return $ci->load->view('flash_message.php', $data);
        }
    }
