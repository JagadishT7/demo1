<?php

/**
 * Inserts a command into the cmdsubsys database.
 */
function submit_subsys_command($cmd, $args)
{
    $ci =& get_instance();

    // Insert command into the DB for the subsys to run
    if (is_array($args)) {
        $serialized_args = serialize($args);
    } else {
        $args = '';
    }
    
    $id = uniqid();
    $sql = "INSERT INTO nagiosna_cmdsubsys (id, timestamp, command, args) VALUES ('".$id."', '".time()."', ".intval($cmd).", '".$serialized_args."');";
    $ci->db->query($sql);

    return $id;
}

function read_subsys_command_backup_status() {

    $ci =& get_instance();

    // Find any backup commands that have not finished
    $sql = "SELECT * FROM nagiosna_cmdsubsys WHERE nagiosna_cmdsubsys.command='1002' AND nagiosna_cmdsubsys.completed='0'";
    $query = $ci->db->query($sql);

    $status = $query->num_rows();

    return $status;

}