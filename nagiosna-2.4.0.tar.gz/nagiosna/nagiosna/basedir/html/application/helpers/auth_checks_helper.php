<?php

    /**
     * Redirect if user isn't logged in.
     **/
    function require_auth()
    {
        $ci =& get_instance();
        if(!($ci->ion_auth->logged_in())) {
            redirect('auth/login?next='.$_SERVER['REQUEST_URI']);
        }
    }

    /**
     * check auth for a role, and redirect if not
     **/
    function require_role($role)
    {
        $ci =& get_instance();
        $user = $ci->ion_auth->get_user();
        if(!($user->role == 'admin' || $user->role == $role)) {
            flash_error('<strong>Oops!</strong> You don\'t have access to that page.');
            redirect('dashboard');
        }
    }

    /**
     * check for an admin user
     **/
    function is_admin()
    {
        $ci =& get_instance();
        $user = $ci->ion_auth->get_user();
        return ($user->role == 'admin');
    }

    /**
     * Check for a logged-in user
     **/
    function logged_in()
    {
        $ci =& get_instance();
        return $ci->ion_auth->logged_in();
    }

    /**
     * Check role assignment
     **/
    function has_role($role) 
    {
        $ci =& get_instance();
        $user = $ci->ion_auth->get_user();
        return ($user->role == 'admin' || $user->role == $role);
    }

    /**
     * Check to see if user has accepted the agreement
     **/
    function require_agreement()
    {
        $ci =& get_instance();
        $user = $ci->ion_auth->get_user();
        if(!$user->agreement_accepted) {
            redirect('setup/user_agreement');
        }
    }
