<?php

function set_translation_locale($language) {
    $lang_path = APPPATH.'language/locales';
    $lang = sprintf("%s", $language);
    putenv('LANG='.$lang);
    putenv('LC_ALL='.$lang);
    setlocale(LC_ALL, $lang);
    bindtextdomain('lang', $lang_path);
    textdomain('lang');
}

// set locale based on config value
$ci = &get_instance();
set_translation_locale($ci->config->item('locale'));
