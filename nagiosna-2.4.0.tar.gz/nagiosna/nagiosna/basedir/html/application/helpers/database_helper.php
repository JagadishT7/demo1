<?php

function populate(&$populatee, $populator)
{
    $ci = get_instance();

    $pop = $ci->db->get_where($populatee->t, $populator);
    
    if($pop->num_rows() === 0) {
        $ids = array_values($populator);
        $id = $ids[0];
        $classname = get_class($populatee);
        throw new Exception("Could not find id {$id} for {$classname}.");
    }
    else {
        $poprow = $pop->row();
        foreach($poprow as $key => $value) {
            $populatee->$key = $value;
        }
    }
}

function populate_with_array(&$populatee, $populator)
{
    foreach($populator as $key => $value) {
        $populatee->$key = $value;
    }
}

function is_unique($selector, $table)
{
    //var_dump($selector);

    $ci =& get_instance();
    $query = $ci->db->get_where($table, $selector);
    
    return $query->num_rows() == 0;
}

function all_is_valid($scope, $items, $q, $table)
{
    $ci =& get_instance();
    $ci->load->library($scope);
    
    foreach($items as $item) {
    
        if(array_key_exists($item, $q) === FALSE) {
            $q[$item] = NULL;
        }
        
        $unique = $item."_is_unique";
        $valid = $item."_is_valid";
        
        if(method_exists($scope, $valid) === TRUE) {
            $success = call_user_func_array(array($scope, $valid), array($q[$item], $table));
            if($success === FALSE) {
                throw new Exception("{$q[$item]} is not a valid {$item}.");
            }
        }
        
        if(method_exists($scope, $unique) === TRUE) {
            $success = call_user_func_array(array($scope, $unique), array($q[$item], $table));
            if($success === FALSE) {
                throw new Exception("{$q[$item]} is not a unique {$item}.");
            }
        }
    }
}

function do_update($idselector, $upselector, $table)
{
    if(empty($upselector) === TRUE) {
        return;
    }
    
    $ci =& get_instance();
    $ci->db->where($idselector);
    $success = $ci->db->update($table, $upselector);
    
    if($success === FALSE) {
        throw new Exception("Unable to update database! Error: ".$ci->db->_error_message());
    }
}

function do_delete($idselector, $table)
{
    $ci =& get_instance();
    $success = $ci->db->delete($table, $idselector);
    
    if($success === FALSE) {
        throw new Exception("Unable to delete ID ".print_r($idselector, TRUE).": ".$ci->db->_error_message());
    }
}

function do_enumerate($selector, $table, $search=array(), $orderby=array(), $join=array())
{
    $ci =& get_instance();
    if (!empty($join)) {
        $ci->db->join($ci->db->escape_str($join['table']), $ci->db->escape_str($join['vars']));
    }
    if (!empty($orderby)) {
        $ci->db->order_by($ci->db->escape_str($orderby['col']), $ci->db->escape_str($orderby['sort']));
    }
    if (!empty($search)) {
        $ci->db->like($search);
        $result = $ci->db->get($table);
    } else {
        $result = $ci->db->get_where($table, $selector);
    }
    
    if($result === FALSE) {
        throw new Exception("Unable to query database with query: ".print_r($selector, TRUE)."!");
    }
    
    return $result;
}

function do_create($q, $table)
{
    $ci =& get_instance();
    $success = $ci->db->insert($table, $q);
    
    if($success === FALSE) {
        throw new Exception("Unable to insert into database! Error: ".$ci->db->_error_message());
    }
}

function set_x(&$setee, $selector)
{
    foreach($selector as $key => $value) {
        $setee->$key = $value;
        $setee->to_update[$key] = $value;
    }
}
