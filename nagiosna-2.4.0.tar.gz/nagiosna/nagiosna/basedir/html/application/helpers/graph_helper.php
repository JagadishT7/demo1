<?php

if (!function_exists('highchartify')) {

    function highchartify($name, $meta, $data)
    {
        $interval = intval($meta['step']);
        $legend = $meta['legend'];
        $start = intval($meta['start']);

        $retjson['name'] = $name;
        $retjson['type'] = 'area';
        $retjson['pointInterval'] = $interval * 1e3;
        $retjson['pointStart'] = $start * 1e3;
        $retjson['data'] = array();
        
        $s_name = make_safe($name);
        $index = array_search($s_name, $legend);
        
        $datapoints = count($data) - 1;
        
        $total = 0;
        for ($i = 0; $i < $datapoints; $i++) {
            $total += round($data[$i][$index], 0);
            $retjson['data'][] = round($data[$i][$index], 2);
        }

        $retjson['total'] = $total;
        
        return $retjson;
    }
}
if (!function_exists('make_defs')) {

    function make_defs($metric, $rrd, $mprefix='', $rra='AVERAGE')
    {
        return array('DEF', "{$mprefix}{$metric}={$rrd}", $metric, $rra); 
    }
}

if (!function_exists('make_cdefs')) {
    
    function make_cdef($name, $dsname)
    {
        $cdefs = array();
        
        $modified = array();
        foreach($dsname as $ds) {
            $d = "{$ds}{$name}";
            $cdefs[] = array('CDEF', "f{$d}={$d},UN,0,{$d},IF");
            $modified[] = "f{$d}";
        }
        
        if(count($modified) < 2) {
            $modified[] = '0';
        }
        
        $plusses = array_fill(0, count($modified) - 1, '+');
        $rpn = array_merge($modified, $plusses);
        $addlist = implode(',', $rpn);
        
        $cdefs[] = array('CDEF', "{$name}={$addlist}");
        
        return $cdefs;
    }
}

if(!function_exists('make_xport')) {
    
    function make_xport($key, $label)
    {
        $xport = array('XPORT');
        $xport[] = $key;
        $xport[] = "'".$label."'";
        return $xport;
    }
}

if(!function_exists('make_safe')) {
    
    function make_safe($str)
    {
        return preg_replace('/[^\da-z]/i', '', $str);
    }
}

if(!function_exists('call_rrd_xport')) {
    
    function call_rrd_xport($defs, $start, $end='-1s', $limit='')
    {
        $cmd[] = '/usr/local/bin/rrdtool';
        $cmd[] = 'xport';
        $cmd[] = '--json';
        $cmd[] = '--start';
        $cmd[] = escapeshellarg($start);
        $cmd[] = '--end';
        $cmd[] = escapeshellarg($end);
        
        foreach($defs as $def) {
            if($def[0] === 'XPORT') {
                $cmd[] = implode(':', $def);
            }
            else {
                $cmd[] = escapeshellarg(implode(':', $def));
            }
        }
        
        $output = array();
        $cmdline = implode(' ', $cmd);

        if (!empty($limit)) {
            $cmdline .= ' -m '.$limit;
        }
        
        exec($cmdline, $output, $returncode);
        
        if($returncode !== 0) {
            throw new UnexpectedValueException('error executing command line for the port graph: '.$cmdline);
        }
        
        $json = implode('', $output);
        
        return $json;
    }
}

if(!function_exists('get_nfcapd_filename_of_time')) {
    
    function get_nfcapd_filename_of_time($ts)
    {
        $nfdate = strftime('%Y%m%d%H%M', $ts);
        return round($nfdate/5) * 5;
    }
}
