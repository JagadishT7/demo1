<?php
    /**
     * Determine whether user is on a mobile device.
     **/

    function is_android()
    {
        return stripos($_SERVER['HTTP_USER_AGENT'],"Android");
    }

    function is_ipad()
    {
        return stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
    }

    function is_iphone()
    {
        return stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    }

    function is_ipod()
    {
        return stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
    }

    function is_webos()
    {
        return stripos($_SERVER['HTTP_USER_AGENT'],"webOS");
    }

    function is_mobile()
    {
        return is_android() || is_ipad() || is_iphone() ||
            is_ipod() || is_webos();
    }

    function is_ios()
    {
        return is_ipad() || is_iphone() || is_ipod();
    }
