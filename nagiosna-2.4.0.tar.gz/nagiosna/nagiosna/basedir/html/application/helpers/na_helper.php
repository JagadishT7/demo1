<?php

/* Genereal helpers for NNA */

class ValidationError extends Exception
{
    function __construct($message, $code=0)
    {
        parent::__construct($message, $code);
    }
}

function human_readable_size($size)
{
    $gb = 1073741824; // bytes
    $mb = 1048576;
    $kb = 1024;

    if ($size > $gb) {
        return round(($size / $gb), 2) . " GiB";
    } else if ($size > $mb) {
        return round(($size / $mb), 2) . " MiB";
    } else if ($size > $kb) {
        return round(($size / $kb), 2) . " KiB";
    } else {
        return ($size) . " B";
    }
}

// Set a usermeta variable
function set_usermeta($name, $value, $uid=null)
{
    $ci =& get_instance();
    if ($uid == null) {
        // Grab the current user's uid based on the session
        $uid = $ci->session->userdata('user_id');
    }

    // Let's add it into the database
    $data = array('uid' => $uid, 'name' => $name, 'value' => $value);
    $where = array('name' => $name, 'uid' => $uid);

    // Grab the user meta and see if we have any rows returned...
    $ci->db->where($where);
    $ci->db->from('nagiosna_usermeta');
    $count = $ci->db->count_all_results();

    if ($count == 0) {
        // Insert
        $ci->db->insert('nagiosna_usermeta', $data);
    } else {
        // Update
        $ci->db->update('nagiosna_usermeta', $data, $where);
    }
}

// Get a usermeta variable
function get_usermeta($name, $uid=null)
{
    $ci =& get_instance();
    if ($uid == null) {
        // Grab the current user's uid based on the session
        $uid = $ci->session->userdata('user_id');
    }

    // grabthe item from the database
    $ci->db->where(array('uid' => $uid, 'name' => $name));
    $ci->db->from('nagiosna_usermeta');
    $query = $ci->db->get();

    if ($query->num_rows() > 0) {
        $results = $query->result();
        return $results[0]->value;
    }

    return 0;
}