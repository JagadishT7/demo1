<?php

/**
 * various helpers for incident (and other?) grid tables
 **/

if (!function_exists('sort_link')) {

    function sort_link($sort_field, $link_text, $default=false)
    {
        $ci =& get_instance();
        // if sorted by this field, show an up/down caret
        if($ci->input->get('sort') == $sort_field) {
            $arrow_class = ($ci->input->get('dir') == 'asc') ? 'icon-chevron-up' : 'icon-chevron-down';
            $target_sort_direction = ($ci->input->get('dir') == 'asc') ? 'desc' : 'asc';
        } elseif($default && !$ci->input->get('sort')) {
            $arrow_class = ($ci->input->get('dir') == 'asc') ? 'icon-chevron-up' : 'icon-chevron-down';
            $target_sort_direction = 'asc';
        } else {
            $arrow_class = '';
            $target_sort_direction = 'asc';
        }

        $base_url = $_SERVER['PHP_SELF'];
        $target_url = '?_x=0';

        // save any search filters applied
        if($ci->input->get('filter')) {
            $target_url .= '&filter='.$ci->input->get('filter');
        }
        
        $target_url .= '&sort='.$sort_field.'&dir='.$target_sort_direction;

        #return sprintf('<i class="%s"></i> <a href="%s">%s</a>',
            #$arrow_class, $target_url, $link_text);
        return sprintf('<a href="%s">%s</a> <i class="%s"></i>',
            $target_url, $link_text, $arrow_class);
    }
}

if(!function_exists('status_label')) {

    function status_label($status)
    {
        switch(strtolower($status)) {
            case 'urgent':
            case 'immediate':
                $label_class = 'label-important';
            break;
            case 'high':
                $label_class = 'label-warning';
            break;
            default:
                $label_class = '';
            break;
        }
        return '<span class="label '.$label_class.'">'.ucfirst(strtolower($status)).'</span>';
    }
}
